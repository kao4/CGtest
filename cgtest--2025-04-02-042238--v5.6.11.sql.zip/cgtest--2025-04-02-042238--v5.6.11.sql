-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_qforvuyvsuikrgivhifbnnhrrpukjadziuxa` (`primaryOwnerId`),
  CONSTRAINT `fk_brxflzhcqymstkefxdgnokfibvaqpfczaqkb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qforvuyvsuikrgivhifbnnhrrpukjadziuxa` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_egdvkcbwyimozdikphwsgeuzepmuxacchlhm` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_vjqxrxpeoinhthrpqcgrelqcticinuxmgwvr` (`dateRead`),
  KEY `fk_lyfjobdnpeeeqtgzvasgdfonsigpxehibews` (`pluginId`),
  CONSTRAINT `fk_jmgvfkeqnxfnzmnzjkbggreunqndlqtkgyom` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lyfjobdnpeeeqtgzvasgdfonsigpxehibews` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cgdzvqmtbxbimhstdwonvsrullhyrukwxgpf` (`sessionId`,`volumeId`),
  KEY `idx_vtbwlmztgsvkfddilmqgibxwdqxlxxlqlxsd` (`volumeId`),
  CONSTRAINT `fk_anyfinqmqedcecqdoynbitnfroyxufyfljyd` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_omnzmqqdexbufbydwzcyvnpspsoujpmhefuu` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_stuurpqgdwnwkrwkdgyjuusmwxutnzyrrzyh` (`filename`,`folderId`),
  KEY `idx_xindyswpyavvwwtiwgbxkpezmxmjstdzjyav` (`folderId`),
  KEY `idx_zxqtphdznkqazgcgwbkfntzwfmqteyallerw` (`volumeId`),
  KEY `fk_pmzadyknhmtywcuxbygpaqhpzmhecoycfoox` (`uploaderId`),
  CONSTRAINT `fk_hrtmuziopilduoqeoiiihqeqoctsibzhoiis` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ifwmzdxygdzlwojsikaddnqnrxxuliymkuha` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pmzadyknhmtywcuxbygpaqhpzmhecoycfoox` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_truicnywgafnhcpytctlaifymktijpnvesea` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_hbrjoqpuicshsxbpnaiqzcmqimnyeoexpnrc` (`siteId`),
  CONSTRAINT `fk_dqiprbizhnjjdubjarkunbazcqfmfmxnahob` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hbrjoqpuicshsxbpnaiqzcmqimnyeoexpnrc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cfmkptrelruvqeowypusdwndrmpjfpnnmktu` (`userId`),
  CONSTRAINT `fk_cfmkptrelruvqeowypusdwndrmpjfpnnmktu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wxcohchvmhhtdevnwrdndpgmpgttyzqzzhhv` (`groupId`),
  KEY `fk_dnellianyhazkdljbfindjtjoogdwueoziid` (`parentId`),
  CONSTRAINT `fk_dnellianyhazkdljbfindjtjoogdwueoziid` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_eheqrtjswethwfbdyvlvriwfzfynhndsbhlv` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eveznpputzrrvgcdjzvepsnhvaxbadkwmksa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hffcoqqlvpzzwlpukpzjtheetrkppnkrghjs` (`name`),
  KEY `idx_tfqgemmagihjpczylqobqsomepnkdrpbxmqa` (`handle`),
  KEY `idx_uyjzguefrtovxncczavxombhzlutmunvunqy` (`structureId`),
  KEY `idx_lcqfnzlwoaegtimcqcsklrvhkybtcvqdykfw` (`fieldLayoutId`),
  KEY `idx_crthzhronxtilwnvndiafwdjkfppocktdadg` (`dateDeleted`),
  CONSTRAINT `fk_jlyxwclzwdrbapceqqzvvbmkxggkhumqgyhi` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vmqqpsdarhzlqpweuwsxfrgjigmuxhutijqd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gxpcjpduowqdqwxzkzpawzbiaabntkmtdlsm` (`groupId`,`siteId`),
  KEY `idx_cdmabtkdhaarwttbyxngaetdbfromujdfytr` (`siteId`),
  CONSTRAINT `fk_vagoeshxwfvgispgiblmaduwphfhbuprlejr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ykwwkzizlmmugbipwfnqpiyygtgzgfindusx` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_dmzykntvetntddfhkoxldepiupjphijsqscm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_qmwhobmcgoouphhffdqwlnlthgyvxnwbpbwa` (`siteId`),
  KEY `fk_neaybmrmlywcpznaicvkblgmtpgrmvxmyoum` (`userId`),
  CONSTRAINT `fk_neaybmrmlywcpznaicvkblgmtpgrmvxmyoum` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ntphthhfhrplyxrnwfuxxtgkolggsvgggggn` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qmwhobmcgoouphhffdqwlnlthgyvxnwbpbwa` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_pznrgbesvqmzvhumckyuovldifdsngxdjyyr` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ucynkiyfyrgbyhtcpgsrzmvwzopvetxitfbv` (`siteId`),
  KEY `fk_lkcmliotwhtuytannawodfwrudmmefhzifcl` (`fieldId`),
  KEY `fk_duqmbishhexlhkcaqlosijgphqddgkxyblms` (`userId`),
  CONSTRAINT `fk_duqmbishhexlhkcaqlosijgphqddgkxyblms` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_idaauvyipuqdupawbmtbgdvepdrjsxemyxop` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lkcmliotwhtuytannawodfwrudmmefhzifcl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ucynkiyfyrgbyhtcpgsrzmvwzopvetxitfbv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_nmbjfygfkxwrseqkkkqsisjrqekfgbbendfl` (`userId`),
  CONSTRAINT `fk_nmbjfygfkxwrseqkkkqsisjrqekfgbbendfl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_drdounnetjnszmeoiyujgsnebtzwcvzpddnf` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_mdlrlbxqikidcxbcqfbbmfajmkomfywyfiuo` (`creatorId`,`provisional`),
  KEY `idx_wsscuzaatfwmkltsvkkhpbzfxxbblwigqahe` (`saved`),
  KEY `fk_ppdcncgatslxqqzmggkdfjtubgozvlyjfops` (`canonicalId`),
  CONSTRAINT `fk_ppdcncgatslxqqzmggkdfjtubgozvlyjfops` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uguemzrkthyxorhpndkkejctvezgbpueutmt` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_kgacgbvkuweikcylsgicpdzwuortookhkzoc` (`elementId`,`timestamp`,`userId`),
  KEY `fk_vnkyqxzujpzrguwvjexpqorrgycpoigmffyw` (`userId`),
  KEY `fk_zxjdtnlcmkbhrkzrkguuargixxtqvwlumwcw` (`siteId`),
  KEY `fk_mrhhgydaldeawsniyedkehnhezeesqpaaiij` (`draftId`),
  CONSTRAINT `fk_hpxnslegapnaadglwdhzvqnitbophgturpwt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mrhhgydaldeawsniyedkehnhezeesqpaaiij` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vnkyqxzujpzrguwvjexpqorrgycpoigmffyw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zxjdtnlcmkbhrkzrkguuargixxtqvwlumwcw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rvlmlnxocphwkmlegmsfjlxxpceqkydsuwly` (`dateDeleted`),
  KEY `idx_tjlykxovanqucycxrmkmxrmnnxduguuqsixp` (`fieldLayoutId`),
  KEY `idx_ymclhbrxwfqslxljxrwggefdpwvdcoquztmg` (`type`),
  KEY `idx_tsfufsskrwiftxixkaxtldlscpgkswlsymct` (`enabled`),
  KEY `idx_gszrkecxtlvafcwrwgqlwpsetpxjdaohtpnm` (`canonicalId`),
  KEY `idx_xfwyonuekcwzzlrvqwfnxamqnjgykbdtjpko` (`archived`,`dateCreated`),
  KEY `idx_rvlokxtauvaisggvrwmoiyxvgsnassoopdye` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_pagcxrojhlvexebdeqdutngwgmgkovxbrufm` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ollxqyzwboutuglutcekrngkmfvszxopfixa` (`draftId`),
  KEY `fk_hbwmgermzxqxmwxmgsrkimwjxmdhbtptzaao` (`revisionId`),
  CONSTRAINT `fk_giiutjwsoxpqwzvundqtniwzxtqcpnnzhpmy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hbwmgermzxqxmwxmgsrkimwjxmdhbtptzaao` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ollxqyzwboutuglutcekrngkmfvszxopfixa` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rbgmqgxvhiireycaqvcuyaykqlemkvjixsgr` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_krjsiaftdznfgaqiintrxyjdduaoovxzbowu` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_bihqrfxhhpqyivobxlloksqfyffvwbaairfb` (`ownerId`),
  CONSTRAINT `fk_bihqrfxhhpqyivobxlloksqfyffvwbaairfb` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gqvxzdmmmqsretndctuxjpirzsswqakwpfvq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ujxchpwnluywketjuzfbgbuxxgnlfxelctlc` (`elementId`,`siteId`),
  KEY `idx_cxudeocmwubpwmpskjgucgbkmjklyugyugzm` (`siteId`),
  KEY `idx_gnlqcwkymmnzoqmdafmhatdzchurmramtwdt` (`title`,`siteId`),
  KEY `idx_dogfejvhnbvudfpzntdypbetwlvniqcyrfxl` (`slug`,`siteId`),
  KEY `idx_cuexnihijdexzluppqsoqlruvzhpwtwedeks` (`enabled`),
  KEY `idx_gsiecfyhlugcidjcxaqxkmcevqixorpvrzch` (`uri`,`siteId`),
  CONSTRAINT `fk_cnbztyzpqxefhbqbtcsfsuvaveddeodokztw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_shlhejcekumdgcppdrkxuxopkfrqqxforbjm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mqlirlmsqdwiipufwgenqefjyuqikwskocxw` (`postDate`),
  KEY `idx_flyqbkzaaibbavmtbljmztfgxwwstocmedqc` (`expiryDate`),
  KEY `idx_hkcvtcqvwcfwrlfetmtvvohlcvdeqxysxfkl` (`sectionId`),
  KEY `idx_jqpgkavrthijsbchsuqlglosgqvvbqhorjkk` (`typeId`),
  KEY `idx_scibvplomnzwpeaxobgllcejenxriyjxmfyc` (`primaryOwnerId`),
  KEY `idx_fxednxtiipkccnmiydvjmojttvgxcxwxdowy` (`fieldId`),
  KEY `fk_lkkginixnfiwnikrztbxwhaxmmvvuktjcbyk` (`parentId`),
  CONSTRAINT `fk_fbvsjlwsrsyyghdncxnpkxmfbxprkxuedkdx` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lkkginixnfiwnikrztbxwhaxmmvvuktjcbyk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uagavwpokqumycrfuxnthettbhwbqaxyqvob` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yfclyjbwdvogukqzqgxdhcfksgzcmurppqgn` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zkacbqddvpwiamhtourprtziuswryxjjvmvm` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zrwxasodxhcyypvaqhzmxkjvqzrlpxiuhxgj` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_cxxbragjykwyyaaqvkaofyfudhsbzyuzkaiz` (`authorId`),
  KEY `idx_ipcdamyslbzxbhlxjoqipwlijwfdvvijyyoi` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_tydxtvjezacvzicmpjcdfzmimnqjlkmcttcg` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_umdgmefuefjsjepgsgblbqhqvecwvravumiu` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yxtqnlfyckpxrwxjrosgmsryahrhyoufqckd` (`fieldLayoutId`),
  KEY `idx_dxngqtvietctiwsubhegkpgahhmhvcomjhym` (`dateDeleted`),
  CONSTRAINT `fk_kkrqdqxvknwecsfeavqroswjneujdbrsyvre` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dhhgutqcpaowclsqgrcmuvtkavwbpdvlbral` (`dateDeleted`),
  KEY `idx_ptvlukbwkxppiffmhvhksepersmftqwxgokz` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_slczohbykqqqvrwqurrxkkwgtlvrdfihtvta` (`handle`,`context`),
  KEY `idx_knfypgrckcdxvfcxxbeotyoiyhctfdflggku` (`context`),
  KEY `idx_sfajmyfgbomycvqsonoyqpizgjqfbikovlfe` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rqgcamkmuksvmtwvgeljuqoizavzchxpqifi` (`name`),
  KEY `idx_btpexkzrqfwbmrfsbawncddgvcllcdzdbcmy` (`handle`),
  KEY `idx_nhzfvfuepawhliceuzhyfgzcshkhsppueold` (`fieldLayoutId`),
  KEY `idx_ytpcknmyqahuvffxlmgvvlpoomnnaxvjtsmi` (`sortOrder`),
  CONSTRAINT `fk_bvawgjdtmiujjtgmfvzthpwhqkizwikeltlo` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gfgtebetoyhhgmdmagitwgdosyjitmkeueiu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lqzrwmodnmylznaspbqmksjccjnznauxswfp` (`accessToken`),
  UNIQUE KEY `idx_unwlifpbfmwvxttualxkioocrhyagbjmtdjr` (`name`),
  KEY `fk_mdcdxsxgrneqmfpwqaxkrughkgojrfmzxnwc` (`schemaId`),
  CONSTRAINT `fk_mdcdxsxgrneqmfpwqaxkrughkgojrfmzxnwc` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_giqeevhacuebzkhqgvwjiihfwasbofmoavjc` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wriscocgbpvggmetnhevpfhziezclvlzbvsy` (`name`),
  KEY `idx_ddvafuhyurhmwopqcqczxzjzwdxibvylaujp` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wpenpsykkphftahitcthehimknokqhkqlrcn` (`track`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nxrpbxuiarneuvqffwswfsejjibvnmybpyiz` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_qhbhmxvskbqrpymwoksobuvigjbpodmpoijr` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_mvverkwrdjmddyrtvlrkqpywadyafkqatxby` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=1012 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mjngequksfoyqbksmgddtkifkqtljbyazacx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_vczxnkmtqupxkxlpvwvffxhmnzzregqqbgzz` (`sourceId`),
  KEY `idx_fyaegkequeaaxgsnkcdnzrnyivnijcjuhxnb` (`targetId`),
  KEY `idx_qncnoowmrbkkiuuijwelcnccsmivrqtaadra` (`sourceSiteId`),
  CONSTRAINT `fk_fgitsbkpbkfhygoqaxcowqnthzyygjciwykq` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gwthvwydizalhpfktchvrzcirllorvuxszcw` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hdyrqprmlwrtvmqlqqnhizcwpzamvpwpozdq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=532 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nsoolsyfbowyfhkilguybehyojktxbbtjujy` (`canonicalId`,`num`),
  KEY `fk_xzvbnhnefknbzexcdorhzciuhuhacrxbqneq` (`creatorId`),
  CONSTRAINT `fk_nslqymgghgomragypijiekkujeyeknsmfbll` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xzvbnhnefknbzexcdorhzciuhuhacrxbqneq` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_glmymutnxgplxagqxamkikwakhxqczzslwef` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nmutnbfbtnxhxhfwksalutyxcbgoktudzhbv` (`handle`),
  KEY `idx_swuwechnfytzkwvjzclzpqlxdnkzmvxvbzsa` (`name`),
  KEY `idx_oqaqjneirlgeixcefqzqjzmmgeevrtxibhmy` (`structureId`),
  KEY `idx_jpblfwomflqaegvpkjbmwwxphfhsdntanqda` (`dateDeleted`),
  CONSTRAINT `fk_nwdtevyzkqjhgzbuckmbmqllqrztbdtpvxmh` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_caorkvgibopvltzpdizagoonoxvlabgqdgxr` (`typeId`),
  CONSTRAINT `fk_caorkvgibopvltzpdizagoonoxvlabgqdgxr` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qxbdgthsxjqgvkvsnmjbgxrpvkmoyhnqlpai` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nehyoudrxualczfpkctlnsutbbldewmczqly` (`sectionId`,`siteId`),
  KEY `idx_rbilgkuezcxgbdlhmzamtkginenhgylfyeaj` (`siteId`),
  CONSTRAINT `fk_qrvfhcnqfohlfkgafwswdapqudhxigregusz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wgeewwzmbrvgwnokzocxgxtvrjpsbgtkciks` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wrszhmjynhpurnbgydjhznsuwylykopaybih` (`uid`),
  KEY `idx_yimddgacooyqskhxlgxsudxzdursyjnsjzdj` (`token`),
  KEY `idx_tpvfctcfkatgapnxqoxorxwojfscsngqubls` (`dateUpdated`),
  KEY `idx_qgxmdcfnqjjrrfmwodzclpxyacamdehbvozl` (`userId`),
  CONSTRAINT `fk_suegibrlmkkfuxofhvowewbjvcflmynlkfyu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uyuifecqnnoksfmuzgocoidksyysxmeyjzse` (`userId`,`message`),
  CONSTRAINT `fk_hbweytbqbdbacvxmvuehmwwtdgmevvwwrdrw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_avvvrqxzvewsouhajsxmnwkfxyhdpisnnifr` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nxlfeeqyzghhsrgarmtahofpzigpzhqmfkwq` (`dateDeleted`),
  KEY `idx_fulqmlmyadjutwbeqrpnrwrybkvmmutwjgcz` (`handle`),
  KEY `idx_jknuedjwlllhuwhxakcqjeprrqynhjhlxast` (`sortOrder`),
  KEY `fk_yfgeyhlgrdtpxtrhkhukwhumtydnagczzbwo` (`groupId`),
  CONSTRAINT `fk_yfgeyhlgrdtpxtrhkhukwhumtydnagczzbwo` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_pwmkdgpcwkmsmwldaccywxnbvylvovbcbomq` (`userId`),
  CONSTRAINT `fk_pwmkdgpcwkmsmwldaccywxnbvylvovbcbomq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ugxwbsgfgpkmlxcfvyftldehthglubverpqo` (`structureId`,`elementId`),
  KEY `idx_tbgwuytmlwgtbxuwillajbxoscldmveuzjgu` (`root`),
  KEY `idx_rmvedtbrxeyfooakxwcbbusuoxacrisigzcm` (`lft`),
  KEY `idx_jamlglkeciqejhbxneitmwqqxapgkwmoohbz` (`rgt`),
  KEY `idx_kpzopfwktlzhjdtwghkvhgrclxycxeiyvryu` (`level`),
  KEY `idx_xljycuahaxefueznrctxzjspccctxozwbdin` (`elementId`),
  CONSTRAINT `fk_mapwimkenepswrtlponavdfjwiebqosvnekd` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kodhxjuevbvglomsrpmimlipozeszyblgytn` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ipkkuncfuqatqbflvlatmhgfkcupctttbsuq` (`key`,`language`),
  KEY `idx_drbakajamghfjmhmxgbakzdytkmrsezfzgno` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bhewcvihooeolucornsjzthwauswzkuldbch` (`name`),
  KEY `idx_smdcbxjvqhigkezlbesuahkpvxjcwhihqvyd` (`handle`),
  KEY `idx_thelkjhqqqllhfnzcxfdzevafyeutwhbixpm` (`dateDeleted`),
  KEY `fk_hcolpxkyafcrofrblsjhucplltffjqheiffb` (`fieldLayoutId`),
  CONSTRAINT `fk_hcolpxkyafcrofrblsjhucplltffjqheiffb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pjhskglhwuxhadtvbejuiuvuzitazixzljju` (`groupId`),
  CONSTRAINT `fk_xqoamrvppikfhscbihqkxyemyhhskjhylkqk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yotocejmxdmfthdzuqzeaxhtzjocmehqfrzy` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rgezbntbpzpaqjnemtkuhjkidyvxdqyyutde` (`token`),
  KEY `idx_lqndxjdjxiafpfwlzpyjpnirgbntcxrieyjm` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qkhrinsgpoprehmraraocwegghzotileirdn` (`handle`),
  KEY `idx_xtancbozvtsthbxsgoyeccubaoxsmwperqvm` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_klectsyyeocpdttspfrlcjofgmastnzizqhj` (`groupId`,`userId`),
  KEY `idx_koxgsinfmphbmgbofupzzoueoejctbkxreow` (`userId`),
  CONSTRAINT `fk_avwirspjjalggfvdfooqtdbjrteeivrzogho` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hmmhbbizthlvjzbwbcdkkcioweidtvbozfin` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rzkuvqeuknsfulkexsqpgjzsfdxgkespfcey` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_olnxfssfavrfsrbqluaknzckvqflhqjmkcsu` (`permissionId`,`groupId`),
  KEY `idx_fcjstlbplyksjzmgykcutbesvevorytsdpyv` (`groupId`),
  CONSTRAINT `fk_aqaztfntqddeeppvpkcigpgzbycmccgefqyc` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qehqvawaykfkqpvxrjjletkmubyrbcjsuaug` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tpdsgqxmkldgzuujnhtdokxajeagboditpfn` (`permissionId`,`userId`),
  KEY `idx_iedbtlxblbzdvcduhqhlaypnativkmivqurz` (`userId`),
  CONSTRAINT `fk_kedyfjuafnfzhiwfisrjdfqdoggpuozvqwyh` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vcxmphflhielxdzfzxhlvsqgkqcbtofvxxhi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_chbbsbsfyborqhmyvjmhmhcnlaxagjrubyjj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mttxvrkesfbzttueodxhistlkbqotgkdbbcp` (`active`),
  KEY `idx_fxhxkfemshorbkrhyzjysrrcdtvblyxjpsln` (`locked`),
  KEY `idx_ytbxznqwmrwoqqcqnjdtlmoqpelremyurumj` (`pending`),
  KEY `idx_efddwgmsnttdgumfconauireidveaetmlomi` (`suspended`),
  KEY `idx_nhiwycycgjplewvfstuiqvgqxddrclqafodi` (`verificationCode`),
  KEY `idx_hvivprpfzutsklfhybebjgfpvoaqfjfwxxim` (`email`),
  KEY `idx_bthdjocvwadndusqebuemfofvhzolbxjmelc` (`username`),
  KEY `fk_oszzgzhjyozdcizcoikxwaylomjfbqczpwak` (`photoId`),
  KEY `fk_iptryxhbqbmngchexwmoxvcijbmhdtzsjqyf` (`affiliatedSiteId`),
  CONSTRAINT `fk_iptryxhbqbmngchexwmoxvcijbmhdtzsjqyf` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oszzgzhjyozdcizcoikxwaylomjfbqczpwak` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uvxdueqnggspwtfxdazugrfbtcjanaeawplr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_khnhkrwihpzpvilsaglpkobcnsnzzlgueqvc` (`name`,`parentId`,`volumeId`),
  KEY `idx_ymqvxqmgzoxiovobsswafpvbpygllvdnjmrt` (`parentId`),
  KEY `idx_hfzwqlmyobnnzaqdngblopitycjdreqfargt` (`volumeId`),
  CONSTRAINT `fk_jtzugpgqoqqwoumiwesfseolvflgrwcicrtd` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_virvcmjjmrmjkbdpizxhykusfzamwztxkrcw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_abubdlbqjaeymarandgtiyadxdacxxaqhiha` (`name`),
  KEY `idx_ywtlsfpzuzyyhgvflfogwpqbbgbwgyiqvvvo` (`handle`),
  KEY `idx_yqmvmdcotrezqgfgasakvyzhfkyxzvcfobim` (`fieldLayoutId`),
  KEY `idx_sphvdvemoqbxqvqcembiikhetglzjdjskubh` (`dateDeleted`),
  CONSTRAINT `fk_yysnmxdodqtxwiowdmxeiogmbzzeagdbqtxv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_lzmrpubiykqfyeyyrchczqozldmouyhvvkdn` (`userId`),
  CONSTRAINT `fk_lzmrpubiykqfyeyyrchczqozldmouyhvvkdn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oevoknjntjqapicbhmexevdwqnvtubemrilc` (`userId`),
  CONSTRAINT `fk_yhdiqppcqtbcwqvepgkdbssuybrxmevlhohf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-02 13:22:38
-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (6,NULL,3,2,'mate01@2x.webp','image',NULL,1840,1308,80582,NULL,NULL,NULL,'2025-03-17 05:39:17','2025-03-17 05:39:17','2025-03-17 05:39:17'),(7,NULL,3,2,'next__small@2x.webp','image',NULL,661,470,35724,NULL,NULL,NULL,'2025-03-17 05:39:17','2025-03-17 05:39:17','2025-03-17 05:39:17'),(8,NULL,3,2,'slide03@2x.webp','image',NULL,895,1312,47192,NULL,NULL,NULL,'2025-03-17 05:39:17','2025-03-17 05:39:17','2025-03-17 05:39:17'),(9,NULL,3,2,'slide02@2x.webp','image',NULL,896,1298,66274,NULL,NULL,NULL,'2025-03-17 05:39:17','2025-03-17 05:39:17','2025-03-17 05:39:17'),(10,NULL,3,2,'mate_top.webp','image',NULL,2880,2050,120466,NULL,NULL,NULL,'2025-03-17 05:39:18','2025-03-17 05:39:18','2025-03-17 05:39:18'),(11,NULL,3,2,'next.webp','image',NULL,2880,2046,315570,NULL,NULL,NULL,'2025-03-17 05:39:19','2025-03-17 05:39:19','2025-03-17 05:39:19'),(12,NULL,3,2,'slide01@2x.webp','image',NULL,896,1298,59642,NULL,NULL,NULL,'2025-03-17 05:39:19','2025-03-17 05:39:19','2025-03-17 05:39:19'),(13,1,4,2,'mate_top_2025-03-17-054048_qgcu.webp','image',NULL,2880,2050,120466,NULL,NULL,NULL,'2025-03-17 05:41:07','2025-03-17 05:40:49','2025-03-17 05:41:07'),(19,1,1,2,'mate_top.webp','image',NULL,2880,2050,120466,NULL,0,0,'2025-03-17 05:44:36','2025-03-17 05:44:36','2025-03-17 05:44:36'),(22,1,4,2,'slide01.webp','image',NULL,896,1298,59642,NULL,NULL,NULL,'2025-03-17 05:48:38','2025-03-17 05:45:28','2025-03-17 05:48:38'),(23,1,4,2,'slide02.webp','image',NULL,896,1298,66274,NULL,NULL,NULL,'2025-03-17 05:48:38','2025-03-17 05:45:34','2025-03-17 05:48:38'),(24,1,4,2,'slide03.webp','image',NULL,895,1312,47192,NULL,NULL,NULL,'2025-03-17 05:48:38','2025-03-17 05:45:39','2025-03-17 05:48:38'),(37,1,4,2,'mate01.webp','image',NULL,1840,1308,80582,NULL,NULL,NULL,'2025-03-17 06:07:22','2025-03-17 06:07:22','2025-03-17 06:07:22'),(94,1,1,2,'namecard__top.webp','image',NULL,2880,2049,328318,NULL,NULL,NULL,'2025-03-18 07:13:07','2025-03-18 07:12:48','2025-03-31 00:55:06'),(96,1,5,2,'namecard01.webp','image',NULL,920,690,17084,NULL,NULL,NULL,'2025-03-18 07:14:28','2025-03-18 07:14:28','2025-03-18 07:15:12'),(98,1,5,2,'namecard02.webp','image',NULL,920,655,15686,NULL,NULL,NULL,'2025-03-18 07:14:37','2025-03-18 07:14:37','2025-03-18 07:15:12'),(107,1,6,2,'infocom_top.webp','image',NULL,2880,2049,165514,NULL,NULL,NULL,'2025-03-19 03:12:01','2025-03-19 03:11:51','2025-03-19 03:12:01'),(109,1,1,2,'infocom01.webp','image',NULL,1839,1392,10988,NULL,0,0,'2025-03-19 03:13:12','2025-03-19 03:13:12','2025-03-19 03:13:12'),(111,1,1,2,'infocom_slide01.webp','image',NULL,895,1299,34492,NULL,0,0,'2025-03-19 03:13:21','2025-03-19 03:13:21','2025-03-19 03:13:21'),(112,1,1,2,'infocom_slide03.webp','image',NULL,896,1298,39480,NULL,0,0,'2025-03-19 03:13:21','2025-03-19 03:13:21','2025-03-19 03:13:21'),(113,1,1,2,'infocom_slide02.webp','image',NULL,895,1298,40608,NULL,0,0,'2025-03-19 03:13:21','2025-03-19 03:13:21','2025-03-19 03:13:21'),(136,1,1,2,'infocom_next.webp','image',NULL,2880,2048,107924,NULL,NULL,NULL,'2025-03-21 03:55:04','2025-03-21 03:55:04','2025-03-31 00:55:06'),(147,1,1,2,'short_offline_240822.mp4','video',NULL,NULL,NULL,5124963,NULL,0,0,'2025-03-21 04:11:02','2025-03-21 04:11:02','2025-03-21 04:11:02'),(151,1,9,2,'MATE_TOP-1.webp','image',NULL,2880,2050,482076,NULL,0,0,'2025-03-21 08:03:02','2025-03-21 08:02:51','2025-03-21 08:03:02'),(153,1,1,2,'mate01-1.webp','image',NULL,1061,1014,18994,NULL,0,0,'2025-03-21 08:04:36','2025-03-21 08:04:36','2025-03-21 08:04:36'),(155,1,1,2,'mate02.webp','image',NULL,1840,1197,169282,NULL,0,0,'2025-03-21 08:04:50','2025-03-21 08:04:50','2025-03-21 08:04:50'),(157,1,1,2,'mate__slide01.webp','image',NULL,660,1173,41342,NULL,0,0,'2025-03-21 08:05:02','2025-03-21 08:05:02','2025-03-21 08:05:02'),(158,1,1,2,'mate__slide02.webp','image',NULL,661,1173,43636,NULL,0,0,'2025-03-21 08:05:08','2025-03-21 08:05:08','2025-03-21 08:05:08'),(159,1,1,2,'mate__slide04.webp','image',NULL,660,1172,34310,NULL,0,0,'2025-03-21 08:05:08','2025-03-21 08:05:08','2025-03-21 08:05:08'),(164,1,1,2,'mate__slide03.webp','image',NULL,661,1173,58650,NULL,0,0,'2025-03-21 08:06:00','2025-03-21 08:06:00','2025-03-21 08:06:00'),(171,1,6,2,'short_offline_240822.mp4','video',NULL,NULL,NULL,5124963,NULL,0,0,'2025-03-21 08:24:35','2025-03-21 08:24:35','2025-03-21 08:24:35'),(172,1,6,2,'infocom_slide01.webp','image',NULL,895,1299,34492,NULL,NULL,NULL,'2025-03-21 08:24:41','2025-03-21 08:24:41','2025-03-21 08:24:41'),(173,1,6,2,'infocom_slide03.webp','image',NULL,896,1298,39480,NULL,NULL,NULL,'2025-03-21 08:24:42','2025-03-21 08:24:42','2025-03-21 08:24:42'),(175,1,6,2,'infocom_slide02.webp','image',NULL,895,1298,40608,NULL,NULL,NULL,'2025-03-21 08:24:42','2025-03-21 08:24:42','2025-03-21 08:24:42'),(179,1,6,2,'short_offline_240822.mp4','video',NULL,NULL,NULL,5124963,NULL,NULL,NULL,'2025-03-21 08:26:00','2025-03-21 08:26:00','2025-03-21 08:26:00'),(199,1,1,2,'MATE_safedrive__next.webp','image',NULL,2880,2049,68494,NULL,0,0,'2025-03-21 08:41:57','2025-03-21 08:41:57','2025-03-21 08:41:57'),(237,1,1,2,'MATE_safedrive__next.webp','image',NULL,2880,2049,68494,NULL,NULL,NULL,'2025-03-21 09:19:09','2025-03-21 09:19:09','2025-03-26 03:20:28'),(240,1,9,2,'mate__slide01.webp','image',NULL,660,1173,41342,NULL,NULL,NULL,'2025-03-21 09:20:18','2025-03-21 09:20:18','2025-03-21 09:20:18'),(241,1,9,2,'mate__slide02.webp','image',NULL,661,1173,43636,NULL,NULL,NULL,'2025-03-21 09:20:36','2025-03-21 09:20:36','2025-03-21 09:20:36'),(242,1,9,2,'mate02.webp','image',NULL,1840,1197,169282,NULL,0,0,'2025-03-21 09:20:36','2025-03-21 09:20:36','2025-03-21 09:20:36'),(243,1,9,2,'mate01-1.webp','image',NULL,1061,1014,18994,NULL,NULL,NULL,'2025-03-21 09:20:36','2025-03-21 09:20:36','2025-03-21 09:20:36'),(244,1,9,2,'MATE_TOP-1.webp','image',NULL,2880,2050,482076,NULL,0,0,'2025-03-21 09:20:37','2025-03-21 09:20:37','2025-03-21 09:20:37'),(245,1,9,2,'mate__slide04.webp','image',NULL,660,1172,34310,NULL,NULL,NULL,'2025-03-21 09:20:37','2025-03-21 09:20:37','2025-03-21 09:20:37'),(246,1,9,2,'mate__slide03.webp','image',NULL,661,1173,58650,NULL,NULL,NULL,'2025-03-21 09:20:37','2025-03-21 09:20:37','2025-03-21 09:20:37'),(247,1,9,2,'MATE_TOP-1.webp','image',NULL,2880,2050,482076,NULL,NULL,NULL,'2025-03-21 09:21:43','2025-03-21 09:21:43','2025-03-21 09:31:01'),(248,1,1,2,'mate02.webp','image',NULL,1840,1197,169282,NULL,0,0,'2025-03-21 09:22:21','2025-03-21 09:22:21','2025-03-25 03:05:30'),(257,NULL,3,2,'lodgeTop.webp','image',NULL,2880,2006,73040,NULL,NULL,NULL,'2025-03-21 09:24:30','2025-03-21 09:24:30','2025-03-21 09:24:30'),(258,1,25,2,'lodgeTop_2025-03-21-092749_wnif.webp','image',NULL,2880,2006,73040,NULL,0,0,'2025-03-24 00:39:56','2025-03-21 09:27:49','2025-03-24 00:39:56'),(260,1,25,2,'lodge__slide01.webp','image',NULL,600,1298,34356,NULL,NULL,NULL,'2025-03-21 09:29:19','2025-03-21 09:29:19','2025-03-21 09:29:19'),(261,1,25,2,'lodge__slide04.webp','image',NULL,600,1299,105178,NULL,NULL,NULL,'2025-03-21 09:29:19','2025-03-21 09:29:19','2025-03-21 09:29:19'),(262,1,25,2,'lodge__slide03.webp','image',NULL,600,1298,60110,NULL,NULL,NULL,'2025-03-21 09:29:20','2025-03-21 09:29:20','2025-03-21 09:29:20'),(263,1,25,2,'lodge__slide02.webp','image',NULL,600,1298,49464,NULL,NULL,NULL,'2025-03-21 09:29:20','2025-03-21 09:29:20','2025-03-21 09:29:20'),(264,1,25,2,'lodgeTop.webp','image',NULL,2880,2006,73040,NULL,0,0,'2025-03-21 09:29:48','2025-03-21 09:29:48','2025-03-25 02:46:38'),(265,1,9,2,'MATE_TOP-1_2025-03-21-093306_lnsw.webp','image',NULL,2880,2050,482076,NULL,NULL,NULL,'2025-03-21 09:33:06','2025-03-21 09:33:06','2025-03-21 09:33:06'),(267,1,9,2,'mate02_2025-03-21-093327_wjgt.webp','image',NULL,1840,1197,169282,NULL,NULL,NULL,'2025-03-21 09:33:27','2025-03-21 09:33:27','2025-03-21 09:33:27'),(288,1,25,2,'lodge__next.webp','image',NULL,658,458,10358,NULL,0,0,'2025-03-24 08:37:49','2025-03-24 08:37:49','2025-03-25 02:46:38'),(291,1,1,2,'lodge__next_2025-03-25-024536_jepx.webp','image',NULL,658,458,10358,NULL,0,0,'2025-03-25 02:45:36','2025-03-25 02:45:36','2025-03-25 02:45:36'),(293,1,25,2,'lodge__next_2025-03-25-024729_dvii.webp','image',NULL,658,458,10358,NULL,0,0,'2025-03-25 02:47:07','2025-03-25 02:47:07','2025-03-25 02:48:44'),(296,1,25,2,'lodgeTop.webp','image',NULL,2880,2006,73040,NULL,NULL,NULL,'2025-03-25 02:48:29','2025-03-25 02:48:29','2025-03-25 02:48:29'),(300,1,1,2,'lodgeTop_2025-03-25-025336_jblp.webp','image',NULL,2880,2006,73040,NULL,NULL,NULL,'2025-03-25 02:53:04','2025-03-25 02:53:04','2025-03-25 05:35:24'),(313,1,1,2,'MATE_TOP-1_2025-03-25-033905_rhde.webp','image',NULL,2880,2050,482076,NULL,NULL,NULL,'2025-03-25 03:38:20','2025-03-25 03:38:20','2025-03-31 00:55:06'),(316,1,25,2,'lodge-video.mp4','video',NULL,NULL,NULL,5555392,NULL,NULL,NULL,'2025-03-25 05:35:20','2025-03-25 05:35:20','2025-03-31 01:53:08');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets_sites` VALUES (6,1,NULL),(7,1,NULL),(8,1,NULL),(9,1,NULL),(10,1,NULL),(11,1,NULL),(12,1,NULL),(13,1,NULL),(19,1,NULL),(22,1,NULL),(23,1,NULL),(24,1,NULL),(37,1,NULL),(94,1,NULL),(96,1,NULL),(98,1,NULL),(107,1,NULL),(109,1,NULL),(111,1,NULL),(112,1,NULL),(113,1,NULL),(136,1,NULL),(147,1,NULL),(151,1,NULL),(153,1,NULL),(155,1,NULL),(157,1,NULL),(158,1,NULL),(159,1,NULL),(164,1,NULL),(171,1,NULL),(172,1,NULL),(173,1,NULL),(175,1,NULL),(179,1,NULL),(199,1,NULL),(237,1,NULL),(240,1,NULL),(241,1,NULL),(242,1,NULL),(243,1,NULL),(244,1,NULL),(245,1,NULL),(246,1,NULL),(247,1,NULL),(248,1,NULL),(257,1,NULL),(258,1,NULL),(260,1,NULL),(261,1,NULL),(262,1,NULL),(263,1,NULL),(264,1,NULL),(265,1,NULL),(267,1,NULL),(288,1,NULL),(291,1,NULL),(293,1,NULL),(296,1,NULL),(300,1,NULL),(313,1,NULL),(316,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (5,1,'postDate','2025-03-17 05:41:47',0,2),(5,1,'slug','2025-03-17 05:41:47',0,2),(5,1,'title','2025-03-17 05:41:07',0,2),(5,1,'uri','2025-03-17 05:41:47',0,2),(27,1,'title','2025-03-17 06:01:09',0,2),(28,1,'title','2025-03-17 06:01:09',0,2),(30,1,'title','2025-03-17 06:01:10',0,2),(31,1,'title','2025-03-17 06:01:10',0,2),(35,1,'postDate','2025-03-17 06:07:45',0,2),(35,1,'slug','2025-03-17 06:06:25',0,2),(35,1,'title','2025-03-31 01:00:00',0,2),(35,1,'uri','2025-03-17 06:06:25',0,2),(36,1,'postDate','2025-03-17 06:07:02',0,2),(36,1,'title','2025-03-17 06:07:43',0,2),(38,1,'postDate','2025-03-17 06:07:29',0,2),(38,1,'title','2025-03-17 06:07:43',0,2),(87,1,'title','2025-03-31 00:57:17',0,2),(88,1,'title','2025-03-31 00:57:17',0,2),(90,1,'title','2025-03-19 03:00:18',0,2),(91,1,'title','2025-03-19 03:00:18',0,2),(93,1,'enabled','2025-03-24 03:26:36',0,2),(93,1,'postDate','2025-03-18 07:14:41',0,2),(93,1,'slug','2025-03-18 07:13:14',0,2),(93,1,'title','2025-03-31 01:00:15',0,2),(93,1,'uri','2025-03-18 07:13:14',0,2),(95,1,'postDate','2025-03-18 07:14:11',0,2),(95,1,'title','2025-03-31 00:57:17',0,2),(97,1,'postDate','2025-03-18 07:14:30',0,2),(97,1,'title','2025-03-31 00:57:17',0,2),(100,1,'title','2025-03-19 03:00:18',0,2),(101,1,'title','2025-03-19 03:00:18',0,2),(106,1,'postDate','2025-03-19 03:13:27',0,2),(106,1,'slug','2025-03-19 03:12:01',0,2),(106,1,'title','2025-03-31 00:59:47',0,2),(106,1,'uri','2025-03-19 03:12:01',0,2),(108,1,'postDate','2025-03-19 03:13:06',0,2),(108,1,'title','2025-03-31 00:57:17',0,2),(110,1,'postDate','2025-03-19 03:13:14',0,2),(110,1,'title','2025-03-31 00:57:17',0,2),(150,1,'postDate','2025-03-21 08:05:14',0,2),(150,1,'slug','2025-03-21 08:03:02',0,2),(150,1,'title','2025-03-31 00:59:09',0,2),(150,1,'uri','2025-03-21 08:03:02',0,2),(152,1,'postDate','2025-03-21 08:04:27',0,2),(152,1,'title','2025-03-31 00:57:17',0,2),(154,1,'postDate','2025-03-21 08:04:41',0,2),(154,1,'title','2025-03-31 00:57:17',0,2),(156,1,'postDate','2025-03-21 08:04:53',0,2),(156,1,'title','2025-03-31 00:57:17',0,2),(256,1,'postDate','2025-03-21 09:29:50',0,2),(256,1,'slug','2025-03-21 09:27:57',0,2),(256,1,'title','2025-03-31 00:58:52',0,2),(256,1,'uri','2025-03-21 09:27:57',0,2),(259,1,'postDate','2025-03-21 09:29:10',0,2),(259,1,'title','2025-03-31 00:57:17',0,2);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (5,1,1,'d38b64a8-3532-46dd-a5dc-3d03063ca3ea','2025-03-17 05:40:49',0,2),(5,1,3,'754fcfae-6760-4762-a1dd-3faa42db0b8a','2025-03-17 05:41:14',0,2),(5,1,4,'9696d0b2-70c2-4fd7-a41e-6e74da803120','2025-03-17 05:41:28',0,2),(5,1,5,'3adf988d-e1cd-4e27-9647-102a2f1a04be','2025-03-17 05:41:38',0,2),(5,1,6,'f6bd2e46-0b52-4ab7-9971-5b5e48d869f0','2025-03-17 05:41:44',0,2),(5,1,8,'8609c98a-4a62-4b2b-8dbd-d9de26b1e8e1','2025-03-17 05:48:38',0,2),(35,1,1,'d38b64a8-3532-46dd-a5dc-3d03063ca3ea','2025-03-17 06:06:16',0,2),(35,1,3,'754fcfae-6760-4762-a1dd-3faa42db0b8a','2025-03-17 06:06:30',0,2),(35,1,4,'9696d0b2-70c2-4fd7-a41e-6e74da803120','2025-03-17 06:06:40',0,2),(35,1,5,'3adf988d-e1cd-4e27-9647-102a2f1a04be','2025-03-17 06:06:46',0,2),(35,1,6,'f6bd2e46-0b52-4ab7-9971-5b5e48d869f0','2025-03-17 07:18:20',0,2),(35,1,7,'f1d01f22-1bc1-4d49-97ff-f8758bcd79d0','2025-03-18 03:59:45',0,2),(35,1,8,'8609c98a-4a62-4b2b-8dbd-d9de26b1e8e1','2025-03-18 03:09:07',0,2),(35,1,8,'d2da8d08-2b24-45c1-99c3-8175108615bd','2025-03-18 05:28:41',0,2),(35,1,9,'d40ab3e9-2f07-47f1-b9f2-822328212844','2025-03-18 03:59:45',0,2),(35,1,11,'684dabbe-4100-4d39-ac6e-9d65f2e8aed0','2025-03-17 07:45:55',0,2),(35,1,14,'6a4fa7d5-02b8-4dad-897a-ad837cba7ab2','2025-03-18 03:59:45',0,2),(35,1,15,'2be26ee9-1be5-4f71-a945-04cac172e11b','2025-03-18 03:59:45',0,2),(35,1,18,'5d2f578c-8fb7-4774-a7d8-9ae82fe5c749','2025-03-19 03:24:11',0,2),(35,1,19,'355ab973-44c6-4128-a52c-6054d3a4d27a','2025-03-21 09:19:11',0,2),(35,1,19,'423351d8-1351-415f-adbf-0d950c548da2','2025-03-21 08:55:05',0,2),(35,1,20,'0db13e7b-c051-4411-aa04-4e0632524a44','2025-03-21 09:11:13',0,2),(35,1,20,'7604e03f-769b-41df-b164-6dbd2592353b','2025-03-21 09:13:29',0,2),(35,1,21,'2a516c28-ca34-4ada-95de-3d4c7841e925','2025-03-25 03:04:44',0,2),(35,1,22,'817435ef-1be5-4ee8-8611-a9261f1bcb02','2025-03-26 03:20:28',0,2),(35,1,23,'ba0c82f9-30d7-4fbc-bc3e-d984926de7a1','2025-03-31 01:00:00',0,2),(36,1,7,'ecd53b5a-047f-4f55-b67b-4fb856ac2534','2025-03-17 06:07:43',0,2),(38,1,9,'e39f40f6-c603-475c-8f3d-66ac1152b540','2025-03-17 06:07:43',0,2),(93,1,1,'d38b64a8-3532-46dd-a5dc-3d03063ca3ea','2025-03-18 07:12:49',0,2),(93,1,3,'754fcfae-6760-4762-a1dd-3faa42db0b8a','2025-03-18 07:13:30',0,2),(93,1,4,'9696d0b2-70c2-4fd7-a41e-6e74da803120','2025-03-18 07:13:40',0,2),(93,1,5,'3adf988d-e1cd-4e27-9647-102a2f1a04be','2025-03-19 03:45:47',0,2),(93,1,8,'d2da8d08-2b24-45c1-99c3-8175108615bd','2025-03-18 07:14:37',0,2),(93,1,11,'684dabbe-4100-4d39-ac6e-9d65f2e8aed0','2025-03-19 03:46:25',0,2),(93,1,18,'5d2f578c-8fb7-4774-a7d8-9ae82fe5c749','2025-03-19 03:24:15',0,2),(93,1,19,'423351d8-1351-415f-adbf-0d950c548da2','2025-03-21 08:27:05',0,2),(93,1,21,'2a516c28-ca34-4ada-95de-3d4c7841e925','2025-03-25 03:03:38',0,2),(93,1,23,'ba0c82f9-30d7-4fbc-bc3e-d984926de7a1','2025-03-31 01:00:15',0,2),(95,1,16,'40236e76-0b57-4872-9713-a653ef4d83f0','2025-03-18 07:14:37',0,2),(97,1,16,'40236e76-0b57-4872-9713-a653ef4d83f0','2025-03-18 07:14:37',0,2),(106,1,1,'d38b64a8-3532-46dd-a5dc-3d03063ca3ea','2025-03-19 03:11:51',0,2),(106,1,3,'754fcfae-6760-4762-a1dd-3faa42db0b8a','2025-03-19 03:12:16',0,2),(106,1,4,'9696d0b2-70c2-4fd7-a41e-6e74da803120','2025-03-19 03:12:26',0,2),(106,1,5,'3adf988d-e1cd-4e27-9647-102a2f1a04be','2025-03-19 03:12:34',0,2),(106,1,8,'d2da8d08-2b24-45c1-99c3-8175108615bd','2025-03-21 08:26:03',0,2),(106,1,18,'5d2f578c-8fb7-4774-a7d8-9ae82fe5c749','2025-03-19 03:16:13',0,2),(106,1,19,'423351d8-1351-415f-adbf-0d950c548da2','2025-03-21 03:55:06',0,2),(106,1,21,'2a516c28-ca34-4ada-95de-3d4c7841e925','2025-03-25 03:05:56',0,2),(106,1,23,'ba0c82f9-30d7-4fbc-bc3e-d984926de7a1','2025-03-31 00:59:47',0,2),(108,1,16,'40236e76-0b57-4872-9713-a653ef4d83f0','2025-03-21 08:26:03',0,2),(110,1,17,'ca1c4dce-e911-4aac-87c4-acef202d13cc','2025-03-21 08:24:47',0,2),(150,1,1,'d38b64a8-3532-46dd-a5dc-3d03063ca3ea','2025-03-21 09:33:29',0,2),(150,1,3,'754fcfae-6760-4762-a1dd-3faa42db0b8a','2025-03-21 08:03:12',0,2),(150,1,4,'9696d0b2-70c2-4fd7-a41e-6e74da803120','2025-03-21 08:03:19',0,2),(150,1,5,'3adf988d-e1cd-4e27-9647-102a2f1a04be','2025-03-21 08:03:27',0,2),(150,1,8,'d2da8d08-2b24-45c1-99c3-8175108615bd','2025-03-21 09:33:29',0,2),(150,1,11,'684dabbe-4100-4d39-ac6e-9d65f2e8aed0','2025-03-21 08:03:35',0,2),(150,1,19,'355ab973-44c6-4128-a52c-6054d3a4d27a','2025-03-25 03:38:26',0,2),(150,1,19,'423351d8-1351-415f-adbf-0d950c548da2','2025-03-21 09:23:01',0,2),(150,1,21,'2a516c28-ca34-4ada-95de-3d4c7841e925','2025-03-25 03:05:30',0,2),(150,1,23,'ba0c82f9-30d7-4fbc-bc3e-d984926de7a1','2025-03-31 00:59:09',0,2),(152,1,16,'40236e76-0b57-4872-9713-a653ef4d83f0','2025-03-21 09:23:01',0,2),(154,1,16,'40236e76-0b57-4872-9713-a653ef4d83f0','2025-03-21 09:33:29',0,2),(156,1,17,'ca1c4dce-e911-4aac-87c4-acef202d13cc','2025-03-21 09:23:01',0,2),(220,1,19,'dcd89f24-0604-45a5-b2c6-947aa96ff816','2025-03-21 09:13:29',0,2),(256,1,1,'d38b64a8-3532-46dd-a5dc-3d03063ca3ea','2025-03-31 02:25:41',0,2),(256,1,3,'754fcfae-6760-4762-a1dd-3faa42db0b8a','2025-03-21 09:28:36',0,2),(256,1,4,'9696d0b2-70c2-4fd7-a41e-6e74da803120','2025-03-21 09:28:46',0,2),(256,1,5,'3adf988d-e1cd-4e27-9647-102a2f1a04be','2025-03-21 09:28:51',0,2),(256,1,8,'d2da8d08-2b24-45c1-99c3-8175108615bd','2025-03-24 08:37:51',0,2),(256,1,11,'684dabbe-4100-4d39-ac6e-9d65f2e8aed0','2025-03-21 09:29:02',0,2),(256,1,19,'355ab973-44c6-4128-a52c-6054d3a4d27a','2025-03-25 02:53:08',0,2),(256,1,21,'2a516c28-ca34-4ada-95de-3d4c7841e925','2025-03-25 03:06:54',0,2),(256,1,23,'ba0c82f9-30d7-4fbc-bc3e-d984926de7a1','2025-03-31 00:55:57',0,2),(256,1,24,'f7ddf1fe-e738-4eb1-8182-f25f3bbf0e8e','2025-03-31 02:25:41',0,2),(259,1,17,'ca1c4dce-e911-4aac-87c4-acef202d13cc','2025-03-21 09:29:25',0,2),(277,1,16,'40236e76-0b57-4872-9713-a653ef4d83f0','2025-03-24 04:21:19',0,2);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,2,0,'最初の下書き',NULL,0,NULL,1),(2,NULL,2,0,'最初の下書き',NULL,0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (5,2,1,NULL,'edit','2025-03-17 05:45:40'),(5,2,1,NULL,'save','2025-03-17 06:04:30'),(35,2,1,NULL,'edit','2025-03-31 00:59:58'),(35,2,1,NULL,'save','2025-03-31 01:00:00'),(93,2,1,NULL,'edit','2025-03-31 01:00:15'),(93,2,1,NULL,'save','2025-03-31 01:00:15'),(106,2,1,NULL,'edit','2025-03-31 00:59:46'),(106,2,1,NULL,'save','2025-03-31 00:59:47'),(150,2,1,NULL,'edit','2025-03-31 00:59:08'),(150,2,1,NULL,'save','2025-03-31 00:59:09'),(256,2,1,NULL,'edit','2025-03-31 02:25:36'),(256,2,1,NULL,'save','2025-03-31 02:25:41'),(316,2,1,NULL,'save','2025-03-31 01:53:19');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (2,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2025-03-17 03:28:22','2025-03-17 03:28:22',NULL,NULL,NULL,'a3d6d7fa-8750-4ba5-872b-0f0e26bd2f63'),(3,NULL,1,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-17 05:35:19','2025-03-17 06:03:23',NULL,'2025-03-17 06:03:23',NULL,'701df2d1-67f5-444f-9ed4-4cbf4c894d8a'),(4,NULL,2,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-17 05:36:17','2025-03-17 06:03:23',NULL,'2025-03-17 06:03:23',NULL,'958b9b25-3405-472c-a1bc-d736ee12a209'),(5,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-17 05:38:26','2025-03-17 06:05:57',NULL,'2025-03-17 06:05:57',NULL,'a2172d2c-1e0f-4732-ac8f-a5fc6d2654d8'),(6,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:17','2025-03-17 05:39:17',NULL,NULL,NULL,'33d38cff-a4bd-4960-b891-7feec8f08546'),(7,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:17','2025-03-17 05:39:17',NULL,NULL,NULL,'98473496-be27-43f0-9dde-9e651f53b92a'),(8,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:17','2025-03-17 05:39:17',NULL,NULL,NULL,'14e144f7-184a-46ec-b5cf-91770584a700'),(9,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:17','2025-03-17 05:39:17',NULL,NULL,NULL,'0590440a-2361-4558-a31d-b181422b51ab'),(10,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:18','2025-03-17 05:39:18',NULL,NULL,NULL,'c9e5c2fd-8f4d-4bb4-bd5e-346ec9ab309b'),(11,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:18','2025-03-17 05:39:18',NULL,NULL,NULL,'a1de2d0b-29ab-4beb-af70-3413b21bbd45'),(12,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-17 05:39:19','2025-03-17 05:39:19',NULL,NULL,NULL,'ba62bed6-98ed-4720-a10f-89ec4a9aa1cb'),(13,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-17 05:40:48','2025-03-17 05:41:07',NULL,NULL,NULL,'264c8302-308a-4ce4-ac39-02508d3ca9e5'),(14,5,NULL,1,4,'craft\\elements\\Entry',1,0,'2025-03-17 05:41:47','2025-03-17 05:41:47',NULL,'2025-03-17 06:05:57',NULL,'ac830769-7382-4f87-bfda-3cf69d122981'),(19,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-17 05:44:35','2025-03-17 06:05:49',NULL,'2025-03-17 06:05:49',NULL,'f239f4d9-c67d-4a65-80df-43de633cabd4'),(22,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-17 05:45:28','2025-03-17 05:48:38',NULL,NULL,NULL,'0a3907f3-8f93-4a11-96f4-0d0667574f36'),(23,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-17 05:45:34','2025-03-17 05:48:38',NULL,NULL,NULL,'dbec7492-3f4b-4bfd-8f22-5c935f009c73'),(24,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-17 05:45:39','2025-03-17 05:48:38',NULL,NULL,NULL,'a31548fe-93e7-4c60-8dc3-335c236e68e6'),(27,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2025-03-17 05:48:38','2025-03-17 06:05:57',NULL,'2025-03-17 06:05:57',1,'ac0b7075-4add-477d-ab33-121126f94f12'),(28,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-03-17 05:48:38','2025-03-17 06:05:57',NULL,'2025-03-17 06:05:57',1,'541758a9-6d97-4a34-9030-3be3e495d6de'),(29,5,NULL,2,4,'craft\\elements\\Entry',1,0,'2025-03-17 05:48:38','2025-03-17 05:48:38',NULL,'2025-03-17 06:05:57',NULL,'25e6ba80-b865-4005-b86d-970e6892ba67'),(30,27,NULL,3,2,'craft\\elements\\Entry',1,0,'2025-03-17 05:48:38','2025-03-17 06:01:10',NULL,'2025-03-17 06:05:57',NULL,'8ec5e169-15f0-4d7f-89a2-2c45985c138d'),(31,28,NULL,4,3,'craft\\elements\\Entry',1,0,'2025-03-17 05:48:38','2025-03-17 06:01:10',NULL,'2025-03-17 06:05:57',NULL,'8ceee17e-72fc-4477-b6e4-dc2725d42b18'),(32,5,NULL,5,4,'craft\\elements\\Entry',1,0,'2025-03-17 06:04:30','2025-03-17 06:04:30',NULL,'2025-03-17 06:05:57',NULL,'7b986deb-f3ff-4e3e-820f-251d9447bfa6'),(33,27,NULL,6,2,'craft\\elements\\Entry',1,0,'2025-03-17 06:01:09','2025-03-17 06:04:30',NULL,'2025-03-17 06:05:57',NULL,'cf270e25-f0d0-483e-a858-f92b163e6e4c'),(34,28,NULL,7,3,'craft\\elements\\Entry',1,0,'2025-03-17 06:01:09','2025-03-17 06:04:30',NULL,'2025-03-17 06:05:57',NULL,'855e197f-e03a-48bf-9cd3-ae6b63e837dd'),(35,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-17 06:05:59','2025-03-31 01:00:00',NULL,NULL,NULL,'a18543f1-a7f3-4e55-b8dc-bff0e59cfbc0'),(36,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2025-03-17 06:07:02','2025-03-17 06:07:43',NULL,'2025-03-18 03:58:42',NULL,'e695c802-f43e-4baf-bde5-c9fc35a02d8b'),(37,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-17 06:07:22','2025-03-17 06:07:22',NULL,NULL,NULL,'5768506d-85df-4c5f-b469-5d549ffd54f3'),(38,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-03-17 06:07:28','2025-03-18 03:02:21',NULL,'2025-03-18 03:02:21',NULL,'58e21ba5-af29-4145-9bd0-dd9fb4de3e54'),(39,35,NULL,8,4,'craft\\elements\\Entry',1,0,'2025-03-17 06:07:45','2025-03-17 06:07:45',NULL,NULL,NULL,'48f38951-f29c-4e4a-9aca-72f9ca8e742f'),(40,36,NULL,9,2,'craft\\elements\\Entry',1,0,'2025-03-17 06:07:43','2025-03-17 06:07:45',NULL,NULL,NULL,'464b98c5-9bbc-4716-a63b-47553a5e83de'),(41,38,NULL,10,3,'craft\\elements\\Entry',1,0,'2025-03-17 06:07:43','2025-03-17 06:07:45',NULL,'2025-03-18 03:02:21',NULL,'2e41cce1-6b94-49d8-9dc3-22badcae2b0a'),(42,35,NULL,11,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:11:56','2025-03-17 07:11:56',NULL,NULL,NULL,'841eac58-fc00-47c6-b943-b63ec566e860'),(43,35,NULL,12,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:12:06','2025-03-17 07:12:06',NULL,NULL,NULL,'dfe518ee-b5c5-443a-a8ae-9eb506276a00'),(45,35,NULL,13,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:13:17','2025-03-17 07:13:17',NULL,NULL,NULL,'f4d35cde-d04b-4fd3-be00-0d7d87b562f4'),(46,35,NULL,14,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:13:23','2025-03-17 07:13:23',NULL,NULL,NULL,'0e46be9f-92bf-4dda-9bf9-b062eb6b4268'),(48,35,NULL,15,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:14:05','2025-03-17 07:14:05',NULL,NULL,NULL,'19542f94-61b9-4eeb-af73-b94216bbbdee'),(50,35,NULL,16,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:15:00','2025-03-17 07:15:00',NULL,NULL,NULL,'8cf6c21b-37f8-4e4d-bf14-266ddccb5bf8'),(52,35,NULL,17,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:18:20','2025-03-17 07:18:20',NULL,NULL,NULL,'f489ca46-5ca1-4821-9ee6-20d10f45a1ef'),(53,35,NULL,18,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:28:18','2025-03-17 07:28:18',NULL,NULL,NULL,'1a96a1b5-02ce-4c93-b15c-b4324a0059f7'),(54,35,NULL,19,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:44:26','2025-03-17 07:44:26',NULL,NULL,NULL,'e9dd22b9-9ac7-4e11-8ba6-bd9a17efd4de'),(56,35,NULL,20,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:45:55','2025-03-17 07:45:55',NULL,NULL,NULL,'3b5e9743-e412-42f0-ad1c-a58c1631da96'),(58,35,NULL,21,4,'craft\\elements\\Entry',1,0,'2025-03-17 07:58:25','2025-03-17 07:58:25',NULL,NULL,NULL,'a2921b29-02a2-4b88-aa42-114c5803f4ae'),(60,35,NULL,22,4,'craft\\elements\\Entry',1,0,'2025-03-17 08:00:00','2025-03-17 08:00:00',NULL,NULL,NULL,'a1ad8a1d-218a-41d4-b77a-4cebeabea976'),(61,35,NULL,23,4,'craft\\elements\\Entry',1,0,'2025-03-17 08:51:12','2025-03-17 08:51:12',NULL,NULL,NULL,'b9da5293-5725-4005-9cd8-d8579df914bc'),(67,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:02:21',NULL,'2025-03-18 03:58:33',NULL,'6ae5ccd4-c2e9-4078-84a2-eb8dd7eeffb1'),(68,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:09:07',NULL,'2025-03-18 03:09:07',NULL,'4c67d85d-bb41-470f-aa7a-33babd8340ab'),(69,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:09:07',NULL,'2025-03-18 03:09:07',NULL,'9b189e13-da5c-4592-a61a-480d73b7e1f3'),(70,35,NULL,24,4,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:02:21',NULL,NULL,NULL,'bdaf79d7-61f2-4fa1-be42-111f485c5b31'),(71,67,NULL,25,3,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:02:21',NULL,NULL,NULL,'5e6053a8-c031-4a28-89e6-309f1ccf7756'),(72,68,NULL,26,3,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:02:21',NULL,'2025-03-18 03:09:07',NULL,'3439b581-ff12-4a53-b187-53a3cfdcc16a'),(73,69,NULL,27,3,'craft\\elements\\Entry',1,0,'2025-03-18 03:02:21','2025-03-18 03:02:21',NULL,'2025-03-18 03:09:07',NULL,'a75aeaab-85bf-4733-bb43-a8603010c9ee'),(77,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2025-03-18 03:09:07','2025-03-18 03:09:07',NULL,'2025-03-18 03:58:36',NULL,'09ee24d5-b1df-4b1e-af74-f45d54fe3a0a'),(78,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2025-03-18 03:09:07','2025-03-18 03:09:07',NULL,'2025-03-18 03:58:38',NULL,'29f32f84-c3e2-440e-83a8-83dcea3636d7'),(79,35,NULL,28,4,'craft\\elements\\Entry',1,0,'2025-03-18 03:09:07','2025-03-18 03:09:07',NULL,NULL,NULL,'5e2503db-d0db-490d-a08a-027e49691205'),(80,77,NULL,29,6,'craft\\elements\\Entry',1,0,'2025-03-18 03:09:07','2025-03-18 03:09:07',NULL,NULL,NULL,'bcde14b8-ac93-4f58-ac94-4c0a2cd6e5cf'),(81,78,NULL,30,7,'craft\\elements\\Entry',1,0,'2025-03-18 03:09:07','2025-03-18 03:09:07',NULL,NULL,NULL,'cdc88fc4-04b9-4d05-a6df-bf78ce549f51'),(83,35,NULL,31,4,'craft\\elements\\Entry',1,0,'2025-03-18 03:59:45','2025-03-18 03:59:45',NULL,NULL,NULL,'ce6fd829-dd76-4e20-943f-41a65c3e55db'),(87,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-18 05:28:41','2025-03-31 00:57:17',NULL,NULL,NULL,'24871f81-1596-4c41-af69-2ef92952ae7e'),(88,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-03-18 05:28:41','2025-03-31 00:57:17',NULL,NULL,NULL,'29c901db-f890-4c2e-ae8f-bb3f47e0639b'),(89,35,NULL,32,4,'craft\\elements\\Entry',1,0,'2025-03-18 05:28:41','2025-03-18 05:28:41',NULL,NULL,NULL,'79c9228d-32b5-4fa3-8532-5942bb7091e5'),(90,87,NULL,33,8,'craft\\elements\\Entry',1,0,'2025-03-18 05:28:41','2025-03-19 03:00:18',NULL,NULL,NULL,'ed0bde03-0579-446b-b3e0-9e245e239f5d'),(91,88,NULL,34,9,'craft\\elements\\Entry',1,0,'2025-03-18 05:28:41','2025-03-19 03:00:18',NULL,NULL,NULL,'bc25bff4-3d46-4a22-a94f-337247e979ba'),(92,35,NULL,35,4,'craft\\elements\\Entry',1,0,'2025-03-18 05:29:26','2025-03-18 05:29:26',NULL,NULL,NULL,'25ad600a-e8cd-4e8b-b551-2d93e69e5069'),(93,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-18 07:12:29','2025-03-31 01:00:15',NULL,NULL,NULL,'f453df45-4db4-49fc-90c1-a8220140e551'),(94,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-18 07:12:48','2025-03-31 00:55:06',NULL,NULL,NULL,'f57d5912-2758-4c64-99f5-d02117adbfa7'),(95,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-18 07:14:11','2025-03-31 00:57:17',NULL,NULL,NULL,'179e5d9f-8e9a-4a77-bb17-64e6cc21a89a'),(96,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-18 07:14:27','2025-03-18 07:15:12',NULL,NULL,NULL,'94ac94ae-5d94-49f8-8635-5301940e5756'),(97,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-18 07:14:30','2025-03-31 00:57:17',NULL,NULL,NULL,'707b4bd4-3633-4a96-9c78-f74b27aadab0'),(98,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-18 07:14:37','2025-03-18 07:15:12',NULL,NULL,NULL,'54084987-934f-4e7d-835e-780a6ab1e3a0'),(99,93,NULL,36,4,'craft\\elements\\Entry',1,0,'2025-03-18 07:14:41','2025-03-18 07:14:41',NULL,NULL,NULL,'f89d8233-acba-4247-b770-044e91651954'),(100,95,NULL,37,8,'craft\\elements\\Entry',1,0,'2025-03-18 07:14:37','2025-03-19 03:00:18',NULL,NULL,NULL,'fe2739a9-09b4-48f1-82aa-41c8b21e91bc'),(101,97,NULL,38,8,'craft\\elements\\Entry',1,0,'2025-03-18 07:14:37','2025-03-19 03:00:18',NULL,NULL,NULL,'af4c5573-f704-4334-8477-dd2b7123f7f4'),(103,93,NULL,39,4,'craft\\elements\\Entry',1,0,'2025-03-18 07:15:25','2025-03-18 07:15:25',NULL,NULL,NULL,'d829f364-386f-443b-9de3-dff10c3a78ad'),(104,NULL,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2025-03-19 02:48:35','2025-03-19 02:48:35',NULL,NULL,NULL,'a9a4111b-5964-4406-9e08-5876e2ad48fc'),(105,104,NULL,40,10,'craft\\elements\\Entry',1,0,'2025-03-19 02:48:35','2025-03-19 02:48:35',NULL,NULL,NULL,'0111abcd-4e51-4db1-994a-61f0559bc9f7'),(106,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:06:57','2025-03-31 00:59:47',NULL,NULL,NULL,'2d90f641-a9f6-4bc8-9c9b-09a28624daf8'),(107,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-19 03:11:50','2025-03-19 03:12:01',NULL,NULL,NULL,'4bf7f0f0-6b51-48e7-9e30-e536fe265c20'),(108,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-19 03:13:05','2025-03-31 00:57:17',NULL,NULL,NULL,'b49745e4-6c07-499d-ab8a-94d278fd5403'),(109,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-19 03:13:11','2025-03-21 08:06:23',NULL,'2025-03-21 08:06:23',NULL,'c778eec2-d967-4b75-8c33-6d0d8a686be5'),(110,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-03-19 03:13:13','2025-03-31 00:57:17',NULL,NULL,NULL,'cda1e9e3-2205-4a2a-92a2-dabeae040df3'),(111,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-19 03:13:21','2025-03-21 08:10:51',NULL,'2025-03-21 08:10:51',NULL,'7ece6db4-46ce-4d8a-9e1d-f07b507a2066'),(112,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-19 03:13:21','2025-03-21 08:10:51',NULL,'2025-03-21 08:10:51',NULL,'63b5761a-c182-40f2-bf47-b680dc735ad3'),(113,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-19 03:13:21','2025-03-21 08:10:51',NULL,'2025-03-21 08:10:51',NULL,'27365231-61d2-494b-a02a-acd50fdf97bf'),(114,106,NULL,41,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:13:27','2025-03-19 03:13:27',NULL,NULL,NULL,'34c08ef2-8466-4fa5-a3e0-31e69485dbc8'),(115,108,NULL,42,8,'craft\\elements\\Entry',1,0,'2025-03-19 03:13:25','2025-03-19 03:13:27',NULL,NULL,NULL,'d2c5c266-0f40-443b-933a-4b706b72ebe4'),(116,110,NULL,43,9,'craft\\elements\\Entry',1,0,'2025-03-19 03:13:25','2025-03-19 03:13:27',NULL,NULL,NULL,'ed8ebec0-04d3-4070-ab24-532d1d25da90'),(118,93,NULL,44,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:15:53','2025-03-19 03:15:53',NULL,NULL,NULL,'a3e1d840-0958-4b61-a394-8cf897d5a72d'),(119,95,NULL,45,8,'craft\\elements\\Entry',1,0,'2025-03-19 03:00:18','2025-03-19 03:15:53',NULL,NULL,NULL,'9594d41f-09f2-4119-9b52-1c1a04a47311'),(120,97,NULL,46,8,'craft\\elements\\Entry',1,0,'2025-03-19 03:00:18','2025-03-19 03:15:53',NULL,NULL,NULL,'fb0ef578-5249-43cf-bb6d-53df9e17b62d'),(122,35,NULL,47,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:15:58','2025-03-19 03:15:58',NULL,NULL,NULL,'1a00204f-8319-4a42-be20-b2689f3acb69'),(123,87,NULL,48,8,'craft\\elements\\Entry',1,0,'2025-03-19 03:00:18','2025-03-19 03:15:58',NULL,NULL,NULL,'5c12321d-3b6b-44cc-8dd2-543ebcfe0b45'),(124,88,NULL,49,9,'craft\\elements\\Entry',1,0,'2025-03-19 03:00:18','2025-03-19 03:15:58',NULL,NULL,NULL,'da8f3798-b9ab-43d1-8d18-9256a171a912'),(126,106,NULL,50,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:16:13','2025-03-19 03:16:13',NULL,NULL,NULL,'ac655bf7-714a-4adf-9255-ffb620ebd8dd'),(127,106,NULL,51,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:17:18','2025-03-19 03:17:18',NULL,NULL,NULL,'ceecef95-66f5-49fd-a437-a6db5a9b7524'),(129,35,NULL,52,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:24:10','2025-03-19 03:24:10',NULL,NULL,NULL,'03178f5c-46bc-4119-a6c4-2285fc64ff3d'),(131,93,NULL,53,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:24:15','2025-03-19 03:24:15',NULL,NULL,NULL,'abade855-0fb7-4aeb-a28d-665ce66c3039'),(133,93,NULL,54,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:45:47','2025-03-19 03:45:47',NULL,NULL,NULL,'cf225614-a502-4c5a-b6f3-312adc9a8bd4'),(135,93,NULL,55,4,'craft\\elements\\Entry',1,0,'2025-03-19 03:46:25','2025-03-19 03:46:25',NULL,NULL,NULL,'f3ca48f1-6ff7-48ec-acea-67e82f166c12'),(136,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 03:55:03','2025-03-31 00:55:06',NULL,NULL,NULL,'a1ca8b8c-1c69-4bcc-befd-e8837cfedff9'),(138,106,NULL,56,4,'craft\\elements\\Entry',1,0,'2025-03-21 03:55:06','2025-03-21 03:55:06',NULL,NULL,NULL,'34a7e663-8337-4afe-b95d-c0815bc22758'),(141,35,NULL,57,4,'craft\\elements\\Entry',1,0,'2025-03-21 03:55:45','2025-03-21 03:55:45',NULL,NULL,NULL,'4acdab82-a005-45ed-bb1f-4a2570abacdb'),(144,93,NULL,58,4,'craft\\elements\\Entry',1,0,'2025-03-21 03:56:08','2025-03-21 03:56:08',NULL,NULL,NULL,'9e97a515-a7d1-451a-b12a-6f411be7ce66'),(147,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 04:11:02','2025-03-21 08:25:41',NULL,'2025-03-21 08:25:41',NULL,'23147e60-892f-4b6b-8406-a1e2c3483652'),(148,106,NULL,59,4,'craft\\elements\\Entry',1,0,'2025-03-21 04:11:04','2025-03-21 04:11:04',NULL,NULL,NULL,'a5c83c7e-e951-4906-b9b8-1a985f97bf17'),(149,108,NULL,60,8,'craft\\elements\\Entry',1,0,'2025-03-21 04:11:04','2025-03-21 04:11:04',NULL,NULL,NULL,'908f9f98-1fcd-4ed3-b29f-9c0650a69cce'),(150,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:02:25','2025-03-31 00:59:09',NULL,NULL,NULL,'7af2dae3-cfc5-4109-9615-a2249edf02e3'),(151,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:02:50','2025-03-21 09:20:08',NULL,'2025-03-21 09:20:08',NULL,'bc9ef7d3-d62c-4e3c-b95e-06aefe179df9'),(152,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-21 08:04:27','2025-03-31 00:57:17',NULL,NULL,NULL,'538b33c5-4551-44c8-9269-cf7f362398a2'),(153,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:04:35','2025-03-21 08:26:41',NULL,'2025-03-21 08:26:41',NULL,'8484ae61-853d-4653-ae58-722ff6877683'),(154,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-21 08:04:40','2025-03-31 00:57:17',NULL,NULL,NULL,'10cb1a5c-7f97-43c1-a229-cd8b1e4a831b'),(155,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:04:50','2025-03-21 08:26:41',NULL,'2025-03-21 08:26:41',NULL,'6e0729ba-eda5-4386-9fb0-c05ce3a9f01e'),(156,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-03-21 08:04:53','2025-03-31 00:57:17',NULL,NULL,NULL,'fb79c20f-de48-48ab-a967-cfdf8de80992'),(157,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:05:02','2025-03-21 08:10:42',NULL,'2025-03-21 08:10:42',NULL,'343d481f-68a2-4059-a2a4-50bc5ce242c4'),(158,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:05:08','2025-03-21 08:10:42',NULL,'2025-03-21 08:10:42',NULL,'5af6c43e-3fde-4ca3-bc28-50868dda7870'),(159,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:05:08','2025-03-21 08:10:42',NULL,'2025-03-21 08:10:42',NULL,'ce31c22d-5378-4b91-b5f3-8447046991c8'),(160,150,NULL,61,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:05:14','2025-03-21 08:05:14',NULL,NULL,NULL,'d65f3e6d-b386-4767-8541-c6510cbc84f4'),(161,152,NULL,62,8,'craft\\elements\\Entry',1,0,'2025-03-21 08:05:08','2025-03-21 08:05:14',NULL,NULL,NULL,'58de534b-7cba-4097-a089-c808f03e99df'),(162,154,NULL,63,8,'craft\\elements\\Entry',1,0,'2025-03-21 08:05:08','2025-03-21 08:05:14',NULL,NULL,NULL,'4ba15ade-696b-41d9-8990-a25a97187592'),(163,156,NULL,64,9,'craft\\elements\\Entry',1,0,'2025-03-21 08:05:08','2025-03-21 08:05:14',NULL,NULL,NULL,'bfa77afe-e365-4622-b984-5e2e4378999f'),(164,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:06:00','2025-03-21 08:10:42',NULL,'2025-03-21 08:10:42',NULL,'9134086c-b169-453b-8da1-1705376c7823'),(167,150,NULL,65,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:06:04','2025-03-21 08:06:04',NULL,NULL,NULL,'55c5daea-cc02-4e7e-9672-7f74e00c25ea'),(168,156,NULL,66,9,'craft\\elements\\Entry',1,0,'2025-03-21 08:06:04','2025-03-21 08:06:04',NULL,NULL,NULL,'cb4312fd-d3e1-48d3-aa1d-cfb6388d6fb3'),(171,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:24:35','2025-03-21 08:25:48',NULL,'2025-03-21 08:25:48',NULL,'46e160ce-6259-44b1-be32-e0b071e835ef'),(172,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:24:41','2025-03-21 08:24:41',NULL,NULL,NULL,'60ef8e13-ee8d-4830-bfb7-87c51e6c2fe4'),(173,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:24:41','2025-03-21 08:24:41',NULL,NULL,NULL,'dd28bda4-7b71-4f25-af79-f8382f229e16'),(175,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:24:42','2025-03-21 08:24:42',NULL,NULL,NULL,'cfd0828d-9549-48e5-978b-dce7d64ce9ce'),(176,106,NULL,67,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:24:47','2025-03-21 08:24:47',NULL,NULL,NULL,'2f21efff-4fcc-4100-a626-c2fc925ed3a2'),(177,108,NULL,68,8,'craft\\elements\\Entry',1,0,'2025-03-21 08:24:47','2025-03-21 08:24:47',NULL,NULL,NULL,'d897dde7-b22b-4754-a6be-8c74f85a0949'),(178,110,NULL,69,9,'craft\\elements\\Entry',1,0,'2025-03-21 08:24:47','2025-03-21 08:24:47',NULL,NULL,NULL,'3ee6e81a-0680-4496-98a6-afa49b78dfaa'),(179,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:26:00','2025-03-21 08:26:00',NULL,NULL,NULL,'60696370-b486-4ee0-9248-af9f2248bff2'),(182,106,NULL,70,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:26:03','2025-03-21 08:26:03',NULL,NULL,NULL,'04d43b35-1423-4e1f-8dd5-3444b2dcd6e7'),(183,108,NULL,71,8,'craft\\elements\\Entry',1,0,'2025-03-21 08:26:03','2025-03-21 08:26:03',NULL,NULL,NULL,'bf8c29ba-7886-41e8-b40c-954cabcb5c9c'),(185,93,NULL,72,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:27:05','2025-03-21 08:27:05',NULL,NULL,NULL,'aff8f65c-6f39-4225-9281-9e51e542d684'),(189,35,NULL,73,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:30:40','2025-03-21 08:30:41',NULL,NULL,NULL,'84458f88-ab70-484b-bffb-0e75fb509533'),(192,35,NULL,74,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:31:46','2025-03-21 08:31:46',NULL,NULL,NULL,'f049af7f-4f58-4855-9f26-c7745f0f6a06'),(195,35,NULL,75,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:36:24','2025-03-21 08:36:24',NULL,NULL,NULL,'4d28ebab-6276-409b-9528-260cd9d2195d'),(198,35,NULL,76,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:41:14','2025-03-21 08:41:14',NULL,NULL,NULL,'a5f32c95-ccf3-4d08-8183-c0ea4828b9f4'),(199,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 08:41:56','2025-03-21 08:42:41',NULL,'2025-03-21 08:42:41',NULL,'2e68d0ad-552f-48bd-b8e1-891f748f85e6'),(201,35,NULL,77,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:41:59','2025-03-21 08:41:59',NULL,NULL,NULL,'41d78683-2213-44b9-9a8b-70ef468dac66'),(204,35,NULL,78,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:47:47','2025-03-21 08:47:47',NULL,NULL,NULL,'29598fb7-584a-4ea7-bd19-613e136a46a0'),(207,35,NULL,79,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:48:51','2025-03-21 08:48:51',NULL,NULL,NULL,'fbcbf513-75fb-44bf-b5a4-065dd78ed2e6'),(210,35,NULL,80,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:50:00','2025-03-21 08:50:00',NULL,NULL,NULL,'39e1ed9b-9296-4a0c-948c-ff27f7ab95ff'),(213,35,NULL,81,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:52:24','2025-03-21 08:52:24',NULL,NULL,NULL,'f940385e-4d58-4d08-a3dd-591ee73cfe54'),(216,35,NULL,82,4,'craft\\elements\\Entry',1,0,'2025-03-21 08:55:05','2025-03-21 08:55:05',NULL,NULL,NULL,'c8272fe1-a4ed-4be0-8f3d-8d5348d74027'),(220,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2025-03-21 09:11:13','2025-03-21 09:13:29',NULL,'2025-03-21 09:15:25',NULL,'55d5973c-198a-4732-b934-6380a985291c'),(221,35,NULL,83,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:11:13','2025-03-21 09:11:13',NULL,NULL,NULL,'577491af-0f76-40d8-a56d-2118564a2c28'),(222,220,NULL,84,11,'craft\\elements\\Entry',1,0,'2025-03-21 09:11:13','2025-03-21 09:11:13',NULL,NULL,NULL,'2284e4f2-463f-4b03-8431-30c18b9b5872'),(226,35,NULL,85,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:13:29','2025-03-21 09:13:29',NULL,NULL,NULL,'d46da10b-5c65-4117-bc91-5218a02810ce'),(227,220,NULL,86,11,'craft\\elements\\Entry',1,0,'2025-03-21 09:13:29','2025-03-21 09:13:29',NULL,NULL,NULL,'1854202d-617c-4874-85c7-781947ee8b9b'),(230,35,NULL,87,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:16:48','2025-03-21 09:16:48',NULL,NULL,NULL,'8688fe5e-bb0a-48f5-8c66-5ff8784ffcfe'),(233,35,NULL,88,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:17:44','2025-03-21 09:17:44',NULL,NULL,NULL,'aa32208d-5067-4648-b3bc-5071e00df3b9'),(236,35,NULL,89,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:18:39','2025-03-21 09:18:39',NULL,NULL,NULL,'b12de6bc-2a2d-4e87-bb55-b2dc10b2c55f'),(237,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:19:09','2025-03-26 03:20:28',NULL,NULL,NULL,'f7899692-55cc-42a3-b8ae-96569d519ba2'),(239,35,NULL,90,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:19:11','2025-03-21 09:19:11',NULL,NULL,NULL,'07394580-e389-41d0-a4c2-671ce0aeb4de'),(240,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:18','2025-03-21 09:20:18',NULL,NULL,NULL,'666bbd47-d2ea-4e56-bb90-129318bd47cd'),(241,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:36','2025-03-21 09:20:36',NULL,NULL,NULL,'13bd8bb2-8a48-4327-9ac3-8f362fc38d35'),(242,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:36','2025-03-21 09:30:56',NULL,'2025-03-21 09:30:56',NULL,'82548cc5-c2fb-48f9-949e-acad597a381f'),(243,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:36','2025-03-21 09:20:36',NULL,NULL,NULL,'e612c21d-57fa-49bc-a8e0-6b57aacc3b86'),(244,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:36','2025-03-21 09:31:01',NULL,'2025-03-21 09:31:01',NULL,'d18a8049-c4aa-4876-a13c-3dd199e67715'),(245,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:37','2025-03-21 09:20:37',NULL,NULL,NULL,'a5d6a86f-b231-4e5b-91e4-21d52efd614a'),(246,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:20:37','2025-03-21 09:20:37',NULL,NULL,NULL,'0c426db3-a4e5-4000-9cc3-b4df6144db2a'),(247,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:21:42','2025-03-21 09:31:01',NULL,NULL,NULL,'aea36285-f1ba-4193-b321-2741402c99c5'),(248,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:22:21','2025-03-25 03:38:50',NULL,'2025-03-25 03:38:50',NULL,'1fe9543e-eee2-4f85-b03b-ea13c658bcb7'),(252,150,NULL,91,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:23:01','2025-03-21 09:23:01',NULL,NULL,NULL,'15aec242-4a3b-4eb9-b21e-5ab106835b01'),(253,152,NULL,92,8,'craft\\elements\\Entry',1,0,'2025-03-21 09:23:01','2025-03-21 09:23:01',NULL,NULL,NULL,'5b8aae35-8ce2-48ad-bd38-2652b122bf36'),(254,154,NULL,93,8,'craft\\elements\\Entry',1,0,'2025-03-21 09:23:01','2025-03-21 09:23:01',NULL,NULL,NULL,'0cec9ff6-e79b-4364-89ef-a7fc2e15c900'),(255,156,NULL,94,9,'craft\\elements\\Entry',1,0,'2025-03-21 09:23:01','2025-03-21 09:23:01',NULL,NULL,NULL,'327d2659-91a8-4bed-8b7c-e5d8d4370f5e'),(256,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:24:15','2025-03-31 02:25:41',NULL,NULL,NULL,'349a8f61-6e41-47f7-bba4-4786820cda69'),(257,NULL,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2025-03-21 09:24:30','2025-03-21 09:24:30',NULL,NULL,NULL,'0e78e4a0-cfc4-4755-8ae6-36c3f954a556'),(258,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:27:49','2025-03-25 02:48:01',NULL,'2025-03-25 02:48:01',NULL,'e48ad7f9-ae9b-4a50-bdf1-1881c2250277'),(259,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-03-21 09:29:10','2025-03-31 00:57:17',NULL,NULL,NULL,'743c08a0-0b1b-4264-a1b0-8bf68b4d4915'),(260,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:29:19','2025-03-21 09:29:19',NULL,NULL,NULL,'d72660b1-40ce-466f-9b71-480ca7c4ee5b'),(261,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:29:19','2025-03-21 09:29:19',NULL,NULL,NULL,'16822ae4-7066-457a-b50f-15971e4cffdf'),(262,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:29:19','2025-03-21 09:29:19',NULL,NULL,NULL,'befe1bcf-bbf1-405b-913d-42ca01cfd278'),(263,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:29:20','2025-03-21 09:29:20',NULL,NULL,NULL,'099c478b-568b-45aa-9ec9-a79929017903'),(264,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:29:48','2025-03-25 02:48:15',NULL,'2025-03-25 02:48:15',NULL,'61a92f61-52f7-4bc2-9f2c-694c8f566cc6'),(265,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:33:06','2025-03-21 09:33:06',NULL,NULL,NULL,'de0be81f-bea6-44e9-b69e-b04bf5cda097'),(267,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-21 09:33:27','2025-03-21 09:33:27',NULL,NULL,NULL,'a237f3eb-f18b-4cd9-afed-c86d27724f51'),(269,150,NULL,95,4,'craft\\elements\\Entry',1,0,'2025-03-21 09:33:29','2025-03-21 09:33:29',NULL,NULL,NULL,'c8e47fbd-92b4-460b-ae52-94d3e0a2bcec'),(270,154,NULL,96,8,'craft\\elements\\Entry',1,0,'2025-03-21 09:33:29','2025-03-21 09:33:29',NULL,NULL,NULL,'214b2ef6-9a7d-43c0-b5ea-c060583efca7'),(271,256,NULL,97,4,'craft\\elements\\Entry',1,0,'2025-03-24 00:39:56','2025-03-24 00:39:56',NULL,NULL,NULL,'71248c36-591a-406e-892c-698ebd6d56b8'),(272,259,NULL,98,9,'craft\\elements\\Entry',1,0,'2025-03-21 09:29:25','2025-03-24 00:39:56',NULL,NULL,NULL,'61ad3a87-9ac1-4b79-b8c4-1a5b5a14b004'),(273,93,NULL,99,4,'craft\\elements\\Entry',0,0,'2025-03-24 00:55:27','2025-03-24 00:55:27',NULL,NULL,NULL,'4afcb2fb-fa4b-497e-a008-18a2f2be8fd3'),(274,93,NULL,100,4,'craft\\elements\\Entry',1,0,'2025-03-24 03:26:36','2025-03-24 03:26:36',NULL,NULL,NULL,'fae0adbb-19e3-4bcd-8a1f-8589375c2870'),(277,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-03-24 04:19:42','2025-03-24 04:21:57',NULL,'2025-03-24 04:21:57',NULL,'1618a408-d4b6-4880-90ef-10c7c57ac052'),(278,256,NULL,101,4,'craft\\elements\\Entry',1,0,'2025-03-24 04:19:42','2025-03-24 04:19:42',NULL,NULL,NULL,'16c0e251-6595-4744-861e-5bc3364fb339'),(279,277,NULL,102,8,'craft\\elements\\Entry',1,0,'2025-03-24 04:19:42','2025-03-24 04:19:42',NULL,'2025-03-24 04:21:57',NULL,'f4f17d27-3cf2-4caa-aae7-aaefd73d9058'),(282,256,NULL,103,4,'craft\\elements\\Entry',1,0,'2025-03-24 04:21:19','2025-03-24 04:21:19',NULL,NULL,NULL,'52fd78a0-eb55-487e-b0df-ad6a9cfae49e'),(283,277,NULL,104,8,'craft\\elements\\Entry',1,0,'2025-03-24 04:21:19','2025-03-24 04:21:19',NULL,'2025-03-24 04:21:57',NULL,'7a7532dd-3a57-4b98-be03-1d611e91d3e4'),(285,256,NULL,105,4,'craft\\elements\\Entry',1,0,'2025-03-24 04:21:57','2025-03-24 04:21:57',NULL,NULL,NULL,'3ab11469-df55-44c1-b48e-4e454ffbb33a'),(288,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-24 08:37:49','2025-03-25 02:47:53',NULL,'2025-03-25 02:47:53',NULL,'8f3683ff-a9b4-4278-9a9b-dddf50d35c4c'),(289,256,NULL,106,4,'craft\\elements\\Entry',1,0,'2025-03-24 08:37:51','2025-03-24 08:37:51',NULL,NULL,NULL,'e36aff4f-8257-4ce1-8aed-c2a2ea0b385e'),(291,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-25 02:45:36','2025-03-25 02:46:43',NULL,'2025-03-25 02:46:43',NULL,'79db9cdc-5027-4dc8-be39-96801888b339'),(292,256,NULL,107,4,'craft\\elements\\Entry',1,0,'2025-03-25 02:45:55','2025-03-25 02:45:55',NULL,NULL,NULL,'f2d5abb2-9381-4361-971d-45e4681647c1'),(293,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-25 02:47:07','2025-03-25 02:53:52',NULL,'2025-03-25 02:53:52',NULL,'cd1fb66c-2dfa-4763-a880-99b0a82d507d'),(295,256,NULL,108,4,'craft\\elements\\Entry',1,0,'2025-03-25 02:47:09','2025-03-25 02:47:09',NULL,NULL,NULL,'c8f1895e-9a2d-4751-b085-d91494ca25d3'),(296,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-25 02:48:28','2025-03-25 02:48:28',NULL,NULL,NULL,'0d7183e5-8e66-4028-8aef-fa66c82a26c9'),(298,256,NULL,109,4,'craft\\elements\\Entry',1,0,'2025-03-25 02:48:31','2025-03-25 02:48:31',NULL,NULL,NULL,'45ee1c4e-0000-4016-a3a9-ebb9f455bcfb'),(300,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-25 02:53:04','2025-03-25 05:35:24',NULL,NULL,NULL,'4c2092d6-7472-489a-802f-4c9ffa3f0ccc'),(301,256,NULL,110,4,'craft\\elements\\Entry',1,0,'2025-03-25 02:53:08','2025-03-25 02:53:08',NULL,NULL,NULL,'236e4608-a34b-490b-9103-414546d8385b'),(303,93,NULL,111,4,'craft\\elements\\Entry',1,0,'2025-03-25 03:03:38','2025-03-25 03:03:38',NULL,NULL,NULL,'926d5b24-dda3-4529-be1e-f4cc74613f61'),(305,35,NULL,112,4,'craft\\elements\\Entry',1,0,'2025-03-25 03:04:44','2025-03-25 03:04:44',NULL,NULL,NULL,'3d1e8d9b-47f4-47db-ab97-116b11e864b3'),(307,150,NULL,113,4,'craft\\elements\\Entry',1,0,'2025-03-25 03:05:30','2025-03-25 03:05:30',NULL,NULL,NULL,'14f61046-c9ef-42b8-893a-7227844ea355'),(309,106,NULL,114,4,'craft\\elements\\Entry',1,0,'2025-03-25 03:05:56','2025-03-25 03:05:56',NULL,NULL,NULL,'b59ae7a0-718a-4194-8a37-4a79da2e70b1'),(311,256,NULL,115,4,'craft\\elements\\Entry',1,0,'2025-03-25 03:06:54','2025-03-25 03:06:54',NULL,NULL,NULL,'79776364-bdd8-45f4-8b6d-13b88656f47c'),(313,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-25 03:38:19','2025-03-31 00:55:06',NULL,NULL,NULL,'a3e225e4-8bb3-46ec-ae72-b77854b12995'),(314,150,NULL,116,4,'craft\\elements\\Entry',1,0,'2025-03-25 03:38:26','2025-03-25 03:38:26',NULL,NULL,NULL,'5e381cfb-d782-4d98-b537-824894a6da85'),(316,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2025-03-25 05:35:20','2025-03-31 01:53:19',NULL,NULL,NULL,'ff37edad-aae8-4fc0-b9e5-15b21555b205'),(317,256,NULL,117,4,'craft\\elements\\Entry',1,0,'2025-03-25 05:35:24','2025-03-25 05:35:24',NULL,NULL,NULL,'639c6a83-bf3f-4b15-9d6a-15c733750ab5'),(319,35,NULL,118,4,'craft\\elements\\Entry',1,0,'2025-03-26 03:20:28','2025-03-26 03:20:28',NULL,NULL,NULL,'626c8f1d-28c5-4489-9fe8-31b2764869ba'),(321,256,NULL,119,4,'craft\\elements\\Entry',1,0,'2025-03-31 00:53:00','2025-03-31 00:53:00',NULL,NULL,NULL,'0db2e6db-6d61-46ce-9f60-ca616fd80050'),(322,256,NULL,120,4,'craft\\elements\\Entry',1,0,'2025-03-31 00:53:05','2025-03-31 00:53:06',NULL,NULL,NULL,'cecb07ca-d147-49b4-b0c8-951187f56b41'),(324,256,NULL,121,4,'craft\\elements\\Entry',1,0,'2025-03-31 00:55:57','2025-03-31 00:55:57',NULL,NULL,NULL,'ef3ff789-71b0-4f25-be3c-264227a6056b'),(325,259,NULL,122,9,'craft\\elements\\Entry',1,0,'2025-03-31 00:55:06','2025-03-31 00:55:57',NULL,NULL,NULL,'bcc552d3-9214-4957-a970-10a3a336a1ce'),(327,256,NULL,123,4,'craft\\elements\\Entry',1,0,'2025-03-31 00:58:52','2025-03-31 00:58:52',NULL,NULL,NULL,'a845bd16-2df0-44a8-b18c-fafc9a852586'),(328,259,NULL,124,9,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 00:58:52',NULL,NULL,NULL,'74dc024d-6484-415d-a4db-f774a86cce87'),(330,150,NULL,125,4,'craft\\elements\\Entry',1,0,'2025-03-31 00:59:09','2025-03-31 00:59:09',NULL,NULL,NULL,'a284127a-7b38-4336-a6d9-779c8b163455'),(331,152,NULL,126,8,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 00:59:09',NULL,NULL,NULL,'edb86736-5c1c-4b19-8168-aa29234b630a'),(332,154,NULL,127,8,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 00:59:09',NULL,NULL,NULL,'5f0d76a5-4508-48a9-9d6a-a9692cab42f1'),(333,156,NULL,128,9,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 00:59:09',NULL,NULL,NULL,'1abe26b1-cdad-4398-a753-437632803315'),(335,106,NULL,129,4,'craft\\elements\\Entry',1,0,'2025-03-31 00:59:47','2025-03-31 00:59:47',NULL,NULL,NULL,'d29c17fa-07ba-4860-965a-2b04a546b443'),(336,108,NULL,130,8,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 00:59:47',NULL,NULL,NULL,'ee6c1bea-b7af-4eb6-bd4d-a154d2114688'),(337,110,NULL,131,9,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 00:59:47',NULL,NULL,NULL,'731c40a4-47dc-463e-941d-f96aee8b20eb'),(339,35,NULL,132,4,'craft\\elements\\Entry',1,0,'2025-03-31 01:00:00','2025-03-31 01:00:00',NULL,NULL,NULL,'ebda14fa-91f8-4360-93b7-cdf7b1d4dae3'),(340,87,NULL,133,8,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 01:00:00',NULL,NULL,NULL,'5d00dcc2-14f9-4fdb-bc86-01cf5d08866d'),(341,88,NULL,134,9,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 01:00:00',NULL,NULL,NULL,'b4935881-1921-4e24-bd8e-0e88aae84e0b'),(343,93,NULL,135,4,'craft\\elements\\Entry',1,0,'2025-03-31 01:00:15','2025-03-31 01:00:15',NULL,NULL,NULL,'46a4f069-ff7c-4a71-8b15-1ed73112e802'),(344,95,NULL,136,8,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 01:00:15',NULL,NULL,NULL,'1bda7790-888c-4bbf-b39f-5dd784bf9620'),(345,97,NULL,137,8,'craft\\elements\\Entry',1,0,'2025-03-31 00:57:17','2025-03-31 01:00:15',NULL,NULL,NULL,'0bd16270-f809-48bf-9760-a51b4c0379a5'),(347,256,NULL,138,4,'craft\\elements\\Entry',1,0,'2025-03-31 02:25:41','2025-03-31 02:25:41',NULL,NULL,NULL,'a8497bb7-4981-4c33-95a9-9d15155e0b20');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES (27,5,1),(28,5,2),(30,29,1),(31,29,2),(33,32,1),(34,32,2),(36,35,1),(38,35,2),(40,39,1),(40,42,1),(40,43,1),(40,45,1),(40,46,1),(40,48,1),(40,50,1),(40,52,1),(40,53,1),(40,54,1),(40,56,1),(40,58,1),(40,60,1),(40,61,1),(40,70,1),(40,79,1),(41,39,2),(41,42,2),(41,43,2),(41,45,2),(41,46,2),(41,48,2),(41,50,2),(41,52,2),(41,53,2),(41,54,2),(41,56,2),(41,58,2),(41,60,2),(41,61,2),(67,35,2),(68,35,3),(69,35,4),(71,70,2),(71,79,2),(72,70,3),(73,70,4),(77,35,3),(78,35,4),(80,79,3),(81,79,4),(87,35,1),(88,35,2),(90,89,1),(90,92,1),(91,89,2),(91,92,2),(95,93,1),(97,93,2),(100,99,1),(100,103,1),(101,99,2),(101,103,2),(108,106,1),(110,106,2),(115,114,1),(115,126,1),(115,127,1),(115,138,1),(116,114,2),(116,126,2),(116,127,2),(116,138,2),(116,148,2),(119,118,1),(119,131,1),(119,133,1),(119,135,1),(119,144,1),(119,185,1),(119,273,1),(119,274,1),(119,303,1),(120,118,2),(120,131,2),(120,133,2),(120,135,2),(120,144,2),(120,185,2),(120,273,2),(120,274,2),(120,303,2),(123,122,1),(123,129,1),(123,141,1),(123,189,1),(123,192,1),(123,195,1),(123,198,1),(123,201,1),(123,204,1),(123,207,1),(123,210,1),(123,213,1),(123,216,1),(123,221,1),(123,226,1),(123,230,1),(123,233,1),(123,236,1),(123,239,1),(123,305,1),(123,319,1),(124,122,2),(124,129,2),(124,141,2),(124,189,2),(124,192,2),(124,195,2),(124,198,2),(124,201,2),(124,204,2),(124,207,2),(124,210,2),(124,213,2),(124,216,2),(124,221,2),(124,226,2),(124,230,2),(124,233,2),(124,236,2),(124,239,2),(124,305,2),(124,319,2),(149,148,1),(152,150,1),(154,150,2),(156,150,3),(161,160,1),(161,167,1),(162,160,2),(162,167,2),(163,160,3),(168,167,3),(177,176,1),(178,176,2),(178,182,2),(178,309,2),(183,182,1),(183,309,1),(220,35,1),(222,221,1),(227,226,1),(253,252,1),(253,269,1),(253,307,1),(253,314,1),(254,252,2),(255,252,3),(255,269,3),(255,307,3),(255,314,3),(259,256,1),(270,269,2),(270,307,2),(270,314,2),(272,271,1),(272,278,2),(272,282,2),(272,285,1),(272,289,1),(272,292,1),(272,295,1),(272,298,1),(272,301,1),(272,311,1),(272,317,1),(272,321,1),(272,322,1),(277,256,1),(279,278,1),(283,282,1),(325,324,1),(328,327,1),(328,347,1),(331,330,1),(332,330,2),(333,330,3),(336,335,1),(337,335,2),(340,339,1),(341,339,2),(344,343,1),(345,343,2);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (2,2,1,NULL,NULL,NULL,NULL,1,'2025-03-17 03:28:22','2025-03-17 03:28:22','2f6a8f84-51d7-4ce6-9535-3c60dd02a8b3'),(3,3,1,NULL,'__temp_oulmdjysctvtimldzniftlkouiahenoxmbgt','__temp_oulmdjysctvtimldzniftlkouiahenoxmbgt','{\"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": []}',1,'2025-03-17 05:35:19','2025-03-17 06:01:09','a6562850-1061-4b87-ac0d-d58788dd2477'),(4,4,1,NULL,'__temp_nsfdttqzfsynyvsgtbdonutxbducytcbvefn','__temp_nsfdttqzfsynyvsgtbdonutxbducytcbvefn','{\"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": []}',1,'2025-03-17 05:36:17','2025-03-17 06:01:09','d1026751-6555-4b54-804b-4f52c0297535'),(5,5,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 05:38:26','2025-03-17 06:01:09','500cbb99-ed22-4f52-bc39-a3cafd6be80b'),(6,6,1,'Mate01 2x',NULL,NULL,NULL,1,'2025-03-17 05:39:17','2025-03-17 05:39:17','3f588df9-1fe5-456f-b673-8c76cde36720'),(7,7,1,'Next small 2x',NULL,NULL,NULL,1,'2025-03-17 05:39:17','2025-03-17 05:39:17','fabef3d9-08df-44e5-9047-45f7eac2afa5'),(8,8,1,'Slide03 2x',NULL,NULL,NULL,1,'2025-03-17 05:39:17','2025-03-17 05:39:17','7e8f2335-740e-4fba-8809-819bd2f9029a'),(9,9,1,'Slide02 2x',NULL,NULL,NULL,1,'2025-03-17 05:39:17','2025-03-17 05:39:17','19576855-7158-4d7e-97d2-856b4e06237c'),(10,10,1,'Mate top',NULL,NULL,NULL,1,'2025-03-17 05:39:18','2025-03-17 05:39:18','8885617d-1d75-4e5b-8582-3c2ee9f5422c'),(11,11,1,'Next',NULL,NULL,NULL,1,'2025-03-17 05:39:18','2025-03-17 05:39:18','46792116-bc8b-4592-ad8b-3771ff02a19b'),(12,12,1,'Slide01 2x',NULL,NULL,NULL,1,'2025-03-17 05:39:19','2025-03-17 05:39:19','a038e9da-1bf4-46eb-a5ff-9dbf9b26f6fd'),(13,13,1,'Mate top',NULL,NULL,NULL,1,'2025-03-17 05:40:48','2025-03-17 05:40:48','2a111abf-2a7d-4de8-ba89-5c01b4a8e370'),(14,14,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','works-entry/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 05:41:47','2025-03-17 05:41:47','4df7096d-9766-42c1-a04c-82292eabcc19'),(19,19,1,'Mate top',NULL,NULL,NULL,1,'2025-03-17 05:44:35','2025-03-17 05:44:35','66e02cbc-1b0b-4a3f-8c7b-642c6f4dc3a3'),(22,22,1,'Slide01',NULL,NULL,NULL,1,'2025-03-17 05:45:28','2025-03-17 05:45:28','f2278fe6-f097-4cf9-aa31-a5976bdf1ec7'),(23,23,1,'Slide02',NULL,NULL,NULL,1,'2025-03-17 05:45:34','2025-03-17 05:45:34','888f0fc7-d37f-45db-91eb-f7b14e842987'),(24,24,1,'Slide03',NULL,NULL,NULL,1,'2025-03-17 05:45:39','2025-03-17 05:45:39','c51565e1-8729-4305-b3f3-4354808a6434'),(27,27,1,NULL,'__temp_cmetbobtamgwhelsnqnpigmgizquoedlegoe',NULL,'{\"ecd53b5a-047f-4f55-b67b-4fb856ac2534\": [19]}',1,'2025-03-17 05:48:38','2025-03-17 05:48:38','9a29678a-81d1-44d1-8a94-7fb76dfbc564'),(28,28,1,NULL,'__temp_bwtineqbxyoepndoisxjdmxxhaqxrhoicdjb',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22, 23, 24]}',1,'2025-03-17 05:48:38','2025-03-17 05:48:38','cba3f6d9-4df5-4697-b4e7-42f6296775af'),(29,29,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','works-entry/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 05:48:38','2025-03-17 05:48:38','c1b20da7-3fa9-48ab-bcb8-49e98384cd06'),(30,30,1,NULL,'__temp_cmetbobtamgwhelsnqnpigmgizquoedlegoe',NULL,'{\"ecd53b5a-047f-4f55-b67b-4fb856ac2534\": [19]}',1,'2025-03-17 05:48:38','2025-03-17 05:48:38','7cff740e-f465-42ea-a996-b18bd97ae694'),(31,31,1,NULL,'__temp_bwtineqbxyoepndoisxjdmxxhaqxrhoicdjb',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22, 23, 24]}',1,'2025-03-17 05:48:38','2025-03-17 05:48:38','4f5bc29f-a309-479c-9648-0aa3cae8a641'),(32,32,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 06:04:30','2025-03-17 06:04:30','120afe0e-bc98-4523-9203-c53b5e61db5f'),(33,33,1,NULL,'__temp_cmetbobtamgwhelsnqnpigmgizquoedlegoe',NULL,'{\"ecd53b5a-047f-4f55-b67b-4fb856ac2534\": [19]}',1,'2025-03-17 06:04:30','2025-03-17 06:04:30','42b58adb-7654-4818-a1d7-534aee20a25f'),(34,34,1,NULL,'__temp_bwtineqbxyoepndoisxjdmxxhaqxrhoicdjb',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22, 23, 24]}',1,'2025-03-17 06:04:30','2025-03-17 06:04:30','d3445f8e-25ee-4edb-b7f3-a29f85e903b2'),(35,35,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/safe-drive\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [237], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"MATE.BIKE\\nNO 違法改造, NO 危険運転\\nSpecial site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 06:05:59','2025-03-31 01:00:00','239cc151-b525-462a-b188-ae5f1704fe14'),(36,36,1,NULL,'__temp_updcntfplzntjoobefplwicuonfgaoiugdia',NULL,'{\"ecd53b5a-047f-4f55-b67b-4fb856ac2534\": [37]}',1,'2025-03-17 06:07:02','2025-03-17 06:07:24','c53c2018-4c93-4577-8446-206eb494c7e5'),(37,37,1,'Mate01',NULL,NULL,NULL,1,'2025-03-17 06:07:22','2025-03-17 06:07:22','6952a9db-6720-4a64-9d08-563c04217a3f'),(38,38,1,NULL,'__temp_ubqsoowcjphtchmtqjghufxiixzmnscziifn',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22, 23, 24]}',1,'2025-03-17 06:07:28','2025-03-17 06:07:43','4ed79054-258f-4b7a-bd32-11f3bb7eb9d4'),(39,39,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 06:07:45','2025-03-17 06:07:45','286cebef-104a-4d89-af9f-e90121b3f3f1'),(40,40,1,NULL,'__temp_updcntfplzntjoobefplwicuonfgaoiugdia',NULL,'{\"ecd53b5a-047f-4f55-b67b-4fb856ac2534\": [37]}',1,'2025-03-17 06:07:45','2025-03-17 06:07:45','1d519a16-5902-43b6-8051-d2342b762d07'),(41,41,1,NULL,'__temp_ubqsoowcjphtchmtqjghufxiixzmnscziifn',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22, 23, 24]}',1,'2025-03-17 06:07:45','2025-03-17 06:07:45','2f7380e0-de3b-4783-8569-fcfdcc1b4ba5'),(42,42,1,'MATE.BIKENO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 07:11:56','2025-03-17 07:11:56','f74e6d6a-2a72-42f1-a590-f64f3760e0bc'),(43,43,1,'MATE.BIKENO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 07:12:06','2025-03-17 07:12:06','54e643e2-20d4-4f65-93f9-4ea47a91d15c'),(45,45,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 07:13:17','2025-03-17 07:13:17','853e2e82-f192-4098-8e48-ecf157a0f50a'),(46,46,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 07:13:23','2025-03-17 07:13:23','efe1f21c-fba5-473e-9c95-74a0733384e8'),(48,48,1,'MATE.BIKE<br>NO 違法改造, NO 危険運転<br>Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 07:14:05','2025-03-17 07:14:05','47f8befc-75c6-4d2b-a50a-7c7eade5b39f'),(50,50,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\n\\nWeb Development\"}',1,'2025-03-17 07:15:00','2025-03-17 07:15:00','accb31dd-822f-400a-ac5f-92ebc6ab6706'),(52,52,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13], \"f6bd2e46-0b52-4ab7-9971-5b5e48d869f0\": \"Web Design\\nWeb Development\"}',1,'2025-03-17 07:18:20','2025-03-17 07:18:20','039cf069-5573-4450-9280-68c86e506954'),(53,53,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 07:28:18','2025-03-17 07:28:18','8c7df3ab-e721-4d56-9f1a-3bae06fb6dd1'),(54,54,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 07:44:26','2025-03-17 07:44:26','9134f0a6-a71d-4f73-a9e5-b354ff0016ee'),(56,56,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 07:45:55','2025-03-17 07:45:55','c0eb04a1-5f36-4a67-a2d9-6dbe3d80d31f'),(58,58,1,'MATE.BIKE, NO 違法改造  NO 危険運転, Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 07:58:25','2025-03-17 07:58:25','3fc2f463-b24a-4d47-89f8-97db27e5efd8'),(60,60,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 08:00:00','2025-03-17 08:00:00','84f40db8-975d-412f-8e4e-e38143bd6088'),(61,61,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-17 08:51:12','2025-03-17 08:51:12','03d3ef5d-f0ed-43fc-9767-cd30517fa193'),(67,67,1,NULL,'__temp_opskzbrjeqbbbwxsahmykpymyafcixttcpof',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','74d20a20-c87f-4974-8de5-2b1c8c9f2895'),(68,68,1,NULL,'__temp_xzaoaymvdsverlksctyrmlbhwqpdlktvbnda',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [23]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','a8820ffc-6256-4463-806f-e5dcbf3469b2'),(69,69,1,NULL,'__temp_obstttwpwjttrqgbfdftpmdqtnmrrwtrguhf',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [24]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','7c41c002-39f7-465e-a648-92c711b68735'),(70,70,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','e223af1f-06cb-4797-975a-468e360e19f7'),(71,71,1,NULL,'__temp_opskzbrjeqbbbwxsahmykpymyafcixttcpof',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [22]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','82675c97-7b93-4e2d-93be-032b07201f91'),(72,72,1,NULL,'__temp_xzaoaymvdsverlksctyrmlbhwqpdlktvbnda',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [23]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','57eead23-dd8c-45f1-93ef-657a1495143c'),(73,73,1,NULL,'__temp_obstttwpwjttrqgbfdftpmdqtnmrrwtrguhf',NULL,'{\"e39f40f6-c603-475c-8f3d-66ac1152b540\": [24]}',1,'2025-03-18 03:02:21','2025-03-18 03:02:21','a0e7c34e-bba5-4ef6-b9dd-b692082b8cb6'),(77,77,1,NULL,'__temp_alyjescceptaeymxatpwnivvfnndnwgkiesi',NULL,'{\"01de0b68-7515-4b76-a034-be874b652d94\": [23]}',1,'2025-03-18 03:09:07','2025-03-18 03:09:07','687db9f2-0a0a-4998-a19f-6a50e44ce4bb'),(78,78,1,NULL,'__temp_nyozuxqikxbxziziyrydpoqufzsbqjwaxwmt',NULL,'{\"aaca72d6-0ceb-4a43-af11-942b98b568f8\": [24]}',1,'2025-03-18 03:09:07','2025-03-18 03:09:07','ef71d701-af16-4883-9243-0fd502388c9f'),(79,79,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-18 03:09:07','2025-03-18 03:09:07','75024458-df37-49a3-8819-affb14a52bdf'),(80,80,1,NULL,'__temp_alyjescceptaeymxatpwnivvfnndnwgkiesi',NULL,'{\"01de0b68-7515-4b76-a034-be874b652d94\": [23]}',1,'2025-03-18 03:09:07','2025-03-18 03:09:07','7abbeaf1-83cd-4480-8fad-121d8578f1d3'),(81,81,1,NULL,'__temp_nyozuxqikxbxziziyrydpoqufzsbqjwaxwmt',NULL,'{\"aaca72d6-0ceb-4a43-af11-942b98b568f8\": [24]}',1,'2025-03-18 03:09:07','2025-03-18 03:09:07','a412f8b7-8d42-4f03-bbcc-82ee839d1e62'),(83,83,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-18 03:59:45','2025-03-19 03:00:18','c37fcfb9-775f-4747-afae-f49a0c527dce'),(87,87,1,NULL,'__temp_nmslncgwsryjboifaitmsdzijkbxwowshtpe',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [37]}',1,'2025-03-18 05:28:41','2025-03-18 05:28:41','322f42f9-8f61-446d-adf2-c8b0b1f76c69'),(88,88,1,NULL,'__temp_pfxiermofrakhwrdarfvqsqxvdkrxxtltrdu',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [22, 23, 24]}',1,'2025-03-18 05:28:41','2025-03-18 05:28:41','63386e7c-6c6d-4324-8035-1ec73166cc44'),(89,89,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-18 05:28:41','2025-03-18 05:28:41','a3ba9410-80a1-4b4b-bba8-b6207d6940d5'),(90,90,1,NULL,'__temp_nmslncgwsryjboifaitmsdzijkbxwowshtpe',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [37]}',1,'2025-03-18 05:28:41','2025-03-18 05:28:41','6232e85b-f174-41c3-997f-77cd7e30c403'),(91,91,1,NULL,'__temp_pfxiermofrakhwrdarfvqsqxvdkrxxtltrdu',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [22, 23, 24]}',1,'2025-03-18 05:28:41','2025-03-18 05:28:41','438c543e-15f5-471a-8f20-51f47ab46ec6'),(92,92,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-18 05:29:26','2025-03-18 05:29:26','35c4d6b8-3204-4ef2-9f5c-191a324fbf21'),(93,93,1,'Codegraph Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://cdgrph.com/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [94], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"Codegraph\\nNamecard redesign\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-18 07:12:29','2025-03-31 01:00:15','a4e15b3e-4d2d-4aa6-9644-1f522683bf28'),(94,94,1,'Namecard top',NULL,NULL,NULL,1,'2025-03-18 07:12:48','2025-03-18 07:12:48','b6a772ad-4265-4da6-ab4b-b79babd1d5f6'),(95,95,1,NULL,'__temp_oceewabbsblobtmzcpzwpfllzyipdqjmugdv',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [96]}',1,'2025-03-18 07:14:11','2025-03-18 07:14:28','122cd8c6-b8bc-4f60-8aad-291c1765a7de'),(96,96,1,'Namecard01',NULL,NULL,NULL,1,'2025-03-18 07:14:27','2025-03-18 07:14:27','ba4f4d16-0234-4a3b-bf23-f649c03d53a4'),(97,97,1,NULL,'__temp_xdpddtgsmmijldfyvrmfskzanosvsouoxftw',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [98]}',1,'2025-03-18 07:14:30','2025-03-18 07:14:37','668f1c56-04f9-4117-a396-fa85846896ae'),(98,98,1,'Namecard02',NULL,NULL,NULL,1,'2025-03-18 07:14:37','2025-03-18 07:14:37','f7ee3664-cae7-45fc-9f43-65ed17efc89d'),(99,99,1,'Codegraph | Namecard redesign','codegraph-namecard-redesign','codegraph-namecard-redesign','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"-\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"graphicDesign\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-18 07:14:41','2025-03-18 07:14:41','5bb0ec23-c090-4ad6-94f3-cebe64810b4a'),(100,100,1,NULL,'__temp_oceewabbsblobtmzcpzwpfllzyipdqjmugdv',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [96]}',1,'2025-03-18 07:14:41','2025-03-18 07:14:41','2923b8c4-a2c5-4ac2-99a1-2de87ae92135'),(101,101,1,NULL,'__temp_xdpddtgsmmijldfyvrmfskzanosvsouoxftw',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [98]}',1,'2025-03-18 07:14:41','2025-03-18 07:14:41','ab78bed0-3310-4434-8def-19483cd92b5d'),(103,103,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','codegraph-namecard-redesign','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"-\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"graphicDesign\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-18 07:15:25','2025-03-18 07:15:25','1b2c799c-65de-41ae-a873-f0f3ff724a4f'),(104,104,1,'Works - Index','works-index','works-index',NULL,1,'2025-03-19 02:48:35','2025-03-19 02:48:35','89285788-b7dc-4311-ae8f-e9c6f4fb62d7'),(105,105,1,'Works - Index','works-index','works-index',NULL,1,'2025-03-19 02:48:35','2025-03-19 02:48:35','7b202d50-166b-4eea-9b02-dfb154741801'),(106,106,1,'infocom MVV Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://www.infocom.co.jp/mvv/ja.html\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [136], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"infocom MVV\\nSpecial site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-19 03:06:57','2025-03-31 00:59:47','729a0d0b-1256-486d-9723-42fd6415e925'),(107,107,1,'Infocom top',NULL,NULL,NULL,1,'2025-03-19 03:11:50','2025-03-19 03:11:50','5b5995eb-8196-4e21-be1d-b534d36a1368'),(108,108,1,NULL,'__temp_mysgupsqfxgsepsvhsnckdggzzasxzrorsze',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [179]}',1,'2025-03-19 03:13:05','2025-03-21 08:26:03','95804089-0b8a-400a-830d-e4ceb6d50ed3'),(109,109,1,'Infocom01',NULL,NULL,NULL,1,'2025-03-19 03:13:11','2025-03-19 03:13:11','3e8cdee2-affb-4889-8ae7-294fc4822ef9'),(110,110,1,NULL,'__temp_kshggiaabxqtkwqqbhgvjgdhuiougfmktidq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [172, 175, 173]}',1,'2025-03-19 03:13:13','2025-03-21 08:24:47','054d0fb4-df43-41ed-bbd4-a40d19cd8eef'),(111,111,1,'Infocom slide01',NULL,NULL,NULL,1,'2025-03-19 03:13:21','2025-03-19 03:13:21','34bc130c-3196-4fae-9810-b2f991f77e1e'),(112,112,1,'Infocom slide03',NULL,NULL,NULL,1,'2025-03-19 03:13:21','2025-03-19 03:13:21','0cd4f64f-cbb0-4c7e-b1bf-820db4c717eb'),(113,113,1,'Infocom slide02',NULL,NULL,NULL,1,'2025-03-19 03:13:21','2025-03-19 03:13:21','742e1f2b-ab9d-4cf5-ba77-bc6a52034537'),(114,114,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-19 03:13:27','2025-03-19 03:13:27','13a24903-582b-4acd-9d82-a7b8704694c5'),(115,115,1,NULL,'__temp_mysgupsqfxgsepsvhsnckdggzzasxzrorsze',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [109]}',1,'2025-03-19 03:13:27','2025-03-19 03:13:27','69846083-a902-4aaa-a234-075d367697c7'),(116,116,1,NULL,'__temp_kshggiaabxqtkwqqbhgvjgdhuiougfmktidq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [111, 113, 112]}',1,'2025-03-19 03:13:27','2025-03-19 03:13:27','498a8243-2ac2-448e-9545-4fd921fee7f8'),(118,118,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"-\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"-\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"graphicDesign\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-19 03:15:53','2025-03-19 03:15:53','b5e3cef6-6986-49a6-84fc-4fc86e361db7'),(119,119,1,NULL,'__temp_oceewabbsblobtmzcpzwpfllzyipdqjmugdv',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [96]}',1,'2025-03-19 03:15:53','2025-03-19 03:15:53','9f59303f-2647-4e58-9e56-e77a19d87133'),(120,120,1,NULL,'__temp_xdpddtgsmmijldfyvrmfskzanosvsouoxftw',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [98]}',1,'2025-03-19 03:15:53','2025-03-19 03:15:53','d774c749-8f8a-4cee-a085-2f8218d6de29'),(122,122,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"-\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-19 03:15:58','2025-03-19 03:15:58','f048d490-c29c-45c3-a7de-de5f7c4a1649'),(123,123,1,NULL,'__temp_nmslncgwsryjboifaitmsdzijkbxwowshtpe',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [37]}',1,'2025-03-19 03:15:58','2025-03-19 03:15:58','8ee4e3b0-867d-4324-8944-49def039d66b'),(124,124,1,NULL,'__temp_pfxiermofrakhwrdarfvqsqxvdkrxxtltrdu',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [22, 23, 24]}',1,'2025-03-19 03:15:58','2025-03-19 03:15:58','07efeb4e-66b3-44a3-82e4-1087705ca838'),(126,126,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-19 03:16:13','2025-03-19 03:16:13','f6e4c664-c1c2-442e-b494-5388d79080c9'),(127,127,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-19 03:17:18','2025-03-19 03:17:18','3c309c31-81b8-4955-abda-8236aad6579b'),(129,129,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-19 03:24:10','2025-03-19 03:24:10','6151b7be-8da7-4841-b999-fa44a909d0af'),(131,131,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"-\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"graphicDesign\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-19 03:24:15','2025-03-19 03:24:15','0bd4c6a4-bf7d-4aa2-9cc8-dcf58e63f040'),(133,133,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-19 03:45:47','2025-03-19 03:45:47','8af36c15-d7f6-44f1-b074-15a3fb2c7a09'),(135,135,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-19 03:46:25','2025-03-19 03:46:25','f02092d0-26f7-4c44-991b-7c5e13db74f6'),(136,136,1,'Infocom next',NULL,NULL,NULL,1,'2025-03-21 03:55:03','2025-03-21 03:55:03','9966aa43-c88a-4dbc-8045-294d1f861db2'),(138,138,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"423351d8-1351-415f-adbf-0d950c548da2\": [136], \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-21 03:55:06','2025-03-21 03:55:06','2528dfe6-faad-4903-82ca-7cab13a65b08'),(141,141,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [139], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 03:55:45','2025-03-21 03:55:45','d986991b-af47-4193-8781-fab468f23aa0'),(144,144,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"423351d8-1351-415f-adbf-0d950c548da2\": [142], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-21 03:56:08','2025-03-21 03:56:08','450b88f5-95f6-49d8-a6df-13b406a19d97'),(147,147,1,'Short offline 240822',NULL,NULL,NULL,1,'2025-03-21 04:11:02','2025-03-21 04:11:02','66c7e0aa-6149-4c43-8b05-a850642e4acb'),(148,148,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"423351d8-1351-415f-adbf-0d950c548da2\": [136], \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-21 04:11:04','2025-03-21 04:11:04','9ae14da3-a23b-4c6a-bd1b-7849e6d115d1'),(149,149,1,NULL,'__temp_mysgupsqfxgsepsvhsnckdggzzasxzrorsze',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [147]}',1,'2025-03-21 04:11:04','2025-03-21 04:11:04','82afbc0f-3116-47cd-9ab5-a8be6dfc43d6'),(150,150,1,'MATE.BIKE 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/hoken\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [313], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"MATE.BIKE\\n盗難＆車両保険 LP\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [265]}',1,'2025-03-21 08:02:25','2025-03-31 00:59:09','4776bd46-3bd6-4f60-b534-d508d037a116'),(151,151,1,'MATE TOP 1',NULL,NULL,NULL,1,'2025-03-21 08:02:50','2025-03-21 08:02:50','d1d9b709-cbc7-472f-af16-adf6b3a6a92c'),(152,152,1,NULL,'__temp_raefhvvclavldyhmgwkbyoklyndxzqorlbxj',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [243]}',1,'2025-03-21 08:04:27','2025-03-21 09:23:01','efdbed3e-f33b-48c1-b5d6-342bc527197b'),(153,153,1,'Mate01 1',NULL,NULL,NULL,1,'2025-03-21 08:04:35','2025-03-21 08:04:35','a67f1b3f-7b10-42c6-b3c4-99c2d40440e5'),(154,154,1,NULL,'__temp_mhnfreujbcccbxjxrtkjiuehcaomotqqfide',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [267]}',1,'2025-03-21 08:04:40','2025-03-21 09:33:29','47a01205-899f-46fe-9116-3da4d12cedb9'),(155,155,1,'Mate02',NULL,NULL,NULL,1,'2025-03-21 08:04:50','2025-03-21 08:04:50','39d5d3ea-5901-40b7-a9d0-6a387e5ae580'),(156,156,1,NULL,'__temp_ujvfagqbyvtkaaekgpternpklbolgymmfgiw',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [240, 241, 246, 245]}',1,'2025-03-21 08:04:53','2025-03-21 09:23:01','4be156be-3c0c-4541-9fba-5de5a96daf53'),(157,157,1,'Mate slide01',NULL,NULL,NULL,1,'2025-03-21 08:05:02','2025-03-21 08:05:02','aca2ce00-0f53-438e-a5e7-0ad73bd70f56'),(158,158,1,'Mate slide02',NULL,NULL,NULL,1,'2025-03-21 08:05:08','2025-03-21 08:05:08','3f506957-c05f-4d67-99d2-f8d1c278a407'),(159,159,1,'Mate slide04',NULL,NULL,NULL,1,'2025-03-21 08:05:08','2025-03-21 08:05:08','1e596974-762d-4896-98d3-14aa5250f852'),(160,160,1,'MATE.BIKE | 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [151], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [151]}',1,'2025-03-21 08:05:14','2025-03-21 08:05:14','e0bde92b-24ac-40af-ac82-c064153e7be8'),(161,161,1,NULL,'__temp_raefhvvclavldyhmgwkbyoklyndxzqorlbxj',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [153]}',1,'2025-03-21 08:05:14','2025-03-21 08:05:14','62c43dd1-5b04-4d66-bde8-035e2a78afe1'),(162,162,1,NULL,'__temp_mhnfreujbcccbxjxrtkjiuehcaomotqqfide',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [155]}',1,'2025-03-21 08:05:14','2025-03-21 08:05:14','cc7c79bd-6682-4431-a9dc-198f416d05f4'),(163,163,1,NULL,'__temp_ujvfagqbyvtkaaekgpternpklbolgymmfgiw',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [157, 158, 159]}',1,'2025-03-21 08:05:14','2025-03-21 08:05:14','e5ccb518-3cb4-409a-b29d-0fc065fbbd25'),(164,164,1,'Mate slide03',NULL,NULL,NULL,1,'2025-03-21 08:06:00','2025-03-21 08:06:00','ea698312-f040-4daa-8e4c-d113fbed7df6'),(167,167,1,'MATE.BIKE | 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [151], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [151]}',1,'2025-03-21 08:06:04','2025-03-21 08:06:04','b732dacb-9c10-4841-8f60-5a29ade17512'),(168,168,1,NULL,'__temp_ujvfagqbyvtkaaekgpternpklbolgymmfgiw',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [157, 158, 164, 159]}',1,'2025-03-21 08:06:04','2025-03-21 08:06:04','33443fb0-d833-4219-9d08-5fdd4919df58'),(171,171,1,'Short offline 240822',NULL,NULL,NULL,1,'2025-03-21 08:24:35','2025-03-21 08:24:35','34480db0-afdb-4dfd-9d07-c4cdcfa4f3f2'),(172,172,1,'Infocom slide01',NULL,NULL,NULL,1,'2025-03-21 08:24:41','2025-03-21 08:24:41','2e013f97-3935-4f7a-9a23-30362210efb6'),(173,173,1,'Infocom slide03',NULL,NULL,NULL,1,'2025-03-21 08:24:41','2025-03-21 08:24:41','9b0b2b16-0344-4b63-836c-bab3ac3721ab'),(175,175,1,'Infocom slide02',NULL,NULL,NULL,1,'2025-03-21 08:24:42','2025-03-21 08:24:42','265e4619-c39c-4a81-9eb7-6c8f50a0e50f'),(176,176,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"423351d8-1351-415f-adbf-0d950c548da2\": [136], \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-21 08:24:47','2025-03-21 08:24:47','e1494d4a-d3bf-4e8e-a11d-2c5208df67ca'),(177,177,1,NULL,'__temp_mysgupsqfxgsepsvhsnckdggzzasxzrorsze',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [171]}',1,'2025-03-21 08:24:47','2025-03-21 08:24:47','09e17cf3-17df-4275-9583-8b00b993ddff'),(178,178,1,NULL,'__temp_kshggiaabxqtkwqqbhgvjgdhuiougfmktidq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [172, 175, 173]}',1,'2025-03-21 08:24:47','2025-03-21 08:24:47','edddec3c-b5b3-4370-b77a-fae864863e5c'),(179,179,1,'Short offline 240822',NULL,NULL,NULL,1,'2025-03-21 08:26:00','2025-03-21 08:26:00','23401919-b324-47bd-97cf-1ec25da77b1f'),(182,182,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"423351d8-1351-415f-adbf-0d950c548da2\": [136], \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-21 08:26:03','2025-03-21 08:26:03','1b1dacfa-9f1f-4c71-b8a1-30bf8f7dd060'),(183,183,1,NULL,'__temp_mysgupsqfxgsepsvhsnckdggzzasxzrorsze',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [179]}',1,'2025-03-21 08:26:03','2025-03-21 08:26:03','8dd06eac-3864-47bd-9905-f5646688ffc3'),(185,185,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"423351d8-1351-415f-adbf-0d950c548da2\": [94], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-21 08:27:05','2025-03-21 08:27:05','c424abf6-beb8-4c83-9d5a-fb90c04ca45c'),(189,189,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [187], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:30:41','2025-03-21 08:30:41','7e56b689-02b4-4443-a880-e4f0fe7ca721'),(192,192,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [190], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:31:46','2025-03-21 08:31:46','6cad454c-37af-40bd-b42f-1df222cdc539'),(195,195,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [193], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:36:24','2025-03-21 08:36:24','6a3bf38b-4da7-4964-9c7a-db9e9549e514'),(198,198,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [197], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:41:14','2025-03-21 08:41:14','d619fdbf-f0db-4bb5-804a-50f02911136d'),(199,199,1,'MATE safedrive next',NULL,NULL,NULL,1,'2025-03-21 08:41:56','2025-03-21 08:41:56','01cc1f4b-ca47-41cf-bd63-c0049566e917'),(201,201,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [199], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:41:59','2025-03-21 08:41:59','d3f6c88f-2b08-448c-9208-bb548d58b6bd'),(204,204,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [202], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:47:47','2025-03-21 08:47:47','d4e87b01-cdc1-4ad6-83ed-680ea417e4c9'),(207,207,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [205], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:48:51','2025-03-21 08:48:51','b5bcd212-8a40-4300-9c85-57ef979a257f'),(210,210,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [208], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:50:00','2025-03-21 08:50:00','76dabb81-1757-44c8-84f9-515e798961bd'),(213,213,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [211], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:52:24','2025-03-21 08:52:24','cb184821-144f-4fa4-8a7c-e25799d1ac48'),(216,216,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"423351d8-1351-415f-adbf-0d950c548da2\": [214], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 08:55:05','2025-03-21 08:55:05','75a6c651-4bc0-41a3-9460-8521f7d17b69'),(220,220,1,NULL,'__temp_kffolqoxpdibtjmfgttailebiaeqfcxvnght',NULL,'{\"dcd89f24-0604-45a5-b2c6-947aa96ff816\": [223]}',1,'2025-03-21 09:11:13','2025-03-21 09:13:29','b85c486d-cb1e-4750-9a45-2c8d76246858'),(221,221,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 09:11:13','2025-03-21 09:11:13','950f1fe1-f70a-412a-8d93-30e285a1f4ba'),(222,222,1,NULL,'__temp_kffolqoxpdibtjmfgttailebiaeqfcxvnght',NULL,'{\"dcd89f24-0604-45a5-b2c6-947aa96ff816\": [219]}',1,'2025-03-21 09:11:13','2025-03-21 09:11:13','19c00427-94d9-4fbe-b3ad-cd3cdb973cff'),(226,226,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 09:13:29','2025-03-21 09:13:29','345a03ce-d42b-4d29-80ef-7db0c940de72'),(227,227,1,NULL,'__temp_kffolqoxpdibtjmfgttailebiaeqfcxvnght',NULL,'{\"dcd89f24-0604-45a5-b2c6-947aa96ff816\": [223]}',1,'2025-03-21 09:13:29','2025-03-21 09:13:29','b9d77c3c-66da-447c-a51d-cde78d648e3b'),(230,230,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [228], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 09:16:48','2025-03-21 09:16:48','c7106a14-46fe-41d5-81e1-fe15fdeae02c'),(233,233,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [231], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 09:17:44','2025-03-21 09:17:44','3400ff21-7126-4a2a-9515-c930fba6436c'),(236,236,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [234], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 09:18:39','2025-03-21 09:18:39','d5e55752-8206-46d9-ab12-3ec0c3055d1e'),(237,237,1,'MATE safedrive next',NULL,NULL,NULL,1,'2025-03-21 09:19:09','2025-03-21 09:19:09','e861eb33-6689-468c-af21-6ae9fda2cfc2'),(239,239,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [237], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-21 09:19:11','2025-03-21 09:19:11','289b9f64-4a65-40d4-aed3-dc1660ccfae2'),(240,240,1,'Mate slide01',NULL,NULL,NULL,1,'2025-03-21 09:20:18','2025-03-21 09:20:18','e96fc527-a2b6-4c8d-85c6-4746a075a7da'),(241,241,1,'Mate slide02',NULL,NULL,NULL,1,'2025-03-21 09:20:36','2025-03-21 09:20:36','48b62db9-c885-4301-adfa-4bc74b8110ad'),(242,242,1,'Mate02',NULL,NULL,NULL,1,'2025-03-21 09:20:36','2025-03-21 09:20:36','2fc45767-37bd-4a81-88f9-c47be61e27fa'),(243,243,1,'Mate01 1',NULL,NULL,NULL,1,'2025-03-21 09:20:36','2025-03-21 09:20:36','155a3ad3-0ab2-4819-85f8-855aff43c6a9'),(244,244,1,'MATE TOP 1',NULL,NULL,NULL,1,'2025-03-21 09:20:36','2025-03-21 09:20:36','d4eafac1-91ca-4324-b585-e3fb61f2afb6'),(245,245,1,'Mate slide04',NULL,NULL,NULL,1,'2025-03-21 09:20:37','2025-03-21 09:20:37','6ff601a8-8c74-4d0a-8dbb-0ac72068f488'),(246,246,1,'Mate slide03',NULL,NULL,NULL,1,'2025-03-21 09:20:37','2025-03-21 09:20:37','f4a6cef9-9062-4f72-953a-df24669ad93b'),(247,247,1,'MATE TOP 1',NULL,NULL,NULL,1,'2025-03-21 09:21:42','2025-03-21 09:21:42','7caafc4c-fdb4-4f36-926b-31548353d309'),(248,248,1,'Mate02',NULL,NULL,NULL,1,'2025-03-21 09:22:21','2025-03-21 09:22:21','a77bbb3f-ae39-4aab-81a4-3b341c3139f9'),(252,252,1,'MATE.BIKE | 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [248], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [244]}',1,'2025-03-21 09:23:01','2025-03-21 09:23:01','ac8c4e00-8539-41c7-b1ad-8c1925954ff1'),(253,253,1,NULL,'__temp_raefhvvclavldyhmgwkbyoklyndxzqorlbxj',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [243]}',1,'2025-03-21 09:23:01','2025-03-21 09:23:01','3e75dfcc-6ff5-4a53-afe7-ed5c2528e79a'),(254,254,1,NULL,'__temp_mhnfreujbcccbxjxrtkjiuehcaomotqqfide',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [242]}',1,'2025-03-21 09:23:01','2025-03-21 09:23:01','d36be88d-52a3-48e8-908b-42b22ce92016'),(255,255,1,NULL,'__temp_ujvfagqbyvtkaaekgpternpklbolgymmfgiw',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [240, 241, 246, 245]}',1,'2025-03-21 09:23:01','2025-03-21 09:23:01','1c81f16e-7ceb-4c10-8faf-13c07a61e13f'),(256,256,1,'The Lodge Okinawa Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"The Lodge Okinawa\\nTeaser site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [296], \"f7ddf1fe-e738-4eb1-8182-f25f3bbf0e8e\": [316]}',1,'2025-03-21 09:24:15','2025-03-31 02:25:41','a5ca0b01-e9d4-4cdd-a6d0-bf63ed3fcc0d'),(257,257,1,'Lodge Top',NULL,NULL,NULL,1,'2025-03-21 09:24:30','2025-03-21 09:24:30','214b9714-7174-4e0c-8e96-c1e9143954b8'),(258,258,1,'Lodge Top',NULL,NULL,NULL,1,'2025-03-21 09:27:49','2025-03-21 09:27:49','408893d4-8dc9-49f3-b8fb-4e61b1d52bba'),(259,259,1,NULL,'__temp_pzoebfgkdvfrvcmvyulwkmlmzlqrtgvjzhaq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [260, 263, 262, 261]}',1,'2025-03-21 09:29:10','2025-03-21 09:29:25','3c950101-c3d6-4f2f-bf96-4af3e21588e8'),(260,260,1,'Lodge slide01',NULL,NULL,NULL,1,'2025-03-21 09:29:19','2025-03-21 09:29:19','4d27f56f-73b4-415b-9c7e-a698181b0a03'),(261,261,1,'Lodge slide04',NULL,NULL,NULL,1,'2025-03-21 09:29:19','2025-03-21 09:29:19','bd5d84fe-4056-42df-9bd2-df5a441abd28'),(262,262,1,'Lodge slide03',NULL,NULL,NULL,1,'2025-03-21 09:29:19','2025-03-21 09:29:19','e063b5cb-08b9-470b-8e01-fef9423fc490'),(263,263,1,'Lodge slide02',NULL,NULL,NULL,1,'2025-03-21 09:29:20','2025-03-21 09:29:20','81c47db8-4255-4ce3-89c8-d968970118c3'),(264,264,1,'Lodge Top',NULL,NULL,NULL,1,'2025-03-21 09:29:48','2025-03-21 09:29:48','6034c8a7-8b44-4662-a9e4-0ef1471899b0'),(265,265,1,'MATE TOP 1',NULL,NULL,NULL,1,'2025-03-21 09:33:06','2025-03-21 09:33:06','ea5bc4c6-7bd6-49b3-bc04-c2dee61d3375'),(267,267,1,'Mate02',NULL,NULL,NULL,1,'2025-03-21 09:33:27','2025-03-21 09:33:27','859b0fea-fa41-4b49-a70e-2380a44da914'),(269,269,1,'MATE.BIKE | 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [248], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [265]}',1,'2025-03-21 09:33:29','2025-03-21 09:33:29','99c28b4a-35c7-4e6f-a1ec-581cd2964323'),(270,270,1,NULL,'__temp_mhnfreujbcccbxjxrtkjiuehcaomotqqfide',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [267]}',1,'2025-03-21 09:33:29','2025-03-21 09:33:29','48514316-0f2f-4bea-b84e-9b43d790a22b'),(271,271,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [264], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-24 00:39:56','2025-03-24 00:39:56','14c1c5b6-7620-4e00-9f71-0750e8b2c0b0'),(272,272,1,NULL,'__temp_pzoebfgkdvfrvcmvyulwkmlmzlqrtgvjzhaq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [260, 263, 262, 261]}',1,'2025-03-24 00:39:56','2025-03-24 00:39:56','9229e7be-096b-4f0c-aafb-0a6d65d4c74a'),(273,273,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [94], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-24 00:55:27','2025-03-24 00:55:27','015b80d7-f403-41e9-a27a-af1b4004f168'),(274,274,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [94], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-24 03:26:36','2025-03-24 03:26:36','90522d03-d748-4e34-876b-94902d150849'),(277,277,1,NULL,'__temp_cqcowumjcszfusicwrlpaqbmqzuyhkulveds',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [258]}',1,'2025-03-24 04:19:42','2025-03-24 04:21:19','3764fe56-6ab5-4a7d-9f66-74fd5f1077de'),(278,278,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [264], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-24 04:19:42','2025-03-24 04:19:42','dec0c742-5cba-42e6-9474-745fb5fcedaa'),(279,279,1,NULL,'__temp_cqcowumjcszfusicwrlpaqbmqzuyhkulveds',NULL,NULL,1,'2025-03-24 04:19:42','2025-03-24 04:19:42','02c9cb4c-f4bc-4718-8561-c46ec50fc737'),(282,282,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [264], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-24 04:21:19','2025-03-24 04:21:19','5d5f36fb-4476-4e47-a2ce-0ce363baeeb8'),(283,283,1,NULL,'__temp_cqcowumjcszfusicwrlpaqbmqzuyhkulveds',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [258]}',1,'2025-03-24 04:21:19','2025-03-24 04:21:19','098df8a6-4678-46a6-9236-a516a429b774'),(285,285,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [264], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-24 04:21:57','2025-03-24 04:21:57','c012fecb-ad49-46e8-8f72-27c54bd61564'),(288,288,1,'Lodge next',NULL,NULL,NULL,1,'2025-03-24 08:37:49','2025-03-24 08:37:49','bec24ca6-7752-4b42-a788-bba914d8fd26'),(289,289,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [288], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-24 08:37:51','2025-03-24 08:37:51','c015ef19-6f22-4c56-8d41-e7758fe8f153'),(291,291,1,'Lodge next',NULL,NULL,NULL,1,'2025-03-25 02:45:36','2025-03-25 02:45:36','d97263a2-fba5-4dc8-a7de-081ae7ce015c'),(292,292,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [291], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-25 02:45:55','2025-03-25 02:45:55','5079204b-832a-4e5c-9ab4-df8c1e7a7971'),(293,293,1,'Lodge next',NULL,NULL,NULL,1,'2025-03-25 02:47:07','2025-03-25 02:47:07','28a36ac6-3f4a-433d-92c5-41e1d5c339c5'),(295,295,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [293], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [258]}',1,'2025-03-25 02:47:09','2025-03-25 02:47:09','d810e2e8-c0fe-48af-bf26-a6128c25f3e8'),(296,296,1,'Lodge Top',NULL,NULL,NULL,1,'2025-03-25 02:48:28','2025-03-25 02:48:28','f45449c1-ef34-468a-9185-fa4eb9146850'),(298,298,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [293], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [296]}',1,'2025-03-25 02:48:31','2025-03-25 02:48:31','2ecb90a7-f235-43da-bc31-e6f01c602fca'),(300,300,1,'Lodge Top',NULL,NULL,NULL,1,'2025-03-25 02:53:04','2025-03-25 02:53:04','62efb459-6c30-43df-a274-691b44513e89'),(301,301,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [296]}',1,'2025-03-25 02:53:08','2025-03-25 02:53:08','d9328c81-98d9-4fcd-b788-00580ab3c86d'),(303,303,1,'Codegraph|Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://cdgrph.com/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [94], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-25 03:03:38','2025-03-25 03:03:38','05dabdaa-da69-41a4-84b1-2144a4fb96b5'),(305,305,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/safe-drive\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [237], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-25 03:04:44','2025-03-25 03:04:44','2a27fb04-836b-4738-9d58-de06bb538f32'),(307,307,1,'MATE.BIKE | 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/hoken\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [248], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [265]}',1,'2025-03-25 03:05:30','2025-03-25 03:05:30','65ca66e5-6e73-44dd-9a59-06312e4f2700'),(309,309,1,'infocom MVV | Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://www.infocom.co.jp/mvv/ja.html\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [136], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-25 03:05:56','2025-03-25 03:05:56','606e580e-e199-45ca-9604-ea72becb0bcf'),(311,311,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [296]}',1,'2025-03-25 03:06:54','2025-03-25 03:06:54','ac6ca337-515c-45bc-8743-09aa02fe60ba'),(313,313,1,'MATE TOP 1',NULL,NULL,NULL,1,'2025-03-25 03:38:19','2025-03-25 03:38:19','b13fd777-c78f-4a66-997d-50d9d8b7d18e'),(314,314,1,'MATE.BIKE | 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/hoken\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [313], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [265]}',1,'2025-03-25 03:38:26','2025-03-25 03:38:26','82c5a384-9d7d-42ca-8beb-f1f9241b9e77'),(316,316,1,'lodge-video',NULL,NULL,NULL,1,'2025-03-25 05:35:20','2025-03-31 01:53:19','13a58164-7bb2-4e54-8931-ac4dab0cd0cb'),(317,317,1,'The Lodge Okinawa | Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [316]}',1,'2025-03-25 05:35:24','2025-03-25 05:35:24','3f79e944-38fc-4875-99b6-ecc5b2727767'),(319,319,1,'MATE.BIKE|NO 違法改造,  NO 危険運転, |Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/safe-drive\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [237], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"817435ef-1be5-4ee8-8611-a9261f1bcb02\": true, \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-26 03:20:28','2025-03-26 03:20:28','61feff6b-c9dd-4664-af63-faaaf75ca01d'),(321,321,1,'The Lodge OkinawaTeaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [316]}',1,'2025-03-31 00:53:00','2025-03-31 00:53:00','ea6a34a7-455c-47f5-a2cb-31d89e6d6ea5'),(322,322,1,'The Lodge OkinawaTeaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [316]}',1,'2025-03-31 00:53:06','2025-03-31 00:53:06','63f9e3d8-c571-4fce-87e0-4bd39b9d6ad5'),(324,324,1,NULL,'the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"The Lodge Okinawa\\nTeaser site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [316]}',1,'2025-03-31 00:55:57','2025-03-31 00:55:57','09f2defa-62b7-4bf0-8aba-95c41ee3ce44'),(325,325,1,NULL,'__temp_pzoebfgkdvfrvcmvyulwkmlmzlqrtgvjzhaq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [260, 263, 262, 261]}',1,'2025-03-31 00:55:57','2025-03-31 00:55:57','a2c15f53-c1ef-4883-949d-1deb8f4a2c03'),(327,327,1,'The Lodge Okinawa Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"The Lodge Okinawa\\nTeaser site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [316]}',1,'2025-03-31 00:58:52','2025-03-31 00:58:52','9232e799-9058-4b6a-9073-6441aa982f6a'),(328,328,1,NULL,'__temp_pzoebfgkdvfrvcmvyulwkmlmzlqrtgvjzhaq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [260, 263, 262, 261]}',1,'2025-03-31 00:58:52','2025-03-31 00:58:52','aad5f480-0099-4a84-bbc6-b2ee155e9e5d'),(330,330,1,'MATE.BIKE 盗難＆車両保険 LP','mate-bike-盗難-車両保険-lp','works/mate-bike-盗難-車両保険-lp','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/hoken\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [313], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\", \"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"車体の破損および盗難を補償する「MATE.BIKEオーナー」専用の盗難&車両保険についてのLP制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2023\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"MATE.BIKE\\n盗難＆車両保険 LP\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [265]}',1,'2025-03-31 00:59:09','2025-03-31 00:59:09','03bfddf0-ef12-4fa6-b951-77a719f34b67'),(331,331,1,NULL,'__temp_raefhvvclavldyhmgwkbyoklyndxzqorlbxj',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [243]}',1,'2025-03-31 00:59:09','2025-03-31 00:59:09','d9579b2e-fe02-4469-bac1-f67797db4cbd'),(332,332,1,NULL,'__temp_mhnfreujbcccbxjxrtkjiuehcaomotqqfide',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [267]}',1,'2025-03-31 00:59:09','2025-03-31 00:59:09','44c66797-75d4-4e7e-a636-4ac127133ed0'),(333,333,1,NULL,'__temp_ujvfagqbyvtkaaekgpternpklbolgymmfgiw',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [240, 241, 246, 245]}',1,'2025-03-31 00:59:09','2025-03-31 00:59:09','7b888901-88ee-4d9e-b948-13b910af19b9'),(335,335,1,'infocom MVV Special site','infocom-mvv-special-site','works/infocom-mvv-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://www.infocom.co.jp/mvv/ja.html\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [136], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"infocom Corp.\", \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\": \"SUPER SUPER Inc.\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"インフォコム株式会社のMission Vision Valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"infocom MVV\\nSpecial site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [107]}',1,'2025-03-31 00:59:47','2025-03-31 00:59:47','6c2a89f5-5514-48f7-b50c-22af4622047b'),(336,336,1,NULL,'__temp_mysgupsqfxgsepsvhsnckdggzzasxzrorsze',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [179]}',1,'2025-03-31 00:59:47','2025-03-31 00:59:47','77eaaf37-0ce6-4a9a-bce8-bdc144279b06'),(337,337,1,NULL,'__temp_kshggiaabxqtkwqqbhgvjgdhuiougfmktidq',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [172, 175, 173]}',1,'2025-03-31 00:59:47','2025-03-31 00:59:47','410a8ec0-b46b-4658-87f0-648173706b1e'),(339,339,1,'MATE.BIKE NO 違法改造, NO 危険運転 Special site','mate-bike-no-違法改造-no-危険運転-special-site','works/mate-bike-no-違法改造-no-危険運転-special-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://mate-bike.jp/pages/safe-drive\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [237], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"MATE.BIKE\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Web Design\", \"Web Development\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe-BIKEを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"MATE.BIKE\\nNO 違法改造, NO 危険運転\\nSpecial site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [13]}',1,'2025-03-31 01:00:00','2025-03-31 01:00:00','75cacd27-01d5-4739-8357-4e33a1f38a4f'),(340,340,1,NULL,'__temp_nmslncgwsryjboifaitmsdzijkbxwowshtpe',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [37]}',1,'2025-03-31 01:00:00','2025-03-31 01:00:00','8739806c-0da8-4fc3-b421-8cf00305e241'),(341,341,1,NULL,'__temp_pfxiermofrakhwrdarfvqsqxvdkrxxtltrdu',NULL,'{\"ca1c4dce-e911-4aac-87c4-acef202d13cc\": [22, 23, 24]}',1,'2025-03-31 01:00:00','2025-03-31 01:00:00','36512753-1f83-4c33-9166-6fddf5d3d1ce'),(343,343,1,'Codegraph Namecard redesign','codegraph-namecard-redesign','works/codegraph-namecard-redesign','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://cdgrph.com/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [94], \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Graphic Design\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2025\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"Codegraph\\nNamecard redesign\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [94]}',1,'2025-03-31 01:00:15','2025-03-31 01:00:15','abb86add-6bd6-4b09-8718-9ba2b2a8bb68'),(344,344,1,NULL,'__temp_oceewabbsblobtmzcpzwpfllzyipdqjmugdv',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [96]}',1,'2025-03-31 01:00:15','2025-03-31 01:00:15','6ad71949-db57-499f-9bf4-936ed6bd3efb'),(345,345,1,NULL,'__temp_xdpddtgsmmijldfyvrmfskzanosvsouoxftw',NULL,'{\"40236e76-0b57-4872-9713-a653ef4d83f0\": [98]}',1,'2025-03-31 01:00:15','2025-03-31 01:00:15','7d642263-1377-4408-8889-25a96d938792'),(347,347,1,'The Lodge Okinawa Teaser site','the-lodge-okinawa-teaser-site','works/the-lodge-okinawa-teaser-site','{\"2a516c28-ca34-4ada-95de-3d4c7841e925\": {\"type\": \"url\", \"value\": \"https://lodge.okinawa/\"}, \"355ab973-44c6-4128-a52c-6054d3a4d27a\": [300], \"3adf988d-e1cd-4e27-9647-102a2f1a04be\": \"GARAGE COMPANY\", \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\": [\"Planning\", \"Web Design\", \"Web Development\", \"Copywriting\"], \"754fcfae-6760-4762-a1dd-3faa42db0b8a\": \"世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。\\n\\n国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるThe Lodgeの空気感を感じていただけるよう配慮しています。\", \"9696d0b2-70c2-4fd7-a41e-6e74da803120\": \"2024\", \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\": \"The Lodge Okinawa\\nTeaser site\", \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\": [296], \"f7ddf1fe-e738-4eb1-8182-f25f3bbf0e8e\": [316]}',1,'2025-03-31 02:25:41','2025-03-31 02:25:41','4a59513f-b4af-4373-a24a-b30d591ed0fa');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (3,1,NULL,NULL,NULL,3,'2025-03-17 05:35:19',NULL,0,0,'2025-03-17 05:35:19','2025-03-17 05:35:19'),(4,1,NULL,NULL,NULL,3,'2025-03-17 05:36:17',NULL,0,0,'2025-03-17 05:36:17','2025-03-17 05:36:17'),(5,1,NULL,NULL,NULL,3,'2025-03-17 05:41:00',NULL,0,0,'2025-03-17 05:38:26','2025-03-17 05:41:47'),(14,1,NULL,NULL,NULL,3,'2025-03-17 05:41:00',NULL,NULL,NULL,'2025-03-17 05:41:47','2025-03-17 05:41:47'),(27,NULL,NULL,5,8,1,'2025-03-17 05:44:00',NULL,0,0,'2025-03-17 05:48:38','2025-03-17 05:48:38'),(28,NULL,NULL,5,8,2,'2025-03-17 05:45:00',NULL,0,0,'2025-03-17 05:48:38','2025-03-17 05:48:38'),(29,1,NULL,NULL,NULL,3,'2025-03-17 05:41:00',NULL,NULL,NULL,'2025-03-17 05:48:38','2025-03-17 05:48:38'),(30,NULL,NULL,29,8,1,'2025-03-17 05:44:00',NULL,NULL,NULL,'2025-03-17 05:48:38','2025-03-17 05:48:38'),(31,NULL,NULL,29,8,2,'2025-03-17 05:45:00',NULL,NULL,NULL,'2025-03-17 05:48:38','2025-03-17 05:48:38'),(32,1,NULL,NULL,NULL,3,'2025-03-17 05:41:00',NULL,NULL,NULL,'2025-03-17 06:04:30','2025-03-17 06:04:30'),(33,NULL,NULL,32,8,1,'2025-03-17 05:44:00',NULL,NULL,NULL,'2025-03-17 06:04:30','2025-03-17 06:04:30'),(34,NULL,NULL,32,8,2,'2025-03-17 05:45:00',NULL,NULL,NULL,'2025-03-17 06:04:30','2025-03-17 06:04:30'),(35,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 06:05:59','2025-03-17 06:07:45'),(36,NULL,NULL,35,8,1,'2025-03-17 06:07:00',NULL,1,NULL,'2025-03-17 06:07:02','2025-03-17 06:07:02'),(38,NULL,NULL,35,8,2,'2025-03-17 06:07:00',NULL,0,0,'2025-03-17 06:07:28','2025-03-17 06:07:29'),(39,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 06:07:45','2025-03-17 06:07:45'),(40,NULL,NULL,39,8,1,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 06:07:45','2025-03-17 06:07:45'),(41,NULL,NULL,39,8,2,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 06:07:45','2025-03-17 06:07:45'),(42,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:11:56','2025-03-17 07:11:56'),(43,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:12:06','2025-03-17 07:12:06'),(45,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:13:17','2025-03-17 07:13:17'),(46,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:13:23','2025-03-17 07:13:23'),(48,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:14:05','2025-03-17 07:14:05'),(50,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:15:00','2025-03-17 07:15:00'),(52,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:18:20','2025-03-17 07:18:20'),(53,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:28:18','2025-03-17 07:28:18'),(54,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:44:26','2025-03-17 07:44:26'),(56,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:45:55','2025-03-17 07:45:55'),(58,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 07:58:25','2025-03-17 07:58:25'),(60,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 08:00:00','2025-03-17 08:00:00'),(61,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-17 08:51:12','2025-03-17 08:51:12'),(67,NULL,NULL,35,8,2,'2025-03-18 03:01:00',NULL,1,NULL,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(68,NULL,NULL,35,8,2,'2025-03-18 03:02:00',NULL,0,0,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(69,NULL,NULL,35,8,2,'2025-03-18 03:02:00',NULL,0,0,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(70,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(71,NULL,NULL,70,8,2,'2025-03-18 03:01:00',NULL,NULL,NULL,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(72,NULL,NULL,70,8,2,'2025-03-18 03:02:00',NULL,NULL,NULL,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(73,NULL,NULL,70,8,2,'2025-03-18 03:02:00',NULL,NULL,NULL,'2025-03-18 03:02:21','2025-03-18 03:02:21'),(77,NULL,NULL,35,8,4,'2025-03-18 03:08:00',NULL,1,NULL,'2025-03-18 03:09:07','2025-03-18 03:09:07'),(78,NULL,NULL,35,8,5,'2025-03-18 03:08:00',NULL,1,NULL,'2025-03-18 03:09:07','2025-03-18 03:09:07'),(79,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-18 03:09:07','2025-03-18 03:09:07'),(80,NULL,NULL,79,8,4,'2025-03-18 03:08:00',NULL,NULL,NULL,'2025-03-18 03:09:07','2025-03-18 03:09:07'),(81,NULL,NULL,79,8,5,'2025-03-18 03:08:00',NULL,NULL,NULL,'2025-03-18 03:09:07','2025-03-18 03:09:07'),(83,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-18 03:59:45','2025-03-18 03:59:45'),(87,NULL,NULL,35,8,6,'2025-03-18 05:27:00',NULL,NULL,NULL,'2025-03-18 05:28:41','2025-03-18 05:28:41'),(88,NULL,NULL,35,8,7,'2025-03-18 05:28:00',NULL,NULL,NULL,'2025-03-18 05:28:41','2025-03-18 05:28:41'),(89,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-18 05:28:41','2025-03-18 05:28:41'),(90,NULL,NULL,89,8,6,'2025-03-18 05:27:00',NULL,NULL,NULL,'2025-03-18 05:28:41','2025-03-18 05:28:41'),(91,NULL,NULL,89,8,7,'2025-03-18 05:28:00',NULL,NULL,NULL,'2025-03-18 05:28:41','2025-03-18 05:28:41'),(92,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-18 05:29:26','2025-03-18 05:29:26'),(93,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:12:29','2025-03-18 07:14:41'),(95,NULL,NULL,93,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:14:11','2025-03-18 07:14:11'),(97,NULL,NULL,93,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:14:30','2025-03-18 07:14:30'),(99,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:14:41','2025-03-18 07:14:41'),(100,NULL,NULL,99,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:14:41','2025-03-18 07:14:41'),(101,NULL,NULL,99,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:14:41','2025-03-18 07:14:41'),(103,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-18 07:15:25','2025-03-18 07:15:25'),(104,2,NULL,NULL,NULL,8,'2025-03-19 02:48:00',NULL,NULL,NULL,'2025-03-19 02:48:35','2025-03-19 02:48:35'),(105,2,NULL,NULL,NULL,8,'2025-03-19 02:48:00',NULL,NULL,NULL,'2025-03-19 02:48:35','2025-03-19 02:48:35'),(106,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:06:57','2025-03-19 03:13:27'),(108,NULL,NULL,106,8,6,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:13:05','2025-03-19 03:13:06'),(110,NULL,NULL,106,8,7,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:13:13','2025-03-19 03:13:14'),(114,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:13:27','2025-03-19 03:13:27'),(115,NULL,NULL,114,8,6,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:13:27','2025-03-19 03:13:27'),(116,NULL,NULL,114,8,7,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:13:27','2025-03-19 03:13:27'),(118,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-19 03:15:53','2025-03-19 03:15:53'),(119,NULL,NULL,118,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-19 03:15:53','2025-03-19 03:15:53'),(120,NULL,NULL,118,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-19 03:15:53','2025-03-19 03:15:53'),(122,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-19 03:15:58','2025-03-19 03:15:58'),(123,NULL,NULL,122,8,6,'2025-03-18 05:27:00',NULL,NULL,NULL,'2025-03-19 03:15:58','2025-03-19 03:15:58'),(124,NULL,NULL,122,8,7,'2025-03-18 05:28:00',NULL,NULL,NULL,'2025-03-19 03:15:58','2025-03-19 03:15:58'),(126,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:16:13','2025-03-19 03:16:13'),(127,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-19 03:17:18','2025-03-19 03:17:18'),(129,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-19 03:24:10','2025-03-19 03:24:10'),(131,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-19 03:24:15','2025-03-19 03:24:15'),(133,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-19 03:45:47','2025-03-19 03:45:47'),(135,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-19 03:46:25','2025-03-19 03:46:25'),(138,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 03:55:06','2025-03-21 03:55:06'),(141,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 03:55:45','2025-03-21 03:55:45'),(144,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-21 03:56:08','2025-03-21 03:56:08'),(148,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 04:11:04','2025-03-21 04:11:04'),(149,NULL,NULL,148,8,6,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 04:11:04','2025-03-21 04:11:04'),(150,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-21 08:02:25','2025-03-21 08:05:14'),(152,NULL,NULL,150,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:04:27','2025-03-21 08:04:27'),(154,NULL,NULL,150,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:04:40','2025-03-21 08:04:41'),(156,NULL,NULL,150,8,7,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:04:53','2025-03-21 08:04:53'),(160,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-21 08:05:14','2025-03-21 08:05:14'),(161,NULL,NULL,160,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:05:14','2025-03-21 08:05:14'),(162,NULL,NULL,160,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:05:14','2025-03-21 08:05:14'),(163,NULL,NULL,160,8,7,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:05:14','2025-03-21 08:05:14'),(167,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-21 08:06:04','2025-03-21 08:06:04'),(168,NULL,NULL,167,8,7,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 08:06:04','2025-03-21 08:06:04'),(176,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 08:24:47','2025-03-21 08:24:47'),(177,NULL,NULL,176,8,6,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 08:24:47','2025-03-21 08:24:47'),(178,NULL,NULL,176,8,7,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 08:24:47','2025-03-21 08:24:47'),(182,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 08:26:03','2025-03-21 08:26:03'),(183,NULL,NULL,182,8,6,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-21 08:26:03','2025-03-21 08:26:03'),(185,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-21 08:27:05','2025-03-21 08:27:05'),(189,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:30:41','2025-03-21 08:30:41'),(192,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:31:46','2025-03-21 08:31:46'),(195,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:36:24','2025-03-21 08:36:24'),(198,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:41:14','2025-03-21 08:41:14'),(201,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:41:59','2025-03-21 08:41:59'),(204,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:47:47','2025-03-21 08:47:47'),(207,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:48:51','2025-03-21 08:48:51'),(210,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:50:00','2025-03-21 08:50:00'),(213,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:52:24','2025-03-21 08:52:24'),(216,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 08:55:05','2025-03-21 08:55:05'),(220,NULL,NULL,35,20,9,'2025-03-21 09:10:00',NULL,1,NULL,'2025-03-21 09:11:13','2025-03-21 09:11:13'),(221,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 09:11:13','2025-03-21 09:11:13'),(222,NULL,NULL,221,20,9,'2025-03-21 09:10:00',NULL,NULL,NULL,'2025-03-21 09:11:13','2025-03-21 09:11:13'),(226,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 09:13:29','2025-03-21 09:13:29'),(227,NULL,NULL,226,20,9,'2025-03-21 09:10:00',NULL,NULL,NULL,'2025-03-21 09:13:29','2025-03-21 09:13:29'),(230,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 09:16:48','2025-03-21 09:16:48'),(233,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 09:17:44','2025-03-21 09:17:44'),(236,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 09:18:39','2025-03-21 09:18:39'),(239,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-21 09:19:11','2025-03-21 09:19:11'),(252,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-21 09:23:01','2025-03-21 09:23:01'),(253,NULL,NULL,252,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 09:23:01','2025-03-21 09:23:01'),(254,NULL,NULL,252,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 09:23:01','2025-03-21 09:23:01'),(255,NULL,NULL,252,8,7,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 09:23:01','2025-03-21 09:23:01'),(256,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-21 09:24:15','2025-03-21 09:29:50'),(259,NULL,NULL,256,8,7,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-21 09:29:10','2025-03-21 09:29:10'),(269,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-21 09:33:29','2025-03-21 09:33:29'),(270,NULL,NULL,269,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-21 09:33:29','2025-03-21 09:33:29'),(271,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-24 00:39:56','2025-03-24 00:39:56'),(272,NULL,NULL,271,8,7,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-24 00:39:56','2025-03-24 00:39:56'),(273,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-24 00:55:27','2025-03-24 00:55:27'),(274,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-24 03:26:36','2025-03-24 03:26:36'),(277,NULL,NULL,256,8,6,'2025-03-24 04:19:00',NULL,0,0,'2025-03-24 04:19:42','2025-03-24 04:19:42'),(278,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-24 04:19:42','2025-03-24 04:19:42'),(279,NULL,NULL,278,8,6,'2025-03-24 04:19:00',NULL,NULL,NULL,'2025-03-24 04:19:42','2025-03-24 04:19:42'),(282,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-24 04:21:19','2025-03-24 04:21:19'),(283,NULL,NULL,282,8,6,'2025-03-24 04:19:00',NULL,NULL,NULL,'2025-03-24 04:21:19','2025-03-24 04:21:19'),(285,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-24 04:21:57','2025-03-24 04:21:57'),(289,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-24 08:37:51','2025-03-24 08:37:51'),(292,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-25 02:45:55','2025-03-25 02:45:55'),(295,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-25 02:47:09','2025-03-25 02:47:09'),(298,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-25 02:48:31','2025-03-25 02:48:31'),(301,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-25 02:53:08','2025-03-25 02:53:08'),(303,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-25 03:03:38','2025-03-25 03:03:38'),(305,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-25 03:04:44','2025-03-25 03:04:44'),(307,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-25 03:05:30','2025-03-25 03:05:30'),(309,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-25 03:05:56','2025-03-25 03:05:56'),(311,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-25 03:06:54','2025-03-25 03:06:54'),(314,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-25 03:38:26','2025-03-25 03:38:26'),(317,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-25 05:35:24','2025-03-25 05:35:24'),(319,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-26 03:20:28','2025-03-26 03:20:28'),(321,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 00:53:00','2025-03-31 00:53:00'),(322,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 00:53:06','2025-03-31 00:53:06'),(324,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 00:55:57','2025-03-31 00:55:57'),(325,NULL,NULL,324,8,7,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 00:55:57','2025-03-31 00:55:57'),(327,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 00:58:52','2025-03-31 00:58:52'),(328,NULL,NULL,327,8,7,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 00:58:52','2025-03-31 00:58:52'),(330,1,NULL,NULL,NULL,3,'2025-03-21 08:05:00',NULL,NULL,NULL,'2025-03-31 00:59:09','2025-03-31 00:59:09'),(331,NULL,NULL,330,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-31 00:59:09','2025-03-31 00:59:09'),(332,NULL,NULL,330,8,6,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-31 00:59:09','2025-03-31 00:59:09'),(333,NULL,NULL,330,8,7,'2025-03-21 08:04:00',NULL,NULL,NULL,'2025-03-31 00:59:09','2025-03-31 00:59:09'),(335,1,NULL,NULL,NULL,3,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-31 00:59:47','2025-03-31 00:59:47'),(336,NULL,NULL,335,8,6,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-31 00:59:47','2025-03-31 00:59:47'),(337,NULL,NULL,335,8,7,'2025-03-19 03:13:00',NULL,NULL,NULL,'2025-03-31 00:59:47','2025-03-31 00:59:47'),(339,1,NULL,NULL,NULL,3,'2025-03-17 06:07:00',NULL,NULL,NULL,'2025-03-31 01:00:00','2025-03-31 01:00:00'),(340,NULL,NULL,339,8,6,'2025-03-18 05:27:00',NULL,NULL,NULL,'2025-03-31 01:00:00','2025-03-31 01:00:00'),(341,NULL,NULL,339,8,7,'2025-03-18 05:28:00',NULL,NULL,NULL,'2025-03-31 01:00:00','2025-03-31 01:00:00'),(343,1,NULL,NULL,NULL,3,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-31 01:00:15','2025-03-31 01:00:15'),(344,NULL,NULL,343,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-31 01:00:15','2025-03-31 01:00:15'),(345,NULL,NULL,343,8,6,'2025-03-18 07:14:00',NULL,NULL,NULL,'2025-03-31 01:00:15','2025-03-31 01:00:15'),(347,1,NULL,NULL,NULL,3,'2025-03-21 09:29:00',NULL,NULL,NULL,'2025-03-31 02:25:41','2025-03-31 02:25:41');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES (3,2,1),(4,2,1),(5,2,1),(14,2,1),(29,2,1),(32,2,1),(35,2,1),(39,2,1),(42,2,1),(43,2,1),(45,2,1),(46,2,1),(48,2,1),(50,2,1),(52,2,1),(53,2,1),(54,2,1),(56,2,1),(58,2,1),(60,2,1),(61,2,1),(70,2,1),(79,2,1),(83,2,1),(89,2,1),(92,2,1),(93,2,1),(99,2,1),(103,2,1),(106,2,1),(114,2,1),(118,2,1),(122,2,1),(126,2,1),(127,2,1),(129,2,1),(131,2,1),(133,2,1),(135,2,1),(138,2,1),(141,2,1),(144,2,1),(148,2,1),(150,2,1),(160,2,1),(167,2,1),(176,2,1),(182,2,1),(185,2,1),(189,2,1),(192,2,1),(195,2,1),(198,2,1),(201,2,1),(204,2,1),(207,2,1),(210,2,1),(213,2,1),(216,2,1),(221,2,1),(226,2,1),(230,2,1),(233,2,1),(236,2,1),(239,2,1),(252,2,1),(256,2,1),(269,2,1),(271,2,1),(273,2,1),(274,2,1),(278,2,1),(282,2,1),(285,2,1),(289,2,1),(292,2,1),(295,2,1),(298,2,1),(301,2,1),(303,2,1),(305,2,1),(307,2,1),(309,2,1),(311,2,1),(314,2,1),(317,2,1),(319,2,1),(321,2,1),(322,2,1),(324,2,1),(327,2,1),(330,2,1),(335,2,1),(339,2,1),(343,2,1),(347,2,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,2,'1カラム画像','contentImageCo1',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-17 03:56:45','2025-03-17 08:05:23','2025-03-18 03:58:42','61bb92ea-08b8-4743-8609-6d0dd7ae0a9e'),(2,3,'スライド画像01','contentSlideImages01',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-17 04:01:14','2025-03-18 03:03:54','2025-03-18 03:58:33','87a68457-070e-40c1-bc4f-fdaac0a48fb6'),(3,4,'Works Entry','worksEntry',NULL,NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2025-03-17 04:14:22','2025-03-31 00:57:17',NULL,'df661a93-b36d-4097-b71a-954549e12cbb'),(4,6,'スライド画像02','contentSlideImages02',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-18 03:07:12','2025-03-18 03:07:12','2025-03-18 03:58:36','cf67f92d-40b1-4976-850f-2913f3d7caba'),(5,7,'スライド画像03','contentSlideImages03',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-18 03:07:34','2025-03-18 03:07:34','2025-03-18 03:58:38','5e53861e-12a5-4222-835e-6bcbb8de1a49'),(6,8,'worksコンテンツ画像１枚','worksContentsImage',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-18 05:22:43','2025-03-18 05:22:43',NULL,'13bc13f8-c9b4-42d9-b39e-66f157aa8554'),(7,9,'worksスライド画像','worksSlideImages',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-18 05:26:11','2025-03-18 05:26:11',NULL,'fa22373c-b2cb-4021-aaad-b1655ebe3179'),(8,10,'Works - Index','worksIndex',NULL,NULL,1,'site',NULL,NULL,0,'site',NULL,0,'2025-03-19 02:44:27','2025-03-19 02:44:27',NULL,'3f9f11ec-2516-48ab-8150-43a411e981cc'),(9,11,'nextエントリコンテンツ画像１枚','nextEntryContentsImage',NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-03-21 09:09:04','2025-03-21 09:09:04','2025-03-21 09:15:25','46770aca-4142-479d-bbd8-8a4932f9d48a');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\User','{\"tabs\": [{\"uid\": \"3b27a07f-7ac0-41ec-b1eb-e7501a101bf7\", \"name\": \"コンテンツ\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"bd6ad611-a407-4510-9c3d-173db261e892\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\users\\\\UsernameField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-03-17T03:38:24+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"3acf37ca-7fb4-43d0-a707-6569a19e4f68\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\users\\\\FullNameField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"fullName\", \"dateAdded\": \"2025-03-17T03:38:24+00:00\", \"inputType\": null, \"requirable\": true, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"cfb64596-147b-4d16-996e-9c593fd1a915\", \"type\": \"craft\\\\fieldlayoutelements\\\\users\\\\PhotoField\", \"label\": null, \"width\": 100, \"warning\": null, \"dateAdded\": \"2025-03-17T03:38:24+00:00\", \"requirable\": false, \"orientation\": null, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a1d144a9-eb21-4aff-a6a7-a923d1d29cfd\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\users\\\\EmailField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-03-17T03:38:24+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [\"id\", \"email\", \"username\", \"lastLoginDate\"]}','2025-03-17 03:39:29','2025-03-17 03:40:05',NULL,'caee186e-03dd-40b9-a2e2-c4be7354368a'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bf18aabc-c6fc-47f9-b716-ab097883d90f\", \"name\": \"コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"ecd53b5a-047f-4f55-b67b-4fb856ac2534\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"414a1587-bd39-4972-9592-f796508591ad\", \"required\": false, \"dateAdded\": \"2025-03-17T03:56:45+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-17 03:56:45','2025-03-17 03:56:45','2025-03-18 03:58:42','04e8ed20-f7c4-4377-9fd5-ed38220c60c7'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"4072eded-e6ee-4877-b04b-2f8ee5c42f77\", \"name\": \"コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"e39f40f6-c603-475c-8f3d-66ac1152b540\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"60bd9d52-0a9e-439b-8284-74c88ed17eac\", \"required\": false, \"dateAdded\": \"2025-03-17T04:01:14+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-17 04:01:14','2025-03-17 04:01:14','2025-03-18 03:58:33','f17383e9-d8ec-47dd-acff-7e7f7fc85021'),(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"8e003d1f-c464-4679-8b4e-642384215822\", \"name\": \"コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"8a6d1f5e-9c85-44b2-a454-d4906858e36c\", \"required\": false, \"dateAdded\": \"2025-03-17T04:14:22+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"f7ddf1fe-e738-4eb1-8182-f25f3bbf0e8e\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"b97dbb57-13da-4446-9e2a-2165bd9a9560\", \"required\": false, \"dateAdded\": \"2025-03-31T02:25:03+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"72db910e-4f53-4c8d-8219-74a498d770f8\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-03-31T00:57:17+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"55477f9c-78c5-4f68-a070-de2d8ad473ab\", \"required\": false, \"dateAdded\": \"2025-03-31T00:55:06+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"754fcfae-6760-4762-a1dd-3faa42db0b8a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"dab1d1ad-6698-4403-a8d7-5eab5fc3ea28\", \"required\": false, \"dateAdded\": \"2025-03-17T04:14:22+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"9696d0b2-70c2-4fd7-a41e-6e74da803120\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"04546a57-f2f5-462c-93ad-04dba5962df5\", \"required\": false, \"dateAdded\": \"2025-03-17T04:14:22+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"3adf988d-e1cd-4e27-9647-102a2f1a04be\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"81ba1093-a582-4e79-a6ed-2be54a743712\", \"required\": false, \"dateAdded\": \"2025-03-17T04:14:22+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce\", \"required\": false, \"dateAdded\": \"2025-03-19T03:15:41+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2\", \"required\": false, \"dateAdded\": \"2025-03-17T07:45:19+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"355ab973-44c6-4128-a52c-6054d3a4d27a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"15978369-dc92-4cc0-ad10-24f4b0ad9b3f\", \"required\": false, \"dateAdded\": \"2025-03-21T09:15:19+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"2a516c28-ca34-4ada-95de-3d4c7841e925\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"841d9c3c-29dd-4cb7-a973-8717b1ebc051\", \"required\": false, \"dateAdded\": \"2025-03-25T03:02:14+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"d0ddd100-7584-45ed-b793-5f297c2a5141\", \"name\": \"自由コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"d2da8d08-2b24-45c1-99c3-8175108615bd\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"f42b1497-cd88-4002-9a50-77a35f41cc0e\", \"required\": false, \"dateAdded\": \"2025-03-18T05:26:58+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [\"id\", \"slug\", \"dateCreated\", \"uri\", \"link\"]}','2025-03-17 04:14:22','2025-03-31 02:25:03',NULL,'7f528141-6957-4f86-b94c-d5ed531a18d7'),(5,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"f463925d-ea61-422f-9d4c-4cdcbd6c6b8f\", \"name\": \"コンテンツ\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"5c4f6ed7-ad97-4fc8-8c5d-ce5934e762f3\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-03-17T05:30:44+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-17 05:34:44','2025-03-17 05:34:44',NULL,'92563543-7016-4c5d-b6f8-b18323066cf0'),(6,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"cb8edc6e-d4a9-4aee-bf64-9499ae1b62b3\", \"name\": \"コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"01de0b68-7515-4b76-a034-be874b652d94\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7a94b27c-2786-43db-bd7d-e7a5883b52d1\", \"required\": false, \"dateAdded\": \"2025-03-18T03:07:12+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-18 03:07:12','2025-03-18 03:07:12','2025-03-18 03:58:36','84b1d8c7-974a-4039-babc-9e8cb8b5d838'),(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"c51ca276-86e3-417e-9a10-39f910052bd0\", \"name\": \"コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"aaca72d6-0ceb-4a43-af11-942b98b568f8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"94b444e0-09e6-4ddd-a2de-73b8f6fc1d90\", \"required\": false, \"dateAdded\": \"2025-03-18T03:07:34+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-18 03:07:34','2025-03-18 03:07:34','2025-03-18 03:58:38','e3a06917-6c94-4eae-b1dd-8c8d96f82444'),(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"06f4c958-74d4-4161-8bc2-3e1e3221b887\", \"name\": \"コンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"40236e76-0b57-4872-9713-a653ef4d83f0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"3172e165-5a99-41e4-876f-6b03fa7dbbf1\", \"required\": false, \"dateAdded\": \"2025-03-18T05:22:43+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-18 05:22:43','2025-03-18 05:22:43',NULL,'482cd17a-6bfb-4030-a9ec-5d4efc7aa674'),(9,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"fc94f871-54d4-48c6-baa6-0af12e068862\", \"name\": \"スライド\", \"elements\": [{\"tip\": null, \"uid\": \"ca1c4dce-e911-4aac-87c4-acef202d13cc\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"83eb390c-c35e-461d-98ba-7f956701ba81\", \"required\": false, \"dateAdded\": \"2025-03-18T05:26:11+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-18 05:26:11','2025-03-18 05:26:11',NULL,'8062995d-d52f-4390-9061-dd5ea0a08a8d'),(10,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"7ed2e9e5-e514-4245-b522-3972875a589a\", \"name\": \"コンテンツ\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"1d0d3901-4a67-4dc4-974e-d413ba3a6f65\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-03-19T02:43:04+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [\"slug\", \"dateCreated\"]}','2025-03-19 02:44:27','2025-03-19 02:44:27',NULL,'06807e81-ef01-4f37-b4e7-f003eda33a5d'),(11,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"b5a69c6e-2c26-4900-8070-50dfbfb7f8ec\", \"name\": \"nextコンテンツ\", \"elements\": [{\"tip\": null, \"uid\": \"dcd89f24-0604-45a5-b2c6-947aa96ff816\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"15978369-dc92-4cc0-ad10-24f4b0ad9b3f\", \"required\": false, \"dateAdded\": \"2025-03-21T09:09:03+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2025-03-21 09:09:04','2025-03-21 09:09:04','2025-03-21 09:15:25','08124406-aa1f-4141-bc3f-6e5cf925d674');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,'worksTOP画像','worksTopImage','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"video\",\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":\"{title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"追加\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2025-03-17 03:43:00','2025-03-21 09:32:52',NULL,'8a6d1f5e-9c85-44b2-a454-d4906858e36c'),(2,'workタイトル','workTitle','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-17 03:49:01','2025-03-17 03:49:01','2025-03-18 05:15:20','d252e305-bd98-448e-8e02-8e5089425142'),(3,'works概要','worksSummary','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-17 03:49:59','2025-03-18 05:16:57',NULL,'dab1d1ad-6698-4403-a8d7-5eab5fc3ea28'),(4,'works公開年','worksYear','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-17 03:50:46','2025-03-18 05:16:50',NULL,'04546a57-f2f5-462c-93ad-04dba5962df5'),(5,'worksクライアント','worksClient','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-17 03:51:44','2025-03-18 05:16:23',NULL,'81ba1093-a582-4e79-a6ed-2be54a743712'),(6,'work作業領域01','workSpace01','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"uiMode\":\"normal\",\"placeholder\":null,\"code\":false,\"multiline\":false,\"initialRows\":4,\"charLimit\":null,\"byteLimit\":null}','2025-03-17 03:53:20','2025-03-17 07:19:31','2025-03-17 07:52:27','e70a8b65-f6e6-4f87-9c5f-50605bde2db0'),(7,'works画像１枚','worksImage1','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-17 03:56:38','2025-03-18 05:18:58','2025-03-18 05:19:58','414a1587-bd39-4972-9592-f796508591ad'),(8,'worksコンテンツ','worksContents','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"entryTypes\":[{\"uid\":\"13bc13f8-c9b4-42d9-b39e-66f157aa8554\"},{\"uid\":\"fa22373c-b2cb-4021-aaad-b1655ebe3179\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":1,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":true,\"viewMode\":\"blocks\"}','2025-03-17 03:57:15','2025-03-18 05:29:52',NULL,'f42b1497-cd88-4002-9a50-77a35f41cc0e'),(9,'workスライド画像01','workSlideImages01','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-17 04:00:56','2025-03-18 03:35:34','2025-03-18 05:15:06','60bd9d52-0a9e-439b-8284-74c88ed17eac'),(10,'work作業領域02','workSpace02','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-17 07:19:52','2025-03-17 07:19:52','2025-03-17 07:52:32','3f53579d-a722-4c31-bb0f-356ec6db99b3'),(11,'works作業領域','worksSpace','global',NULL,NULL,1,'none',NULL,'craft\\fields\\MultiSelect','{\"customOptions\":false,\"options\":[{\"label\":\"Planning\",\"value\":\"Planning\",\"default\":\"\"},{\"label\":\"Web Direction\",\"value\":\"Web Direction\",\"default\":\"\"},{\"label\":\"Web Design\",\"value\":\"Web Design\",\"default\":\"\"},{\"label\":\"Web Development\",\"value\":\"Web Development\",\"default\":\"1\"},{\"label\":\"Photograph\",\"value\":\"Photograph\",\"default\":\"\"},{\"label\":\"Videograph\",\"value\":\"Videograph\",\"default\":\"\"},{\"label\":\"Graphic Design\",\"value\":\"Graphic Design\",\"default\":\"\"},{\"label\":\"Copywriting\",\"value\":\"Copywriting\",\"default\":\"\"},{\"label\":\"Illustration\",\"value\":\"Illustration\",\"default\":\"\"}]}','2025-03-17 07:26:49','2025-03-19 03:27:23',NULL,'2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2'),(12,'workスライド画像02','workSlideImages02','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-18 02:59:10','2025-03-18 03:00:09','2025-03-18 03:02:32','4e08f151-43b4-4cda-9a3f-f65c9a625e0e'),(13,'workスライド画像03','workSlideImages03','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-18 03:00:01','2025-03-18 03:00:01','2025-03-18 03:02:39','1454642c-de85-42ee-9f12-f8eeb50bbe0c'),(14,'workスライド画像02','workSlideImages02','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-18 03:05:48','2025-03-18 03:36:09','2025-03-18 05:15:11','7a94b27c-2786-43db-bd7d-e7a5883b52d1'),(15,'workスライド画像03','workSlideImages03','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-18 03:06:30','2025-03-18 03:36:30','2025-03-18 05:15:13','94b444e0-09e6-4ddd-a2de-73b8f6fc1d90'),(16,'worksコンテンツ画像１枚','worksContentsImage1','global',NULL,NULL,1,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"video\",\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2025-03-18 05:22:01','2025-03-24 04:22:06',NULL,'3172e165-5a99-41e4-876f-6b03fa7dbbf1'),(17,'worksスライド画像','worksSlideImages','global',NULL,NULL,1,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":5,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":\"{owner.title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"スライドを追加\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-03-18 05:24:33','2025-03-21 08:23:37',NULL,'83eb390c-c35e-461d-98ba-7f956701ba81'),(18,'worksエージェント','worksAgent','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-19 03:15:00','2025-03-19 03:15:00',NULL,'ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce'),(19,'nextエントリ画像','nextEntryImage','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":\"{owner.title}\",\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2025-03-21 03:50:07','2025-03-21 09:18:52',NULL,'15978369-dc92-4cc0-ad10-24f4b0ad9b3f'),(20,'nextエントリコンテンツ','nextEntryContents','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"entryTypes\":[{\"uid\":\"46770aca-4142-479d-bbd8-8a4932f9d48a\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":1,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2025-03-21 09:09:27','2025-03-21 09:09:27','2025-03-21 09:14:41','aa0c7e34-3615-462e-92f9-40218bfb42d7'),(21,'worksリンク','worksUrl','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Link','{\"fullGraphqlData\":true,\"maxLength\":255,\"showLabelField\":false,\"typeSettings\":{\"url\":{\"allowRootRelativeUrls\":\"1\",\"allowAnchors\":\"\"}},\"types\":[\"url\"]}','2025-03-25 03:01:55','2025-03-25 03:09:46',NULL,'841d9c3c-29dd-4cb7-a973-8717b1ebc051'),(22,'allowLineBreaks','allowlineBreaks','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":null,\"onLabel\":null}','2025-03-26 03:19:46','2025-03-26 03:19:46','2025-03-26 03:29:25','d09f309d-4d51-44b3-ae09-edfffbc7a776'),(23,'worksタイトル','worksTitle','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":3,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-03-31 00:54:42','2025-03-31 00:55:42',NULL,'55477f9c-78c5-4f68-a070-de2d8ad473ab'),(24,'worksTOP動画','worksTopVideo','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":true,\"allowUploads\":true,\"allowedKinds\":[\"video\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":\"{title}\",\"restrictedLocationSource\":\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"追加\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2025-03-31 02:24:42','2025-03-31 03:07:53',NULL,'b97dbb57-13da-4446-9e2a-2165bd9a9560');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'5.6.11','5.6.0.2',0,'ryvlznvnqead','3@iutxfhdqyd','2025-03-14 01:39:02','2025-03-31 03:07:53','88224994-0f5e-47c6-a1c4-e9c96936f22b');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1743390473'),('email.fromEmail','\"kaori@cdgrph.com\"'),('email.fromName','\"CGtest\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.color','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elementCondition','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.dateAdded','\"2025-03-18T05:22:43+00:00\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.elementCondition','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.fieldUid','\"3172e165-5a99-41e4-876f-6b03fa7dbbf1\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.handle','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.includeInCards','false'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.instructions','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.label','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.providesThumbs','false'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.required','false'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.tip','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.uid','\"40236e76-0b57-4872-9713-a653ef4d83f0\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.userCondition','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.warning','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.elements.0.width','100'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.name','\"コンテンツ\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.uid','\"06f4c958-74d4-4161-8bc2-3e1e3221b887\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.fieldLayouts.482cd17a-6bfb-4030-a9ec-5d4efc7aa674.tabs.0.userCondition','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.handle','\"worksContentsImage\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.hasTitleField','false'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.icon','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.name','\"worksコンテンツ画像１枚\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.showSlugField','true'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.showStatusField','true'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.slugTranslationKeyFormat','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.slugTranslationMethod','\"site\"'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.titleFormat','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.titleTranslationKeyFormat','null'),('entryTypes.13bc13f8-c9b4-42d9-b39e-66f157aa8554.titleTranslationMethod','\"site\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.color','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.cardView.0','\"slug\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.cardView.1','\"dateCreated\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elementCondition','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.autocomplete','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.autocorrect','true'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.class','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.dateAdded','\"2025-03-19T02:43:04+00:00\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.disabled','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.elementCondition','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.id','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.includeInCards','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.inputType','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.instructions','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.label','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.max','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.min','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.name','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.orientation','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.placeholder','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.providesThumbs','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.readonly','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.required','true'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.size','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.step','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.tip','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.title','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.uid','\"1d0d3901-4a67-4dc4-974e-d413ba3a6f65\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.userCondition','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.warning','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.elements.0.width','100'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.name','\"コンテンツ\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.uid','\"7ed2e9e5-e514-4245-b522-3972875a589a\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.fieldLayouts.06807e81-ef01-4f37-b4e7-f003eda33a5d.tabs.0.userCondition','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.handle','\"worksIndex\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.hasTitleField','true'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.icon','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.name','\"Works - Index\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.showSlugField','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.showStatusField','false'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.slugTranslationKeyFormat','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.slugTranslationMethod','\"site\"'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.titleFormat','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.titleTranslationKeyFormat','null'),('entryTypes.3f9f11ec-2516-48ab-8150-43a411e981cc.titleTranslationMethod','\"site\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.color','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.cardView.0','\"id\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.cardView.1','\"slug\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.cardView.2','\"dateCreated\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.cardView.3','\"uri\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.cardView.4','\"link\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.dateAdded','\"2025-03-17T04:14:22+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.fieldUid','\"8a6d1f5e-9c85-44b2-a454-d4906858e36c\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.uid','\"d38b64a8-3532-46dd-a5dc-3d03063ca3ea\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.0.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.dateAdded','\"2025-03-31T02:25:03+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.fieldUid','\"b97dbb57-13da-4446-9e2a-2165bd9a9560\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.uid','\"f7ddf1fe-e738-4eb1-8182-f25f3bbf0e8e\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.1.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.dateAdded','\"2025-03-25T03:02:14+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.fieldUid','\"841d9c3c-29dd-4cb7-a973-8717b1ebc051\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.uid','\"2a516c28-ca34-4ada-95de-3d4c7841e925\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.10.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.autocapitalize','true'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.autocomplete','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.autocorrect','true'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.class','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.dateAdded','\"2025-03-31T00:57:17+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.disabled','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.id','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.inputType','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.max','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.min','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.name','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.orientation','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.placeholder','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.readonly','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.required','true'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.size','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.step','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.title','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.uid','\"72db910e-4f53-4c8d-8219-74a498d770f8\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.2.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.dateAdded','\"2025-03-31T00:55:06+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.fieldUid','\"55477f9c-78c5-4f68-a070-de2d8ad473ab\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.uid','\"ba0c82f9-30d7-4fbc-bc3e-d984926de7a1\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.3.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.dateAdded','\"2025-03-17T04:14:22+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.fieldUid','\"dab1d1ad-6698-4403-a8d7-5eab5fc3ea28\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.uid','\"754fcfae-6760-4762-a1dd-3faa42db0b8a\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.4.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.dateAdded','\"2025-03-17T04:14:22+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.fieldUid','\"04546a57-f2f5-462c-93ad-04dba5962df5\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.uid','\"9696d0b2-70c2-4fd7-a41e-6e74da803120\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.5.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.dateAdded','\"2025-03-17T04:14:22+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.fieldUid','\"81ba1093-a582-4e79-a6ed-2be54a743712\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.uid','\"3adf988d-e1cd-4e27-9647-102a2f1a04be\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.6.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.dateAdded','\"2025-03-19T03:15:41+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.fieldUid','\"ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.uid','\"5d2f578c-8fb7-4774-a7d8-9ae82fe5c749\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.7.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.dateAdded','\"2025-03-17T07:45:19+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.fieldUid','\"2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.uid','\"684dabbe-4100-4d39-ac6e-9d65f2e8aed0\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.8.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.dateAdded','\"2025-03-21T09:15:19+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.fieldUid','\"15978369-dc92-4cc0-ad10-24f4b0ad9b3f\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.uid','\"355ab973-44c6-4128-a52c-6054d3a4d27a\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.elements.9.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.name','\"コンテンツ\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.uid','\"8e003d1f-c464-4679-8b4e-642384215822\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.0.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.dateAdded','\"2025-03-18T05:26:58+00:00\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.elementCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.fieldUid','\"f42b1497-cd88-4002-9a50-77a35f41cc0e\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.handle','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.includeInCards','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.instructions','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.label','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.providesThumbs','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.required','false'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.tip','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.uid','\"d2da8d08-2b24-45c1-99c3-8175108615bd\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.warning','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.elements.0.width','100'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.name','\"自由コンテンツ\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.uid','\"d0ddd100-7584-45ed-b793-5f297c2a5141\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.fieldLayouts.7f528141-6957-4f86-b94c-d5ed531a18d7.tabs.1.userCondition','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.handle','\"worksEntry\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.hasTitleField','true'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.icon','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.name','\"Works Entry\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.showSlugField','true'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.showStatusField','true'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.slugTranslationKeyFormat','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.slugTranslationMethod','\"site\"'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.titleFormat','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.titleTranslationKeyFormat','null'),('entryTypes.df661a93-b36d-4097-b71a-954549e12cbb.titleTranslationMethod','\"site\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.color','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elementCondition','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.dateAdded','\"2025-03-18T05:26:11+00:00\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.elementCondition','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.fieldUid','\"83eb390c-c35e-461d-98ba-7f956701ba81\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.handle','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.includeInCards','false'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.instructions','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.label','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.providesThumbs','false'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.required','false'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.tip','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.uid','\"ca1c4dce-e911-4aac-87c4-acef202d13cc\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.userCondition','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.warning','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.elements.0.width','100'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.name','\"スライド\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.uid','\"fc94f871-54d4-48c6-baa6-0af12e068862\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.fieldLayouts.8062995d-d52f-4390-9061-dd5ea0a08a8d.tabs.0.userCondition','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.handle','\"worksSlideImages\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.hasTitleField','false'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.icon','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.name','\"worksスライド画像\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.showSlugField','true'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.showStatusField','true'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.slugTranslationKeyFormat','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.slugTranslationMethod','\"site\"'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.titleFormat','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.titleTranslationKeyFormat','null'),('entryTypes.fa22373c-b2cb-4021-aaad-b1655ebe3179.titleTranslationMethod','\"site\"'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.columnSuffix','null'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.handle','\"worksYear\"'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.instructions','null'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.name','\"works公開年\"'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.searchable','true'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.byteLimit','null'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.charLimit','null'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.code','false'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.initialRows','4'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.multiline','false'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.placeholder','null'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.settings.uiMode','\"normal\"'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.translationKeyFormat','null'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.translationMethod','\"none\"'),('fields.04546a57-f2f5-462c-93ad-04dba5962df5.type','\"craft\\\\fields\\\\PlainText\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.columnSuffix','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.handle','\"nextEntryImage\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.instructions','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.name','\"nextエントリ画像\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.searchable','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.allowedKinds.0','\"image\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.allowSelfRelations','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.allowSubfolders','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.allowUploads','true'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.branchLimit','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.defaultUploadLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.defaultUploadLocationSubpath','\"{owner.title}\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.maintainHierarchy','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.maxRelations','1'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.minRelations','1'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.previewMode','\"full\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.restrictedDefaultUploadSubpath','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.restrictedLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.restrictedLocationSubpath','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.restrictFiles','true'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.restrictLocation','true'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.selectionLabel','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.showCardsInGrid','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.showSiteMenu','true'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.showUnpermittedFiles','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.showUnpermittedVolumes','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.sources','\"*\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.targetSiteId','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.validateRelatedElements','false'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.settings.viewMode','\"large\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.translationKeyFormat','null'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.translationMethod','\"none\"'),('fields.15978369-dc92-4cc0-ad10-24f4b0ad9b3f.type','\"craft\\\\fields\\\\Assets\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.columnSuffix','null'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.handle','\"worksSpace\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.instructions','null'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.name','\"works作業領域\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.searchable','true'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.customOptions','false'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.0.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.0.__assoc__.0.1','\"Planning\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.0.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.0.__assoc__.1.1','\"Planning\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.0.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.0.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.1.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.1.__assoc__.0.1','\"Web Direction\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.1.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.1.__assoc__.1.1','\"Web Direction\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.1.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.1.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.2.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.2.__assoc__.0.1','\"Web Design\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.2.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.2.__assoc__.1.1','\"Web Design\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.2.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.2.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.3.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.3.__assoc__.0.1','\"Web Development\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.3.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.3.__assoc__.1.1','\"Web Development\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.3.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.3.__assoc__.2.1','\"1\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.4.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.4.__assoc__.0.1','\"Photograph\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.4.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.4.__assoc__.1.1','\"Photograph\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.4.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.4.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.5.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.5.__assoc__.0.1','\"Videograph\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.5.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.5.__assoc__.1.1','\"Videograph\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.5.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.5.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.6.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.6.__assoc__.0.1','\"Graphic Design\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.6.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.6.__assoc__.1.1','\"Graphic Design\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.6.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.6.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.7.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.7.__assoc__.0.1','\"Copywriting\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.7.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.7.__assoc__.1.1','\"Copywriting\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.7.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.7.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.8.__assoc__.0.0','\"label\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.8.__assoc__.0.1','\"Illustration\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.8.__assoc__.1.0','\"value\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.8.__assoc__.1.1','\"Illustration\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.8.__assoc__.2.0','\"default\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.settings.options.8.__assoc__.2.1','\"\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.translationKeyFormat','null'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.translationMethod','\"none\"'),('fields.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2.type','\"craft\\\\fields\\\\MultiSelect\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.columnSuffix','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.handle','\"worksContentsImage1\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.instructions','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.name','\"worksコンテンツ画像１枚\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.searchable','true'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.allowedKinds.0','\"video\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.allowedKinds.1','\"image\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.allowSelfRelations','false'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.allowSubfolders','true'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.allowUploads','true'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.branchLimit','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.defaultUploadLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.defaultUploadLocationSubpath','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.maintainHierarchy','false'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.maxRelations','1'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.minRelations','1'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.previewMode','\"full\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.restrictedDefaultUploadSubpath','\"{owner.title}\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.restrictedLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.restrictedLocationSubpath','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.restrictFiles','true'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.restrictLocation','true'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.selectionLabel','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.showCardsInGrid','false'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.showSiteMenu','true'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.showUnpermittedFiles','false'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.showUnpermittedVolumes','false'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.sources','\"*\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.targetSiteId','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.validateRelatedElements','false'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.settings.viewMode','\"large\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.translationKeyFormat','null'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.translationMethod','\"none\"'),('fields.3172e165-5a99-41e4-876f-6b03fa7dbbf1.type','\"craft\\\\fields\\\\Assets\"'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.columnSuffix','null'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.handle','\"worksTitle\"'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.instructions','null'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.name','\"worksタイトル\"'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.searchable','true'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.byteLimit','null'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.charLimit','null'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.code','false'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.initialRows','3'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.multiline','true'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.placeholder','null'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.settings.uiMode','\"normal\"'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.translationKeyFormat','null'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.translationMethod','\"none\"'),('fields.55477f9c-78c5-4f68-a070-de2d8ad473ab.type','\"craft\\\\fields\\\\PlainText\"'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.columnSuffix','null'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.handle','\"worksClient\"'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.instructions','null'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.name','\"worksクライアント\"'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.searchable','false'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.byteLimit','null'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.charLimit','null'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.code','false'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.initialRows','4'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.multiline','true'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.placeholder','null'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.settings.uiMode','\"normal\"'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.translationKeyFormat','null'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.translationMethod','\"none\"'),('fields.81ba1093-a582-4e79-a6ed-2be54a743712.type','\"craft\\\\fields\\\\PlainText\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.columnSuffix','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.handle','\"worksSlideImages\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.instructions','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.name','\"worksスライド画像\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.searchable','true'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.allowedKinds.0','\"image\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.allowSelfRelations','false'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.allowSubfolders','true'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.allowUploads','true'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.branchLimit','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.defaultUploadLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.defaultUploadLocationSubpath','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.maintainHierarchy','false'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.maxRelations','5'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.minRelations','1'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.previewMode','\"full\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.restrictedDefaultUploadSubpath','\"{owner.title}\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.restrictedLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.restrictedLocationSubpath','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.restrictFiles','true'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.restrictLocation','true'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.selectionLabel','\"スライドを追加\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.showCardsInGrid','false'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.showSiteMenu','true'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.showUnpermittedFiles','false'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.showUnpermittedVolumes','false'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.sources','\"*\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.targetSiteId','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.validateRelatedElements','false'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.settings.viewMode','\"list\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.translationKeyFormat','null'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.translationMethod','\"none\"'),('fields.83eb390c-c35e-461d-98ba-7f956701ba81.type','\"craft\\\\fields\\\\Assets\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.columnSuffix','null'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.handle','\"worksUrl\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.instructions','null'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.name','\"worksリンク\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.searchable','false'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.fullGraphqlData','true'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.maxLength','255'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.showLabelField','false'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.types.0','\"url\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.typeSettings.__assoc__.0.0','\"url\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.typeSettings.__assoc__.0.1.__assoc__.0.0','\"allowRootRelativeUrls\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.typeSettings.__assoc__.0.1.__assoc__.0.1','\"1\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.typeSettings.__assoc__.0.1.__assoc__.1.0','\"allowAnchors\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.settings.typeSettings.__assoc__.0.1.__assoc__.1.1','\"\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.translationKeyFormat','null'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.translationMethod','\"none\"'),('fields.841d9c3c-29dd-4cb7-a973-8717b1ebc051.type','\"craft\\\\fields\\\\Link\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.columnSuffix','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.handle','\"worksTopImage\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.instructions','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.name','\"worksTOP画像\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.searchable','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.allowedKinds.0','\"video\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.allowedKinds.1','\"image\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.allowSelfRelations','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.allowSubfolders','true'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.allowUploads','true'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.branchLimit','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.defaultUploadLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.defaultUploadLocationSubpath','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.maintainHierarchy','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.maxRelations','1'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.minRelations','1'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.previewMode','\"full\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.restrictedDefaultUploadSubpath','\"{title}\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.restrictedLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.restrictedLocationSubpath','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.restrictFiles','true'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.restrictLocation','true'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.selectionLabel','\"追加\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.showCardsInGrid','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.showSiteMenu','true'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.showUnpermittedFiles','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.showUnpermittedVolumes','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.sources','\"*\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.targetSiteId','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.validateRelatedElements','false'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.settings.viewMode','\"large\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.translationKeyFormat','null'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.translationMethod','\"none\"'),('fields.8a6d1f5e-9c85-44b2-a454-d4906858e36c.type','\"craft\\\\fields\\\\Assets\"'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.columnSuffix','null'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.handle','\"worksAgent\"'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.instructions','null'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.name','\"worksエージェント\"'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.searchable','true'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.byteLimit','null'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.charLimit','null'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.code','false'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.initialRows','4'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.multiline','true'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.placeholder','null'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.settings.uiMode','\"normal\"'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.translationKeyFormat','null'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.translationMethod','\"none\"'),('fields.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce.type','\"craft\\\\fields\\\\PlainText\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.columnSuffix','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.handle','\"worksTopVideo\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.instructions','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.name','\"worksTOP動画\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.searchable','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.allowedKinds.0','\"video\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.allowSelfRelations','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.allowSubfolders','true'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.allowUploads','true'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.branchLimit','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.defaultUploadLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.defaultUploadLocationSubpath','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.maintainHierarchy','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.maxRelations','1'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.minRelations','1'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.previewMode','\"full\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.restrictedDefaultUploadSubpath','\"{title}\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.restrictedLocationSource','\"volume:0ec3aa91-e4e8-4340-a06a-519f38ee7424\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.restrictedLocationSubpath','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.restrictFiles','true'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.restrictLocation','true'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.selectionLabel','\"追加\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.showCardsInGrid','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.showSiteMenu','true'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.showUnpermittedFiles','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.showUnpermittedVolumes','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.sources','\"*\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.targetSiteId','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.validateRelatedElements','false'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.settings.viewMode','\"large\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.translationKeyFormat','null'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.translationMethod','\"none\"'),('fields.b97dbb57-13da-4446-9e2a-2165bd9a9560.type','\"craft\\\\fields\\\\Assets\"'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.columnSuffix','null'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.handle','\"worksSummary\"'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.instructions','null'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.name','\"works概要\"'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.searchable','true'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.byteLimit','null'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.charLimit','null'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.code','false'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.initialRows','4'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.multiline','true'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.placeholder','null'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.settings.uiMode','\"normal\"'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.translationKeyFormat','null'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.translationMethod','\"none\"'),('fields.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28.type','\"craft\\\\fields\\\\PlainText\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.columnSuffix','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.handle','\"worksContents\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.instructions','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.name','\"worksコンテンツ\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.searchable','false'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.createButtonLabel','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.defaultIndexViewMode','\"cards\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.entryTypes.0.__assoc__.0.1','\"13bc13f8-c9b4-42d9-b39e-66f157aa8554\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.entryTypes.1.__assoc__.0.0','\"uid\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.entryTypes.1.__assoc__.0.1','\"fa22373c-b2cb-4021-aaad-b1655ebe3179\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.includeTableView','false'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.maxEntries','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.minEntries','1'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.pageSize','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.propagationKeyFormat','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.propagationMethod','\"all\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.showCardsInGrid','true'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.settings.viewMode','\"blocks\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.translationKeyFormat','null'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.translationMethod','\"site\"'),('fields.f42b1497-cd88-4002-9a50-77a35f41cc0e.type','\"craft\\\\fields\\\\Matrix\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"@webroot/uploads\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"/uploads\"'),('meta.__names__.04546a57-f2f5-462c-93ad-04dba5962df5','\"works公開年\"'),('meta.__names__.0ec3aa91-e4e8-4340-a06a-519f38ee7424','\"Work\"'),('meta.__names__.13bc13f8-c9b4-42d9-b39e-66f157aa8554','\"worksコンテンツ画像１枚\"'),('meta.__names__.15978369-dc92-4cc0-ad10-24f4b0ad9b3f','\"nextエントリ画像\"'),('meta.__names__.2a1d939d-8dd8-41f9-ba38-c92b3e2bacb2','\"works作業領域\"'),('meta.__names__.3172e165-5a99-41e4-876f-6b03fa7dbbf1','\"worksコンテンツ画像１枚\"'),('meta.__names__.3a35e34e-277e-47e5-94e8-8f4ff3887ee0','\"Works -Entry\"'),('meta.__names__.3f9f11ec-2516-48ab-8150-43a411e981cc','\"Works - Index\"'),('meta.__names__.55477f9c-78c5-4f68-a070-de2d8ad473ab','\"worksタイトル\"'),('meta.__names__.81ba1093-a582-4e79-a6ed-2be54a743712','\"worksクライアント\"'),('meta.__names__.83eb390c-c35e-461d-98ba-7f956701ba81','\"worksスライド画像\"'),('meta.__names__.841d9c3c-29dd-4cb7-a973-8717b1ebc051','\"worksリンク\"'),('meta.__names__.8a6d1f5e-9c85-44b2-a454-d4906858e36c','\"worksTOP画像\"'),('meta.__names__.ae3c0b97-597c-4f6a-8edc-57c2dd41e5ce','\"worksエージェント\"'),('meta.__names__.b97dbb57-13da-4446-9e2a-2165bd9a9560','\"worksTOP動画\"'),('meta.__names__.bffa93b7-d62e-412f-be4a-661c30b74b33','\"CGtest\"'),('meta.__names__.cc29658c-c25a-4148-9c08-e722eb9a1c7b','\"Works - Index\"'),('meta.__names__.dab1d1ad-6698-4403-a8d7-5eab5fc3ea28','\"works概要\"'),('meta.__names__.df661a93-b36d-4097-b71a-954549e12cbb','\"Works Entry\"'),('meta.__names__.e1547157-8cce-47ee-ad7b-ecafd023889a','\"CGtest\"'),('meta.__names__.f42b1497-cd88-4002-9a50-77a35f41cc0e','\"worksコンテンツ\"'),('meta.__names__.fa22373c-b2cb-4021-aaad-b1655ebe3179','\"worksスライド画像\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.defaultPlacement','\"beginning\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.enableVersioning','true'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.entryTypes.0.uid','\"df661a93-b36d-4097-b71a-954549e12cbb\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.handle','\"worksEntry\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.maxAuthors','1'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.name','\"Works -Entry\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.previewTargets.0.__assoc__.0.1','\"プライマリのエントリページ\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.propagationMethod','\"all\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.enabledByDefault','true'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.hasUrls','true'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.template','\"works/_entry\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.uriFormat','\"works/{slug}\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.structure.maxLevels','null'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.structure.uid','\"e6fbcb61-8cad-49aa-8fef-8f4b68c82cc3\"'),('sections.3a35e34e-277e-47e5-94e8-8f4ff3887ee0.type','\"structure\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.defaultPlacement','\"end\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.enableVersioning','true'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.entryTypes.0.uid','\"3f9f11ec-2516-48ab-8150-43a411e981cc\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.handle','\"worksIndex\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.maxAuthors','1'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.name','\"Works - Index\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.previewTargets.0.__assoc__.0.1','\"プライマリのエントリページ\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.propagationMethod','\"all\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.enabledByDefault','true'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.hasUrls','true'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.template','\"works-index/_entry.twig\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.siteSettings.e1547157-8cce-47ee-ad7b-ecafd023889a.uriFormat','\"works-index\"'),('sections.cc29658c-c25a-4148-9c08-e722eb9a1c7b.type','\"single\"'),('siteGroups.bffa93b7-d62e-412f-be4a-661c30b74b33.name','\"CGtest\"'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.handle','\"default\"'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.hasUrls','true'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.language','\"JA\"'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.name','\"CGtest\"'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.primary','true'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.siteGroup','\"bffa93b7-d62e-412f-be4a-661c30b74b33\"'),('sites.e1547157-8cce-47ee-ad7b-ecafd023889a.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"CGtest\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.6.0.2\"'),('system.timeZone','\"Asia/Tokyo\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.cardView.0','\"id\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.cardView.1','\"email\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.cardView.2','\"username\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.cardView.3','\"lastLoginDate\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elementCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.autocapitalize','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.autocomplete','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.autocorrect','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.class','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.dateAdded','\"2025-03-17T03:38:24+00:00\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.disabled','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.elementCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.id','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.includeInCards','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.inputType','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.instructions','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.label','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.max','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.min','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.name','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.orientation','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.placeholder','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.providesThumbs','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.readonly','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.requirable','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.size','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.step','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.tip','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.title','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\users\\\\UsernameField\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.uid','\"bd6ad611-a407-4510-9c3d-173db261e892\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.userCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.warning','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.0.width','100'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.attribute','\"fullName\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.autocapitalize','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.autocomplete','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.autocorrect','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.class','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.dateAdded','\"2025-03-17T03:38:24+00:00\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.disabled','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.elementCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.id','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.includeInCards','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.inputType','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.instructions','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.label','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.max','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.min','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.name','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.orientation','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.placeholder','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.providesThumbs','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.readonly','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.requirable','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.required','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.size','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.step','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.tip','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.title','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\users\\\\FullNameField\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.uid','\"3acf37ca-7fb4-43d0-a707-6569a19e4f68\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.userCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.warning','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.1.width','100'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.dateAdded','\"2025-03-17T03:38:24+00:00\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.elementCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.id','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.includeInCards','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.instructions','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.label','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.orientation','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.providesThumbs','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.requirable','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.tip','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\users\\\\PhotoField\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.uid','\"cfb64596-147b-4d16-996e-9c593fd1a915\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.userCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.warning','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.2.width','100'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.autocapitalize','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.autocomplete','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.autocorrect','true'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.class','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.dateAdded','\"2025-03-17T03:38:24+00:00\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.disabled','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.elementCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.id','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.includeInCards','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.inputType','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.instructions','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.label','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.max','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.min','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.name','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.orientation','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.placeholder','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.providesThumbs','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.readonly','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.requirable','false'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.size','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.step','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.tip','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.title','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\users\\\\EmailField\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.uid','\"a1d144a9-eb21-4aff-a6a7-a923d1d29cfd\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.userCondition','null'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.elements.3.width','100'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.name','\"コンテンツ\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.uid','\"3b27a07f-7ac0-41ec-b1eb-e7501a101bf7\"'),('users.fieldLayouts.caee186e-03dd-40b9-a2e2-c4be7354368a.tabs.0.userCondition','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.altTranslationKeyFormat','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.altTranslationMethod','\"none\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elementCondition','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.autocapitalize','true'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.autocomplete','false'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.autocorrect','true'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.class','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.dateAdded','\"2025-03-17T05:30:44+00:00\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.disabled','false'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.elementCondition','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.id','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.includeInCards','false'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.inputType','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.instructions','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.label','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.max','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.min','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.name','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.orientation','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.placeholder','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.providesThumbs','false'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.readonly','false'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.requirable','false'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.size','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.step','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.tip','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.title','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.uid','\"5c4f6ed7-ad97-4fc8-8c5d-ce5934e762f3\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.userCondition','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.warning','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.elements.0.width','100'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.name','\"コンテンツ\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.uid','\"f463925d-ea61-422f-9d4c-4cdcbd6c6b8f\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fieldLayouts.92563543-7016-4c5d-b6f8-b18323066cf0.tabs.0.userCondition','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.fs','\"uploads\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.handle','\"work\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.name','\"Work\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.sortOrder','1'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.subpath','\"work\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.titleTranslationKeyFormat','null'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.titleTranslationMethod','\"site\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.transformFs','\"\"'),('volumes.0ec3aa91-e4e8-4340-a06a-519f38ee7424.transformSubpath','\"transform/work\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (8,1,5,NULL,13,1,'2025-03-17 05:40:49','2025-03-17 05:40:49','89dffc8c-8649-4fc8-a4f0-94d34e3f1ef6'),(9,1,14,NULL,13,1,'2025-03-17 05:41:47','2025-03-17 05:41:47','66c4312a-77de-4d7c-973e-c68945c5a2bc'),(19,7,27,NULL,19,1,'2025-03-17 05:48:38','2025-03-17 05:48:38','c870c049-eeff-456e-9906-ab164fe97795'),(20,9,28,NULL,22,1,'2025-03-17 05:48:38','2025-03-17 05:48:38','1327149f-3d1f-4ceb-adfc-f65b08cff527'),(21,9,28,NULL,23,2,'2025-03-17 05:48:38','2025-03-17 05:48:38','c83abeea-3503-413c-aa25-01fdc2a3c2ff'),(22,9,28,NULL,24,3,'2025-03-17 05:48:38','2025-03-17 05:48:38','b4ea125b-2085-409a-a356-0fcda37d8164'),(23,1,29,NULL,13,1,'2025-03-17 05:48:38','2025-03-17 05:48:38','08bbcf87-5edf-4d58-9e0a-341cfd81f9a8'),(24,7,30,NULL,19,1,'2025-03-17 05:48:38','2025-03-17 05:48:38','7725fb64-ec8e-4a1f-93f3-3a6785fff976'),(25,9,31,NULL,22,1,'2025-03-17 05:48:38','2025-03-17 05:48:38','b4ff7107-4f00-4c49-8db4-3fa183e7da7a'),(26,9,31,NULL,23,2,'2025-03-17 05:48:38','2025-03-17 05:48:38','cd5ff825-65a4-4a3d-8a09-7b97af82e21b'),(27,9,31,NULL,24,3,'2025-03-17 05:48:38','2025-03-17 05:48:38','a87c9295-1aee-4197-adeb-b45b8025cf61'),(28,1,32,NULL,13,1,'2025-03-17 06:04:30','2025-03-17 06:04:30','f7b9071e-b468-4a5d-8368-d2caadae362d'),(29,7,33,NULL,19,1,'2025-03-17 06:04:30','2025-03-17 06:04:30','325b7647-2203-46f4-899a-d42a869a05f7'),(30,9,34,NULL,22,1,'2025-03-17 06:04:30','2025-03-17 06:04:30','39fabc52-a3b3-4436-8ff4-42406962cc45'),(31,9,34,NULL,23,2,'2025-03-17 06:04:30','2025-03-17 06:04:30','5ff3126d-0108-45a3-a3e8-d682ce0ab9da'),(32,9,34,NULL,24,3,'2025-03-17 06:04:30','2025-03-17 06:04:30','5ff271cc-200d-49dc-a056-07d185319821'),(33,1,35,NULL,13,1,'2025-03-17 06:06:16','2025-03-17 06:06:16','5cdbfc88-750b-4a05-ad04-88212b891acc'),(34,7,36,NULL,37,1,'2025-03-17 06:07:24','2025-03-17 06:07:24','383299a3-2138-45a6-a560-f99bba5625f2'),(35,9,38,NULL,22,1,'2025-03-17 06:07:34','2025-03-17 06:07:34','07daf3f5-c635-434c-9660-8a944f6ebbcf'),(36,9,38,NULL,23,2,'2025-03-17 06:07:38','2025-03-17 06:07:38','9eb64398-5ac5-4fc8-b86e-94a76a511dc3'),(37,9,38,NULL,24,3,'2025-03-17 06:07:43','2025-03-17 06:07:43','575d89f0-d58a-4e4a-b215-356cede11494'),(38,1,39,NULL,13,1,'2025-03-17 06:07:45','2025-03-17 06:07:45','9dc822be-c0bd-40c6-807f-0c968e4e971e'),(39,7,40,NULL,37,1,'2025-03-17 06:07:45','2025-03-17 06:07:45','ef0a2de9-5aae-4235-bbdb-1f5b5589d6e0'),(40,9,41,NULL,22,1,'2025-03-17 06:07:45','2025-03-17 06:07:45','52480cd2-a848-411a-9079-a80e1b0aeff4'),(41,9,41,NULL,23,2,'2025-03-17 06:07:45','2025-03-17 06:07:45','14bea735-ff46-457b-9aa3-3d9ef5ffa23b'),(42,9,41,NULL,24,3,'2025-03-17 06:07:45','2025-03-17 06:07:45','ffefb228-6f37-4e5a-8751-c43109d82a3d'),(43,1,42,NULL,13,1,'2025-03-17 07:11:56','2025-03-17 07:11:56','52cdcba1-3252-48fe-83d8-9fe618d994e8'),(44,1,43,NULL,13,1,'2025-03-17 07:12:06','2025-03-17 07:12:06','3510bc32-3f3c-4dca-ba64-daf301291288'),(46,1,45,NULL,13,1,'2025-03-17 07:13:17','2025-03-17 07:13:17','475a7006-3dea-4f32-9169-203a5e836639'),(47,1,46,NULL,13,1,'2025-03-17 07:13:23','2025-03-17 07:13:23','a6149826-51fc-4454-8f96-dd8405169571'),(49,1,48,NULL,13,1,'2025-03-17 07:14:05','2025-03-17 07:14:05','4910a8af-5698-4475-aab2-61dcf6e09d3b'),(51,1,50,NULL,13,1,'2025-03-17 07:15:00','2025-03-17 07:15:00','8b9ee391-bd72-4604-9d34-a06e1bd2ad75'),(53,1,52,NULL,13,1,'2025-03-17 07:18:20','2025-03-17 07:18:20','baa41f15-2eff-4b1e-9863-bda4ef04480b'),(54,1,53,NULL,13,1,'2025-03-17 07:28:18','2025-03-17 07:28:18','b390331a-58a4-4773-b0ca-19ca7f31b89e'),(55,1,54,NULL,13,1,'2025-03-17 07:44:26','2025-03-17 07:44:26','5728a078-110c-4d7c-bcdb-43bb4948c3b3'),(57,1,56,NULL,13,1,'2025-03-17 07:45:55','2025-03-17 07:45:55','a6f8da27-ab54-4d4c-8510-220274b28d15'),(59,1,58,NULL,13,1,'2025-03-17 07:58:25','2025-03-17 07:58:25','66f90df8-ac15-4da9-b3a5-b53eb196bf49'),(61,1,60,NULL,13,1,'2025-03-17 08:00:00','2025-03-17 08:00:00','f4473b70-39ac-420e-b703-4a3e1e4ddf33'),(62,1,61,NULL,13,1,'2025-03-17 08:51:12','2025-03-17 08:51:12','44be28a5-8537-4cb3-910b-9f4d0ba2785a'),(67,9,67,NULL,22,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','d903777d-bda3-4003-9975-23b9ce847f7f'),(68,9,68,NULL,23,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','61ef90d7-e72a-495e-85d3-7cfab6848209'),(69,9,69,NULL,24,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','94e2099b-0897-4070-88e5-fc5edd12df75'),(70,1,70,NULL,13,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','d064a2bc-9f9c-4f1b-8117-2a59a0da8ad6'),(71,9,71,NULL,22,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','93261fb4-6ad1-40d9-b576-67d8299aee03'),(72,9,72,NULL,23,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','b8c1f190-273d-4ff0-b80b-59e27f1cc531'),(73,9,73,NULL,24,1,'2025-03-18 03:02:21','2025-03-18 03:02:21','eedd1d2f-28c6-4d4c-8b86-252ecdf1bbc7'),(77,14,77,NULL,23,1,'2025-03-18 03:09:07','2025-03-18 03:09:07','d88b1fd6-26e5-4260-ae86-72bbd07073b5'),(78,15,78,NULL,24,1,'2025-03-18 03:09:07','2025-03-18 03:09:07','46625d73-4a6f-4aa7-bb42-8ca7eaaf5c62'),(79,1,79,NULL,13,1,'2025-03-18 03:09:07','2025-03-18 03:09:07','5de1197e-c11a-47a1-a87d-bb620a7b12e6'),(80,14,80,NULL,23,1,'2025-03-18 03:09:07','2025-03-18 03:09:07','353bae85-3064-4438-b849-4048a1b9b9a2'),(81,15,81,NULL,24,1,'2025-03-18 03:09:07','2025-03-18 03:09:07','afe33046-345e-4f50-afc3-f94247708764'),(91,1,83,NULL,13,1,'2025-03-18 03:59:45','2025-03-18 03:59:45','06054a1e-3dbb-4959-a161-222e6a271be5'),(101,16,87,NULL,37,1,'2025-03-18 05:28:41','2025-03-18 05:28:41','fa7a24e1-cca2-4e3d-be9f-c9f35a928280'),(102,17,88,NULL,22,1,'2025-03-18 05:28:41','2025-03-18 05:28:41','88d35e0c-465e-46d3-8707-5618a1c82749'),(103,17,88,NULL,23,2,'2025-03-18 05:28:41','2025-03-18 05:28:41','c26665d4-f4cc-495b-9ae5-803fa89282ac'),(104,17,88,NULL,24,3,'2025-03-18 05:28:41','2025-03-18 05:28:41','04aff9f8-4554-4999-94d9-18152ccd90d5'),(105,1,89,NULL,13,1,'2025-03-18 05:28:41','2025-03-18 05:28:41','83a85edb-0eea-4106-aef8-d57a01cfa600'),(106,16,90,NULL,37,1,'2025-03-18 05:28:41','2025-03-18 05:28:41','fb5df353-970e-409e-bf2f-3e5af3739dd4'),(107,17,91,NULL,22,1,'2025-03-18 05:28:41','2025-03-18 05:28:41','af14b6a7-a581-42bc-a269-567c384c4635'),(108,17,91,NULL,23,2,'2025-03-18 05:28:41','2025-03-18 05:28:41','df4d5771-f970-424b-8386-e90986133cad'),(109,17,91,NULL,24,3,'2025-03-18 05:28:41','2025-03-18 05:28:41','7a809de7-bfc2-43c9-9224-b14dcaec316c'),(110,1,92,NULL,13,1,'2025-03-18 05:29:26','2025-03-18 05:29:26','387af354-b253-41e2-a0c8-3b4a5810942b'),(111,1,93,NULL,94,1,'2025-03-18 07:12:49','2025-03-18 07:12:49','43d4c06b-a5e3-40d6-8483-acf868a86c24'),(112,16,95,NULL,96,1,'2025-03-18 07:14:28','2025-03-18 07:14:28','2a12d339-8eb6-4240-a6b6-d6f7d0352489'),(113,16,97,NULL,98,1,'2025-03-18 07:14:37','2025-03-18 07:14:37','3d1496e1-7129-4a98-ae69-1498e9df8eb6'),(114,1,99,NULL,94,1,'2025-03-18 07:14:41','2025-03-18 07:14:41','e52f158c-accc-4695-ad2f-7a681bb7e9b2'),(115,16,100,NULL,96,1,'2025-03-18 07:14:41','2025-03-18 07:14:41','a0914bd2-c583-461c-858d-dc090c4239d3'),(116,16,101,NULL,98,1,'2025-03-18 07:14:41','2025-03-18 07:14:41','ab5c9169-0659-44ac-8a11-65d6a09bd4c8'),(118,1,103,NULL,94,1,'2025-03-18 07:15:25','2025-03-18 07:15:25','923959be-3778-416c-a698-b1bea27492c4'),(119,1,106,NULL,107,1,'2025-03-19 03:11:51','2025-03-19 03:11:51','8060320c-a5a1-4c6b-bb7a-b62b6deb25b0'),(124,1,114,NULL,107,1,'2025-03-19 03:13:27','2025-03-19 03:13:27','7e10e296-6ca8-4d0f-a49f-96e4dcf7b5c1'),(125,16,115,NULL,109,1,'2025-03-19 03:13:27','2025-03-19 03:13:27','1b526d7e-8058-4a85-9c3a-e0444a18c433'),(126,17,116,NULL,111,1,'2025-03-19 03:13:27','2025-03-19 03:13:27','e007e77c-aa59-4461-bebb-132a0806ecdf'),(127,17,116,NULL,113,2,'2025-03-19 03:13:27','2025-03-19 03:13:27','3d29fb76-5fe9-4f97-9dad-518c306f112f'),(128,17,116,NULL,112,3,'2025-03-19 03:13:27','2025-03-19 03:13:27','79cbd695-e97c-4066-9fac-1ad4b5e39042'),(130,1,118,NULL,94,1,'2025-03-19 03:15:53','2025-03-19 03:15:53','baf04e7c-abbd-4d4e-82a5-93bfc1b6890d'),(131,16,119,NULL,96,1,'2025-03-19 03:15:53','2025-03-19 03:15:53','fe976d2a-8997-40b1-921c-3f5b02f5880c'),(132,16,120,NULL,98,1,'2025-03-19 03:15:53','2025-03-19 03:15:53','934a5e0a-1006-4b69-9274-6a6b6d1b79d4'),(134,1,122,NULL,13,1,'2025-03-19 03:15:58','2025-03-19 03:15:58','5a673fbc-18da-448f-9bd4-b9f8d0a5614e'),(135,16,123,NULL,37,1,'2025-03-19 03:15:58','2025-03-19 03:15:58','2bead3f4-49b5-4909-b453-8780f33b64f3'),(136,17,124,NULL,22,1,'2025-03-19 03:15:58','2025-03-19 03:15:58','01d4e96f-f03d-4cd6-8cd7-5a8098d2660f'),(137,17,124,NULL,23,2,'2025-03-19 03:15:58','2025-03-19 03:15:58','3a522450-5fdb-421d-a08b-444272d2e738'),(138,17,124,NULL,24,3,'2025-03-19 03:15:58','2025-03-19 03:15:58','35a2e16a-e708-4d65-9e2f-e83bc29081c9'),(140,1,126,NULL,107,1,'2025-03-19 03:16:13','2025-03-19 03:16:13','289d48f8-1089-47b7-9875-5c62fd994f70'),(141,1,127,NULL,107,1,'2025-03-19 03:17:18','2025-03-19 03:17:18','ca24d128-27a8-4e51-b8c4-355593c86be1'),(143,1,129,NULL,13,1,'2025-03-19 03:24:10','2025-03-19 03:24:10','58dfc6a1-a736-41af-8179-f6229480d900'),(145,1,131,NULL,94,1,'2025-03-19 03:24:15','2025-03-19 03:24:15','973224f8-255b-4fe5-ab9c-b8e215c4ace6'),(147,1,133,NULL,94,1,'2025-03-19 03:45:47','2025-03-19 03:45:47','7c238505-6d51-4a6a-af04-b0fa3e6500a6'),(149,1,135,NULL,94,1,'2025-03-19 03:46:25','2025-03-19 03:46:25','ac13a114-c075-42e1-a65b-fe1cbd32bf60'),(152,19,106,NULL,136,1,'2025-03-21 03:55:06','2025-03-21 03:55:06','10fd2d04-85d1-4818-9554-d5c74b5b8acd'),(153,1,138,NULL,107,1,'2025-03-21 03:55:06','2025-03-21 03:55:06','a47a9de6-fab4-45cd-8948-1c8b79827fbd'),(154,19,138,NULL,136,1,'2025-03-21 03:55:06','2025-03-21 03:55:06','f4fff2b8-80b2-4972-8041-6f5b8dd0b831'),(158,1,141,NULL,13,1,'2025-03-21 03:55:45','2025-03-21 03:55:45','0ef56ccb-361b-4f5b-bdaa-da4ac140c8aa'),(159,19,141,NULL,139,1,'2025-03-21 03:55:45','2025-03-21 03:55:45','21f32e17-d57c-44a9-82bf-5bff3fe2ea1b'),(163,1,144,NULL,94,1,'2025-03-21 03:56:08','2025-03-21 03:56:08','380eea92-9611-4e8f-9a11-d902ae999452'),(164,19,144,NULL,142,1,'2025-03-21 03:56:08','2025-03-21 03:56:08','a384b42e-ff6b-4f04-9b7e-813798bce0bd'),(170,1,148,NULL,107,1,'2025-03-21 04:11:04','2025-03-21 04:11:04','cde959b8-32dc-4752-a603-d7809c5ab55f'),(171,19,148,NULL,136,1,'2025-03-21 04:11:04','2025-03-21 04:11:04','40f980dc-90b5-48e9-9923-049c4a18545b'),(172,16,149,NULL,147,1,'2025-03-21 04:11:04','2025-03-21 04:11:04','29b1b2a6-cb57-4f52-aac6-0f4198811b9b'),(180,1,160,NULL,151,1,'2025-03-21 08:05:14','2025-03-21 08:05:14','d3efa845-6b93-4990-9670-767b784a41cc'),(181,19,160,NULL,151,1,'2025-03-21 08:05:14','2025-03-21 08:05:14','16810ad7-681d-4eeb-88af-9e507fb8560f'),(182,16,161,NULL,153,1,'2025-03-21 08:05:14','2025-03-21 08:05:14','82995e19-a287-4e1b-bdd8-35c9277f56f3'),(183,16,162,NULL,155,1,'2025-03-21 08:05:14','2025-03-21 08:05:14','d549258a-0564-41e0-8059-95fa43c83b39'),(184,17,163,NULL,157,1,'2025-03-21 08:05:14','2025-03-21 08:05:14','56236bc1-113a-4043-bf71-3c898cb6c1a6'),(185,17,163,NULL,158,2,'2025-03-21 08:05:14','2025-03-21 08:05:14','139b152d-5bcf-42f0-b106-2748263390bf'),(186,17,163,NULL,159,3,'2025-03-21 08:05:14','2025-03-21 08:05:14','bea0fb61-6b35-4eae-8930-0eaca83785bd'),(194,1,167,NULL,151,1,'2025-03-21 08:06:04','2025-03-21 08:06:04','270f01a4-b0e3-4748-bd40-63751ec09d5e'),(195,19,167,NULL,151,1,'2025-03-21 08:06:04','2025-03-21 08:06:04','7b8356fe-a58b-4d8a-9fb0-98e610993ccb'),(196,17,168,NULL,157,1,'2025-03-21 08:06:04','2025-03-21 08:06:04','b0196669-6709-4ef0-af77-732b15e93e2e'),(197,17,168,NULL,158,2,'2025-03-21 08:06:04','2025-03-21 08:06:04','cfd1430f-b674-430a-888c-243e9019664a'),(198,17,168,NULL,164,3,'2025-03-21 08:06:04','2025-03-21 08:06:04','6f3f4739-2c73-42c3-9b72-7f2ce84b5434'),(199,17,168,NULL,159,4,'2025-03-21 08:06:04','2025-03-21 08:06:04','c5bc13b6-e874-4d4e-8a95-050748a35135'),(211,17,110,NULL,172,1,'2025-03-21 08:24:47','2025-03-21 08:24:47','5064f084-8fc8-4213-a5a4-87c4554b2267'),(212,17,110,NULL,175,2,'2025-03-21 08:24:47','2025-03-21 08:24:47','69a6b60c-1050-4789-8167-1f421cd0b222'),(213,17,110,NULL,173,3,'2025-03-21 08:24:47','2025-03-21 08:24:47','3adbdec3-81d6-445a-99d3-0319f5726473'),(214,1,176,NULL,107,1,'2025-03-21 08:24:47','2025-03-21 08:24:47','f720cc4c-9d9f-4fb5-a95c-349f82caee48'),(215,19,176,NULL,136,1,'2025-03-21 08:24:47','2025-03-21 08:24:47','98b2184b-9d6c-4d98-bd3f-3462bc04a9a9'),(216,16,177,NULL,171,1,'2025-03-21 08:24:47','2025-03-21 08:24:47','d9380484-d4e0-4cb6-80b0-6ee5b187a711'),(217,17,178,NULL,172,1,'2025-03-21 08:24:47','2025-03-21 08:24:47','ac625483-88be-43ef-8212-dbf408c3f133'),(218,17,178,NULL,175,2,'2025-03-21 08:24:47','2025-03-21 08:24:47','23395da9-ff7d-4d4d-a74b-552ed78a79ae'),(219,17,178,NULL,173,3,'2025-03-21 08:24:47','2025-03-21 08:24:47','c0b1e054-55f4-4bc0-9e40-eb3c6482ddd0'),(224,16,108,NULL,179,1,'2025-03-21 08:26:03','2025-03-21 08:26:03','c48a9e4b-5c30-4242-97d7-2b19789d3303'),(225,1,182,NULL,107,1,'2025-03-21 08:26:03','2025-03-21 08:26:03','a7b1e270-ff31-40f6-9827-b983a69f3069'),(226,19,182,NULL,136,1,'2025-03-21 08:26:03','2025-03-21 08:26:03','f3b95009-8ae6-488a-a5b8-94c4dbc735ac'),(227,16,183,NULL,179,1,'2025-03-21 08:26:03','2025-03-21 08:26:03','26f4507c-3959-4a5d-8875-3d3bae8c7acf'),(231,19,93,NULL,94,1,'2025-03-21 08:27:05','2025-03-21 08:27:05','30d7f6fc-b7fe-419b-9a84-af3bd5f8577b'),(232,1,185,NULL,94,1,'2025-03-21 08:27:05','2025-03-21 08:27:05','217516b4-f62e-479a-943a-1246b7716c04'),(233,19,185,NULL,94,1,'2025-03-21 08:27:05','2025-03-21 08:27:05','479395bd-5739-4496-b4fe-e2d61ffdca33'),(240,1,189,NULL,13,1,'2025-03-21 08:30:41','2025-03-21 08:30:41','1b1a3579-07bb-41e4-9a38-000a9f1bdb71'),(241,19,189,NULL,187,1,'2025-03-21 08:30:41','2025-03-21 08:30:41','0402d1be-b78c-478f-9318-72adf8444b50'),(246,1,192,NULL,13,1,'2025-03-21 08:31:46','2025-03-21 08:31:46','be09e3ee-5504-4158-a02b-ae4c301efbd6'),(247,19,192,NULL,190,1,'2025-03-21 08:31:46','2025-03-21 08:31:46','df851a0b-0eb6-40ad-968d-b31d2be7deff'),(252,1,195,NULL,13,1,'2025-03-21 08:36:24','2025-03-21 08:36:24','95443469-62a6-472d-ad45-3ac5eeef10aa'),(253,19,195,NULL,193,1,'2025-03-21 08:36:24','2025-03-21 08:36:24','56a7b08f-9b26-4b73-b501-1b0f5e287795'),(258,1,198,NULL,13,1,'2025-03-21 08:41:14','2025-03-21 08:41:14','f4e53b21-9f3a-43ae-a1a0-fbfda63d9036'),(259,19,198,NULL,197,1,'2025-03-21 08:41:14','2025-03-21 08:41:14','e46f8be6-a744-4280-8fd4-1566bdd6f58c'),(264,1,201,NULL,13,1,'2025-03-21 08:41:59','2025-03-21 08:41:59','ab815032-1478-4da2-b6f0-9bd1e789c6e8'),(265,19,201,NULL,199,1,'2025-03-21 08:41:59','2025-03-21 08:41:59','0153477c-4793-4126-a178-665a8e2bdd6d'),(270,1,204,NULL,13,1,'2025-03-21 08:47:47','2025-03-21 08:47:47','367d2896-2212-4aef-85db-6eea25b3e6e5'),(271,19,204,NULL,202,1,'2025-03-21 08:47:47','2025-03-21 08:47:47','85bd2c78-90e3-41ac-86c6-c0fdb5d85d3f'),(276,1,207,NULL,13,1,'2025-03-21 08:48:51','2025-03-21 08:48:51','f68cda76-aace-4388-b081-843a918119b4'),(277,19,207,NULL,205,1,'2025-03-21 08:48:51','2025-03-21 08:48:51','71112a93-f7f4-4227-ab26-9ecf2b68b1f3'),(282,1,210,NULL,13,1,'2025-03-21 08:50:00','2025-03-21 08:50:00','b2edcbd9-a2a0-4521-a744-ddeb2258aadc'),(283,19,210,NULL,208,1,'2025-03-21 08:50:00','2025-03-21 08:50:00','0f67be44-d9cf-4a8f-8826-0524b0fa2ff9'),(288,1,213,NULL,13,1,'2025-03-21 08:52:24','2025-03-21 08:52:24','5bb496f8-4c7c-4bf3-9602-eefc1da99f72'),(289,19,213,NULL,211,1,'2025-03-21 08:52:24','2025-03-21 08:52:24','8fb808ab-c281-4da3-a461-a05fe41afe2c'),(294,1,216,NULL,13,1,'2025-03-21 08:55:05','2025-03-21 08:55:05','d1e2c92a-2488-4952-9d46-6180539164d6'),(295,19,216,NULL,214,1,'2025-03-21 08:55:05','2025-03-21 08:55:05','7939ac5d-3ec2-445c-b599-3aba8ee90023'),(299,1,221,NULL,13,1,'2025-03-21 09:11:13','2025-03-21 09:11:13','10b6902d-4c33-453f-80fb-6bb7c7a4bc72'),(300,19,222,NULL,219,1,'2025-03-21 09:11:13','2025-03-21 09:11:13','590fb614-17e4-44f2-b399-b7babcd1c8e2'),(304,19,220,NULL,223,1,'2025-03-21 09:13:29','2025-03-21 09:13:29','4bef62a3-75c3-4aa1-a19b-f819f5867265'),(305,1,226,NULL,13,1,'2025-03-21 09:13:29','2025-03-21 09:13:29','8e8a88e7-bce1-41f2-8138-b42ec75b16e9'),(306,19,227,NULL,223,1,'2025-03-21 09:13:29','2025-03-21 09:13:29','77f24ad9-c89a-4dd4-9ca9-7b72f6def854'),(310,1,230,NULL,13,1,'2025-03-21 09:16:48','2025-03-21 09:16:48','d996b0c9-bf28-4530-a0b4-198f8c3c10a2'),(311,19,230,NULL,228,1,'2025-03-21 09:16:48','2025-03-21 09:16:48','72a5a7d4-c2ac-4c1c-931b-6a0e1c540be2'),(316,1,233,NULL,13,1,'2025-03-21 09:17:44','2025-03-21 09:17:44','2008ec27-6667-44f3-a78f-35ad1cd2bd9f'),(317,19,233,NULL,231,1,'2025-03-21 09:17:44','2025-03-21 09:17:44','d5a22945-e82f-498d-9c32-1baad505e649'),(322,1,236,NULL,13,1,'2025-03-21 09:18:39','2025-03-21 09:18:39','e8e6fc38-5441-4dda-a5f7-59fd53a9e71b'),(323,19,236,NULL,234,1,'2025-03-21 09:18:39','2025-03-21 09:18:39','a079b5c3-a562-4e71-9755-867a832bab17'),(327,19,35,NULL,237,1,'2025-03-21 09:19:11','2025-03-21 09:19:11','9ee28440-77ca-482d-87a8-4a129480307f'),(328,1,239,NULL,13,1,'2025-03-21 09:19:11','2025-03-21 09:19:11','ac1c1d79-7839-4a58-a303-4140f7ac56ca'),(329,19,239,NULL,237,1,'2025-03-21 09:19:11','2025-03-21 09:19:11','d4548650-64ff-4b8a-9836-f4cc277aba74'),(347,16,152,NULL,243,1,'2025-03-21 09:23:01','2025-03-21 09:23:01','05d0638b-5418-49ae-b0e5-9262718639fb'),(349,17,156,NULL,240,1,'2025-03-21 09:23:01','2025-03-21 09:23:01','96d1ebf3-c2b2-424f-b594-ec574c2b4312'),(350,17,156,NULL,241,2,'2025-03-21 09:23:01','2025-03-21 09:23:01','9e0a460a-e399-472c-9208-43619064fec1'),(351,17,156,NULL,246,3,'2025-03-21 09:23:01','2025-03-21 09:23:01','0c59e451-35fe-40bb-954d-63ac1199d762'),(352,17,156,NULL,245,4,'2025-03-21 09:23:01','2025-03-21 09:23:01','d546c6ec-bf46-491c-a675-073163ae08c4'),(353,1,252,NULL,247,1,'2025-03-21 09:23:01','2025-03-21 09:31:01','dafcdba7-5cf1-404b-b715-0c5980bd60f0'),(354,19,252,NULL,248,1,'2025-03-21 09:23:01','2025-03-21 09:23:01','ba058eb5-729e-4f65-9795-469bba1e3d35'),(355,16,253,NULL,243,1,'2025-03-21 09:23:01','2025-03-21 09:23:01','89a510c7-ff12-413c-85e1-6238e6028c8f'),(356,16,254,NULL,248,1,'2025-03-21 09:23:01','2025-03-21 09:30:56','485ef95a-55eb-45ae-acda-ef34f6965dfc'),(357,17,255,NULL,240,1,'2025-03-21 09:23:01','2025-03-21 09:23:01','80708ac6-e473-474a-b14f-e535c7fc8f2e'),(358,17,255,NULL,241,2,'2025-03-21 09:23:01','2025-03-21 09:23:01','7010b6de-f4cf-42d7-8bc4-5aced33e945c'),(359,17,255,NULL,246,3,'2025-03-21 09:23:01','2025-03-21 09:23:01','0e99b266-96e7-4078-874f-b45643aec6f1'),(360,17,255,NULL,245,4,'2025-03-21 09:23:01','2025-03-21 09:23:01','b0d863f0-18d6-41b1-aff1-7d8e1fee40c3'),(363,17,259,NULL,260,1,'2025-03-21 09:29:19','2025-03-21 09:29:19','b491081f-a19c-483f-a436-ac37bc419749'),(364,17,259,NULL,261,4,'2025-03-21 09:29:20','2025-03-21 09:29:25','abd33321-f4da-4ead-a3f8-b8326e00067b'),(365,17,259,NULL,262,3,'2025-03-21 09:29:21','2025-03-21 09:29:25','35150fda-1923-4251-bb6b-e9d727633e89'),(366,17,259,NULL,263,2,'2025-03-21 09:29:21','2025-03-21 09:29:23','5386c421-2088-4538-8ece-c6d679a1eced'),(373,1,150,NULL,265,1,'2025-03-21 09:33:29','2025-03-21 09:33:29','70d622dc-3bd9-40ac-9437-de345aeef6ff'),(374,16,154,NULL,267,1,'2025-03-21 09:33:29','2025-03-21 09:33:29','0996a135-f3ed-4cd5-bb44-4c0d2fde2d12'),(375,1,269,NULL,265,1,'2025-03-21 09:33:29','2025-03-21 09:33:29','9b18d1f9-9b4b-4f2f-9b5b-fdfe6c948ef9'),(376,19,269,NULL,248,1,'2025-03-21 09:33:29','2025-03-21 09:33:29','cce43339-e993-4879-8df7-5cd04bab615b'),(377,16,270,NULL,267,1,'2025-03-21 09:33:29','2025-03-21 09:33:29','cd67f1e9-a19c-4c29-a05c-4d501996a97c'),(378,1,271,NULL,258,1,'2025-03-24 00:39:56','2025-03-24 00:39:56','5f48f6b6-82c1-4d3c-8224-2caa0713f8bc'),(379,19,271,NULL,264,1,'2025-03-24 00:39:56','2025-03-24 00:39:56','78ccdb86-a1cd-4e14-af1e-1aea27d0ea14'),(380,17,272,NULL,260,1,'2025-03-24 00:39:56','2025-03-24 00:39:56','fc433246-ba30-483e-ac92-2bed5c7d18e4'),(381,17,272,NULL,263,2,'2025-03-24 00:39:56','2025-03-24 00:39:56','38534717-f28e-4029-99ed-e0a638e12358'),(382,17,272,NULL,262,3,'2025-03-24 00:39:56','2025-03-24 00:39:56','8eca4068-8f66-4b04-8954-fbe0e049c3c2'),(383,17,272,NULL,261,4,'2025-03-24 00:39:56','2025-03-24 00:39:56','c09ded4c-1f90-43d5-a81c-c71720b8ec15'),(384,1,273,NULL,94,1,'2025-03-24 00:55:27','2025-03-24 00:55:27','7a85a436-e033-49e8-9359-8f27c001bb5e'),(385,19,273,NULL,94,1,'2025-03-24 00:55:27','2025-03-24 00:55:27','83077363-e6e1-49a6-9bcd-ee33122deba3'),(386,1,274,NULL,94,1,'2025-03-24 03:26:36','2025-03-24 03:26:36','dcd3de8b-d624-4c42-a4b2-38556ae8d496'),(387,19,274,NULL,94,1,'2025-03-24 03:26:36','2025-03-24 03:26:36','24706b60-9ef3-4d19-a433-deb6b6e03f1f'),(390,1,278,NULL,258,1,'2025-03-24 04:19:42','2025-03-24 04:19:42','92fe01c9-e77b-4dbe-8ea1-383db80b2594'),(391,19,278,NULL,264,1,'2025-03-24 04:19:42','2025-03-24 04:19:42','824ea09c-1422-4a25-a0e8-1c72f9dc3a31'),(395,16,277,NULL,258,1,'2025-03-24 04:21:19','2025-03-24 04:21:19','cb0f14c5-01e7-4498-8d10-c14f7d0aec87'),(396,1,282,NULL,258,1,'2025-03-24 04:21:19','2025-03-24 04:21:19','b0ceb028-b05c-4f80-afb7-c0839c524619'),(397,19,282,NULL,264,1,'2025-03-24 04:21:19','2025-03-24 04:21:19','f2a84460-2682-4eb5-a503-187221ee3799'),(398,16,283,NULL,258,1,'2025-03-24 04:21:19','2025-03-24 04:21:19','6112f014-d3f0-4e34-8b4e-9f916aa48630'),(401,1,285,NULL,258,1,'2025-03-24 04:21:57','2025-03-24 04:21:57','f1e8c2b6-c63f-41eb-8e42-2071eac9aa32'),(402,19,285,NULL,264,1,'2025-03-24 04:21:57','2025-03-24 04:21:57','4e699310-d075-43b2-b6bc-057fe7e79e42'),(407,1,289,NULL,258,1,'2025-03-24 08:37:51','2025-03-24 08:37:51','8ebe3118-1d4d-4d50-947f-ba6aa1811e8c'),(408,19,289,NULL,288,1,'2025-03-24 08:37:51','2025-03-24 08:37:51','1bb114bb-2203-44eb-84bf-bb6cb824d946'),(413,1,292,NULL,258,1,'2025-03-25 02:45:55','2025-03-25 02:45:55','3ac6c56c-f21e-45ef-86ec-fdd22508d15a'),(414,19,292,NULL,291,1,'2025-03-25 02:45:55','2025-03-25 02:45:55','ccc7993a-83cb-4043-95f4-ae14ecd2e7b9'),(419,1,295,NULL,258,1,'2025-03-25 02:47:09','2025-03-25 02:47:09','d1dc7369-6e02-408e-aa8c-88ab9ac2000e'),(420,19,295,NULL,293,1,'2025-03-25 02:47:09','2025-03-25 02:47:09','c116a1fa-71b2-4514-8528-b953e534670e'),(425,1,298,NULL,296,1,'2025-03-25 02:48:31','2025-03-25 02:48:31','c45ceb4f-5163-4869-aa04-e6ea57aec6fa'),(426,19,298,NULL,293,1,'2025-03-25 02:48:31','2025-03-25 02:48:31','7c073860-143d-461a-b0af-7080dd4ffc35'),(430,19,256,NULL,300,1,'2025-03-25 02:53:08','2025-03-25 02:53:08','ff575628-3ef2-4ddc-96ee-679ccc2e2ef3'),(431,1,301,NULL,296,1,'2025-03-25 02:53:08','2025-03-25 02:53:08','4f08e920-1fbb-4568-a9ff-ffc0fc2927ee'),(432,19,301,NULL,300,1,'2025-03-25 02:53:08','2025-03-25 02:53:08','3a5dc375-ddfd-4913-be0f-ff2e0ec90931'),(435,1,303,NULL,94,1,'2025-03-25 03:03:38','2025-03-25 03:03:38','742f261a-af06-4bfe-ba78-ee566a3a091a'),(436,19,303,NULL,94,1,'2025-03-25 03:03:38','2025-03-25 03:03:38','87f2f72d-52e5-4a3c-be9f-59114faf468f'),(439,1,305,NULL,13,1,'2025-03-25 03:04:44','2025-03-25 03:04:44','b3bda1bb-fcfb-4741-b9d3-d1c9dc4cff4d'),(440,19,305,NULL,237,1,'2025-03-25 03:04:44','2025-03-25 03:04:44','31c3efa3-8f42-45c0-b6e2-a0d6c79d81b3'),(443,1,307,NULL,265,1,'2025-03-25 03:05:30','2025-03-25 03:05:30','e543a579-f01c-41ee-af4b-bbbe27b3db3f'),(444,19,307,NULL,248,1,'2025-03-25 03:05:30','2025-03-25 03:05:30','be2bb36e-9eb4-4467-acd1-a6ee0fb24e5a'),(447,1,309,NULL,107,1,'2025-03-25 03:05:56','2025-03-25 03:05:56','75d91f23-ac93-4423-84b9-09178b97562b'),(448,19,309,NULL,136,1,'2025-03-25 03:05:56','2025-03-25 03:05:56','c5cbe6a4-30ad-4d33-b624-a8b008df301e'),(451,1,311,NULL,296,1,'2025-03-25 03:06:54','2025-03-25 03:06:54','26cd8569-9843-4300-be07-65439d148aae'),(452,19,311,NULL,300,1,'2025-03-25 03:06:54','2025-03-25 03:06:54','20f9d8a9-b4a3-4b73-a87d-b07c937f57ff'),(456,19,150,NULL,313,1,'2025-03-25 03:38:26','2025-03-25 03:38:26','29cc8121-595f-4a23-9613-254f917380a6'),(457,1,314,NULL,265,1,'2025-03-25 03:38:26','2025-03-25 03:38:26','641153ca-ddab-4023-8cf0-fd4305184fbd'),(458,19,314,NULL,313,1,'2025-03-25 03:38:26','2025-03-25 03:38:26','d06c340d-73fe-4314-ac02-f433c5b1069d'),(463,1,317,NULL,316,1,'2025-03-25 05:35:24','2025-03-25 05:35:24','712eae04-53aa-4dee-96c3-5e27b2043769'),(464,19,317,NULL,300,1,'2025-03-25 05:35:24','2025-03-25 05:35:24','2122d315-1f27-4ad1-92a8-dd361eda419b'),(467,1,319,NULL,13,1,'2025-03-26 03:20:28','2025-03-26 03:20:28','60a550c3-0499-485e-9652-a7ee4c32cf93'),(468,19,319,NULL,237,1,'2025-03-26 03:20:28','2025-03-26 03:20:28','114a11f5-9586-47f8-86a4-8e608725d95b'),(471,1,321,NULL,316,1,'2025-03-31 00:53:00','2025-03-31 00:53:00','c6abd9f5-f655-46bc-9220-6b9f23ab2585'),(472,19,321,NULL,300,1,'2025-03-31 00:53:00','2025-03-31 00:53:00','f8fdcf8c-b538-46a5-8785-f4fa07477dc1'),(473,1,322,NULL,316,1,'2025-03-31 00:53:06','2025-03-31 00:53:06','4baaa4fe-579b-4b6c-8e4e-4192ad642e1e'),(474,19,322,NULL,300,1,'2025-03-31 00:53:06','2025-03-31 00:53:06','577c3fa8-66a8-4198-8f93-65a833364b1b'),(477,1,324,NULL,316,1,'2025-03-31 00:55:57','2025-03-31 00:55:57','29595bdd-3021-44d7-b7ea-f44c19167594'),(478,19,324,NULL,300,1,'2025-03-31 00:55:57','2025-03-31 00:55:57','58be8d1e-a4a7-464b-b6a2-7f6023991328'),(479,17,325,NULL,260,1,'2025-03-31 00:55:57','2025-03-31 00:55:57','5e2797e8-cc70-45e8-88f6-7124cf9bb6dc'),(480,17,325,NULL,263,2,'2025-03-31 00:55:57','2025-03-31 00:55:57','382d3f8b-086a-478a-99fc-0470940f12db'),(481,17,325,NULL,262,3,'2025-03-31 00:55:57','2025-03-31 00:55:57','bb37ef71-34a6-4739-a2e3-f019b4385551'),(482,17,325,NULL,261,4,'2025-03-31 00:55:57','2025-03-31 00:55:57','ea998832-e4a3-442b-ad74-66eecc4b71d6'),(485,1,327,NULL,316,1,'2025-03-31 00:58:52','2025-03-31 00:58:52','cf212ab5-9f11-4178-89ca-171d720a0f7a'),(486,19,327,NULL,300,1,'2025-03-31 00:58:52','2025-03-31 00:58:52','2e9fb00e-10ed-418d-ad1c-2024f9d920a6'),(487,17,328,NULL,260,1,'2025-03-31 00:58:52','2025-03-31 00:58:52','e1430754-8b5f-44dd-8b22-3834680aeaad'),(488,17,328,NULL,263,2,'2025-03-31 00:58:52','2025-03-31 00:58:52','12f57b86-1c71-44f3-9432-84a7763c4d36'),(489,17,328,NULL,262,3,'2025-03-31 00:58:52','2025-03-31 00:58:52','a2656290-8e4f-4ea8-8606-38d8d1965e91'),(490,17,328,NULL,261,4,'2025-03-31 00:58:52','2025-03-31 00:58:52','03f9e4fd-638c-4ee3-be6b-74ef35a26192'),(493,1,330,NULL,265,1,'2025-03-31 00:59:09','2025-03-31 00:59:09','fe0e3d60-5eaf-43d8-8159-344c7844169f'),(494,19,330,NULL,313,1,'2025-03-31 00:59:09','2025-03-31 00:59:09','1cdbd2ac-c4cc-4e76-84ec-0ed3d40dfea9'),(495,16,331,NULL,243,1,'2025-03-31 00:59:09','2025-03-31 00:59:09','89831313-6be6-4871-b914-f9264aa2d78b'),(496,16,332,NULL,267,1,'2025-03-31 00:59:09','2025-03-31 00:59:09','2b981caf-45d7-4051-b3e9-3a4d9b7a8de7'),(497,17,333,NULL,240,1,'2025-03-31 00:59:09','2025-03-31 00:59:09','98872e88-a591-445d-bc20-1864de86a8e3'),(498,17,333,NULL,241,2,'2025-03-31 00:59:09','2025-03-31 00:59:09','97e46ca4-f1d6-4d27-b352-2f51f71ea1a9'),(499,17,333,NULL,246,3,'2025-03-31 00:59:09','2025-03-31 00:59:09','37d77263-28d0-4236-8e34-e8ff9e3a4ccc'),(500,17,333,NULL,245,4,'2025-03-31 00:59:09','2025-03-31 00:59:09','7eea01c2-9257-4d58-8f6f-ba5740c46c79'),(503,1,335,NULL,107,1,'2025-03-31 00:59:47','2025-03-31 00:59:47','22c7423f-cd70-40a4-842a-5beefb6903cf'),(504,19,335,NULL,136,1,'2025-03-31 00:59:47','2025-03-31 00:59:47','55e685b6-5d90-40cc-a052-4b31ee6ab7b4'),(505,16,336,NULL,179,1,'2025-03-31 00:59:47','2025-03-31 00:59:47','5c1d27b7-917c-4d1c-b02c-fa8aede1c1cb'),(506,17,337,NULL,172,1,'2025-03-31 00:59:47','2025-03-31 00:59:47','cae0cb29-37ae-4294-821b-e6182ce9fd5e'),(507,17,337,NULL,175,2,'2025-03-31 00:59:47','2025-03-31 00:59:47','87a0f6a7-1d63-40ed-88bc-e00161c4c5f5'),(508,17,337,NULL,173,3,'2025-03-31 00:59:47','2025-03-31 00:59:47','0c6f920b-2754-409c-9f2b-250390f0dcf5'),(511,1,339,NULL,13,1,'2025-03-31 01:00:00','2025-03-31 01:00:00','b49d1827-23a2-4d49-9d9e-d046401250e7'),(512,19,339,NULL,237,1,'2025-03-31 01:00:00','2025-03-31 01:00:00','4cb7ce88-12ea-4820-8be8-92cfa7b5c19e'),(513,16,340,NULL,37,1,'2025-03-31 01:00:00','2025-03-31 01:00:00','dc4914e4-2b1f-4556-b684-b831546d257d'),(514,17,341,NULL,22,1,'2025-03-31 01:00:00','2025-03-31 01:00:00','c383b90a-ff1d-46b6-aaa0-7fa45fc2a9af'),(515,17,341,NULL,23,2,'2025-03-31 01:00:00','2025-03-31 01:00:00','e55513f3-83a2-479d-acea-59e0870b1d19'),(516,17,341,NULL,24,3,'2025-03-31 01:00:00','2025-03-31 01:00:00','807d7bb1-b15b-44ea-8ea0-3428974ce8a9'),(519,1,343,NULL,94,1,'2025-03-31 01:00:15','2025-03-31 01:00:15','fd6cd58a-b667-405a-8505-14ee0a67c300'),(520,19,343,NULL,94,1,'2025-03-31 01:00:15','2025-03-31 01:00:15','a3c389dd-07ed-4432-bb23-986cf1805947'),(521,16,344,NULL,96,1,'2025-03-31 01:00:15','2025-03-31 01:00:15','11b45914-7881-46b8-8090-adfd1aa2b20a'),(522,16,345,NULL,98,1,'2025-03-31 01:00:15','2025-03-31 01:00:15','53f8dd92-7eef-48a9-a398-3338b20f2ab2'),(527,1,256,NULL,296,1,'2025-03-31 02:25:41','2025-03-31 02:25:41','764ed4c0-4947-4eb6-8cb4-22db361cb708'),(528,24,256,NULL,316,1,'2025-03-31 02:25:41','2025-03-31 02:25:41','0276ecbe-9f46-45f6-b417-2a2446627732'),(529,1,347,NULL,296,1,'2025-03-31 02:25:41','2025-03-31 02:25:41','7f6501a2-da93-4755-80dd-8f2b9668076b'),(530,24,347,NULL,316,1,'2025-03-31 02:25:41','2025-03-31 02:25:41','aed16826-7205-4a21-bfe4-e85ba7693648'),(531,19,347,NULL,300,1,'2025-03-31 02:25:41','2025-03-31 02:25:41','5c8f2fd2-1e6e-43c4-a64d-12e9ad63bdff');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,5,2,1,''),(2,5,2,2,'「ドラフト1」を適用'),(3,27,2,1,NULL),(4,28,2,1,NULL),(5,5,2,3,''),(6,27,2,2,NULL),(7,28,2,2,NULL),(8,35,2,1,''),(9,36,2,1,NULL),(10,38,2,1,NULL),(11,35,2,2,''),(12,35,2,3,''),(13,35,2,4,'「ドラフト1」を適用'),(14,35,2,5,''),(15,35,2,6,'「ドラフト1」を適用'),(16,35,2,7,'「ドラフト1」を適用'),(17,35,2,8,'「ドラフト1」を適用'),(18,35,2,9,''),(19,35,2,10,''),(20,35,2,11,'「ドラフト1」を適用'),(21,35,2,12,'「ドラフト1」を適用'),(22,35,2,13,'「ドラフト1」を適用'),(23,35,2,14,''),(24,35,2,15,'「ドラフト1」を適用'),(25,67,2,1,NULL),(26,68,2,1,NULL),(27,69,2,1,NULL),(28,35,2,16,'「ドラフト1」を適用'),(29,77,2,1,NULL),(30,78,2,1,NULL),(31,35,2,17,'「ドラフト1」を適用'),(32,35,2,18,'「ドラフト1」を適用'),(33,87,2,1,NULL),(34,88,2,1,NULL),(35,35,2,19,''),(36,93,2,1,''),(37,95,2,1,NULL),(38,97,2,1,NULL),(39,93,2,2,'「ドラフト1」を適用'),(40,104,2,1,NULL),(41,106,2,1,''),(42,108,2,1,NULL),(43,110,2,1,NULL),(44,93,2,3,'「ドラフト1」を適用'),(45,95,2,2,NULL),(46,97,2,2,NULL),(47,35,2,20,'「ドラフト1」を適用'),(48,87,2,2,NULL),(49,88,2,2,NULL),(50,106,2,2,'「ドラフト1」を適用'),(51,106,2,3,''),(52,35,2,21,'「ドラフト1」を適用'),(53,93,2,4,'「ドラフト1」を適用'),(54,93,2,5,'「ドラフト1」を適用'),(55,93,2,6,'「ドラフト1」を適用'),(56,106,2,4,'「ドラフト1」を適用'),(57,35,2,22,'「ドラフト1」を適用'),(58,93,2,7,'「ドラフト1」を適用'),(59,106,2,5,'「ドラフト1」を適用'),(60,108,2,2,NULL),(61,150,2,1,''),(62,152,2,1,NULL),(63,154,2,1,NULL),(64,156,2,1,NULL),(65,150,2,2,'「ドラフト1」を適用'),(66,156,2,2,NULL),(67,106,2,6,'「ドラフト1」を適用'),(68,108,2,3,NULL),(69,110,2,2,NULL),(70,106,2,7,'「ドラフト1」を適用'),(71,108,2,4,NULL),(72,93,2,8,'「ドラフト1」を適用'),(73,35,2,23,'「ドラフト1」を適用'),(74,35,2,24,'「ドラフト1」を適用'),(75,35,2,25,'「ドラフト1」を適用'),(76,35,2,26,'「ドラフト1」を適用'),(77,35,2,27,'「ドラフト1」を適用'),(78,35,2,28,'「ドラフト1」を適用'),(79,35,2,29,'「ドラフト1」を適用'),(80,35,2,30,'「ドラフト1」を適用'),(81,35,2,31,'「ドラフト1」を適用'),(82,35,2,32,'「ドラフト1」を適用'),(83,35,2,33,'「ドラフト1」を適用'),(84,220,2,1,NULL),(85,35,2,34,'「ドラフト1」を適用'),(86,220,2,2,NULL),(87,35,2,35,'「ドラフト1」を適用'),(88,35,2,36,''),(89,35,2,37,'「ドラフト1」を適用'),(90,35,2,38,''),(91,150,2,3,'「ドラフト1」を適用'),(92,152,2,2,NULL),(93,154,2,2,NULL),(94,156,2,3,NULL),(95,150,2,4,'「ドラフト1」を適用'),(96,154,2,3,NULL),(97,256,2,1,''),(98,259,2,1,NULL),(99,93,2,9,NULL),(100,93,2,10,NULL),(101,256,2,2,'「ドラフト1」を適用'),(102,277,2,1,NULL),(103,256,2,3,'「ドラフト1」を適用'),(104,277,2,2,NULL),(105,256,2,4,'「ドラフト1」を適用'),(106,256,2,5,'「ドラフト1」を適用'),(107,256,2,6,'「ドラフト1」を適用'),(108,256,2,7,'「ドラフト1」を適用'),(109,256,2,8,'「ドラフト1」を適用'),(110,256,2,9,'「ドラフト1」を適用'),(111,93,2,11,'「ドラフト1」を適用'),(112,35,2,39,'「ドラフト1」を適用'),(113,150,2,5,'「ドラフト1」を適用'),(114,106,2,8,'「ドラフト1」を適用'),(115,256,2,10,'「ドラフト1」を適用'),(116,150,2,6,'「ドラフト1」を適用'),(117,256,2,11,'「ドラフト1」を適用'),(118,35,2,40,'「ドラフト1」を適用'),(119,256,2,12,'「ドラフト1」を適用'),(120,256,2,13,''),(121,256,2,14,'「ドラフト1」を適用'),(122,259,2,2,NULL),(123,256,2,15,'「ドラフト1」を適用'),(124,259,2,3,NULL),(125,150,2,7,'「ドラフト1」を適用'),(126,152,2,3,NULL),(127,154,2,4,NULL),(128,156,2,4,NULL),(129,106,2,9,'「ドラフト1」を適用'),(130,108,2,5,NULL),(131,110,2,3,NULL),(132,35,2,41,'「ドラフト1」を適用'),(133,87,2,3,NULL),(134,88,2,3,NULL),(135,93,2,12,'「ドラフト1」を適用'),(136,95,2,3,NULL),(137,97,2,3,NULL),(138,256,2,16,'「ドラフト1」を適用');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (2,'email',0,1,' kaori cdgrph com '),(2,'firstname',0,1,''),(2,'fullname',0,1,''),(2,'lastname',0,1,''),(2,'slug',0,1,''),(2,'username',0,1,' kaoara '),(3,'slug',0,1,' temp oulmdjysctvtimldzniftlkouiahenoxmbgt '),(3,'title',0,1,''),(4,'slug',0,1,' temp nsfdttqzfsynyvsgtbdonutxbducytcbvefn '),(4,'title',0,1,''),(5,'field',3,1,' 法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe bikeを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。 '),(5,'field',4,1,' 2024 '),(5,'slug',0,1,' mate bike no 違法改造 no 危険運転 special site '),(5,'title',0,1,' mate bike no 違法改造 no 危険運転 special site '),(6,'alt',0,1,''),(6,'extension',0,1,' webp '),(6,'filename',0,1,' mate01 2x webp '),(6,'kind',0,1,' image '),(6,'slug',0,1,''),(6,'title',0,1,' mate01 2x '),(7,'alt',0,1,''),(7,'extension',0,1,' webp '),(7,'filename',0,1,' next small 2x webp '),(7,'kind',0,1,' image '),(7,'slug',0,1,''),(7,'title',0,1,' next small 2x '),(8,'alt',0,1,''),(8,'extension',0,1,' webp '),(8,'filename',0,1,' slide03 2x webp '),(8,'kind',0,1,' image '),(8,'slug',0,1,''),(8,'title',0,1,' slide03 2x '),(9,'alt',0,1,''),(9,'extension',0,1,' webp '),(9,'filename',0,1,' slide02 2x webp '),(9,'kind',0,1,' image '),(9,'slug',0,1,''),(9,'title',0,1,' slide02 2x '),(10,'alt',0,1,''),(10,'extension',0,1,' webp '),(10,'filename',0,1,' mate top webp '),(10,'kind',0,1,' image '),(10,'slug',0,1,''),(10,'title',0,1,' mate top '),(11,'alt',0,1,''),(11,'extension',0,1,' webp '),(11,'filename',0,1,' next webp '),(11,'kind',0,1,' image '),(11,'slug',0,1,''),(11,'title',0,1,' next '),(12,'alt',0,1,''),(12,'extension',0,1,' webp '),(12,'filename',0,1,' slide01 2x webp '),(12,'kind',0,1,' image '),(12,'slug',0,1,''),(12,'title',0,1,' slide01 2x '),(13,'alt',0,1,''),(13,'extension',0,1,' webp '),(13,'filename',0,1,' mate top 2025 03 17 054048 qgcu webp '),(13,'kind',0,1,' image '),(13,'slug',0,1,''),(13,'title',0,1,' mate top '),(19,'alt',0,1,''),(19,'extension',0,1,' webp '),(19,'filename',0,1,' mate top webp '),(19,'kind',0,1,' image '),(19,'slug',0,1,''),(19,'title',0,1,' mate top '),(22,'alt',0,1,''),(22,'extension',0,1,' webp '),(22,'filename',0,1,' slide01 webp '),(22,'kind',0,1,' image '),(22,'slug',0,1,''),(22,'title',0,1,' slide01 '),(23,'alt',0,1,''),(23,'extension',0,1,' webp '),(23,'filename',0,1,' slide02 webp '),(23,'kind',0,1,' image '),(23,'slug',0,1,''),(23,'title',0,1,' slide02 '),(24,'alt',0,1,''),(24,'extension',0,1,' webp '),(24,'filename',0,1,' slide03 webp '),(24,'kind',0,1,' image '),(24,'slug',0,1,''),(24,'title',0,1,' slide03 '),(27,'slug',0,1,' temp cmetbobtamgwhelsnqnpigmgizquoedlegoe '),(27,'title',0,1,''),(28,'slug',0,1,' temp bwtineqbxyoepndoisxjdmxxhaqxrhoicdjb '),(28,'title',0,1,''),(35,'field',3,1,' 法令を遵守しつつ、楽しみながら、人と地球に優しい選択をするe bikeを正しく活用するために、ユーザーの皆様に向けた特設サイトの制作をお手伝いさせていただきました。 '),(35,'field',4,1,' 2024 '),(35,'field',11,1,' web design web design web development web development '),(35,'field',18,1,''),(35,'field',23,1,' mate bike no 違法改造 no 危険運転 special site '),(35,'slug',0,1,' mate bike no 違法改造 no 危険運転 special site '),(35,'title',0,1,' mate bike no 違法改造 no 危険運転 special site '),(36,'slug',0,1,' temp updcntfplzntjoobefplwicuonfgaoiugdia '),(36,'title',0,1,''),(37,'alt',0,1,''),(37,'extension',0,1,' webp '),(37,'filename',0,1,' mate01 webp '),(37,'kind',0,1,' image '),(37,'slug',0,1,''),(37,'title',0,1,' mate01 '),(38,'slug',0,1,' temp ubqsoowcjphtchmtqjghufxiixzmnscziifn '),(38,'title',0,1,''),(67,'slug',0,1,' temp opskzbrjeqbbbwxsahmykpymyafcixttcpof '),(67,'title',0,1,''),(68,'slug',0,1,' temp xzaoaymvdsverlksctyrmlbhwqpdlktvbnda '),(68,'title',0,1,''),(69,'slug',0,1,' temp obstttwpwjttrqgbfdftpmdqtnmrrwtrguhf '),(69,'title',0,1,''),(77,'slug',0,1,' temp alyjescceptaeymxatpwnivvfnndnwgkiesi '),(77,'title',0,1,''),(78,'slug',0,1,' temp nyozuxqikxbxziziyrydpoqufzsbqjwaxwmt '),(78,'title',0,1,''),(87,'field',16,1,' mate01 '),(87,'slug',0,1,' temp nmslncgwsryjboifaitmsdzijkbxwowshtpe '),(87,'title',0,1,''),(88,'field',17,1,' slide01 slide02 slide03 '),(88,'slug',0,1,' temp pfxiermofrakhwrdarfvqsqxvdkrxxtltrdu '),(88,'title',0,1,''),(93,'field',3,1,' 自社内の名刺をサイトリニューアルに合わせて数年ぶりに刷新。直接名刺交換をさせていただく機会もめっきり減ってしまいましたが、機会がありましたらぜひ受け取って下さい。 '),(93,'field',4,1,' 2025 '),(93,'field',11,1,' graphic design graphic design '),(93,'field',18,1,''),(93,'field',23,1,' codegraph namecard redesign '),(93,'slug',0,1,' codegraph namecard redesign '),(93,'title',0,1,' codegraph namecard redesign '),(94,'alt',0,1,''),(94,'extension',0,1,' webp '),(94,'filename',0,1,' namecard top webp '),(94,'kind',0,1,' image '),(94,'slug',0,1,''),(94,'title',0,1,' namecard top '),(95,'field',16,1,' namecard01 '),(95,'slug',0,1,' temp oceewabbsblobtmzcpzwpfllzyipdqjmugdv '),(95,'title',0,1,''),(96,'alt',0,1,''),(96,'extension',0,1,' webp '),(96,'filename',0,1,' namecard01 webp '),(96,'kind',0,1,' image '),(96,'slug',0,1,''),(96,'title',0,1,' namecard01 '),(97,'field',16,1,' namecard02 '),(97,'slug',0,1,' temp xdpddtgsmmijldfyvrmfskzanosvsouoxftw '),(97,'title',0,1,''),(98,'alt',0,1,''),(98,'extension',0,1,' webp '),(98,'filename',0,1,' namecard02 webp '),(98,'kind',0,1,' image '),(98,'slug',0,1,''),(98,'title',0,1,' namecard02 '),(104,'slug',0,1,' works index '),(104,'title',0,1,' works index '),(106,'field',3,1,' インフォコム株式会社のmission vision valueの刷新に伴うスペシャルサイトの構築を担当させていただきました。 '),(106,'field',4,1,' 2024 '),(106,'field',18,1,' super super inc '),(106,'field',23,1,' infocom mvv special site '),(106,'slug',0,1,' infocom mvv special site '),(106,'title',0,1,' infocom mvv special site '),(107,'alt',0,1,''),(107,'extension',0,1,' webp '),(107,'filename',0,1,' infocom top webp '),(107,'kind',0,1,' image '),(107,'slug',0,1,''),(107,'title',0,1,' infocom top '),(108,'field',16,1,' short offline 240822 '),(108,'slug',0,1,' temp mysgupsqfxgsepsvhsnckdggzzasxzrorsze '),(108,'title',0,1,''),(109,'alt',0,1,''),(109,'extension',0,1,' webp '),(109,'filename',0,1,' infocom01 webp '),(109,'kind',0,1,' image '),(109,'slug',0,1,''),(109,'title',0,1,' infocom01 '),(110,'field',17,1,' infocom slide01 infocom slide02 infocom slide03 '),(110,'slug',0,1,' temp kshggiaabxqtkwqqbhgvjgdhuiougfmktidq '),(110,'title',0,1,''),(111,'alt',0,1,''),(111,'extension',0,1,' webp '),(111,'filename',0,1,' infocom slide01 webp '),(111,'kind',0,1,' image '),(111,'slug',0,1,''),(111,'title',0,1,' infocom slide01 '),(112,'alt',0,1,''),(112,'extension',0,1,' webp '),(112,'filename',0,1,' infocom slide03 webp '),(112,'kind',0,1,' image '),(112,'slug',0,1,''),(112,'title',0,1,' infocom slide03 '),(113,'alt',0,1,''),(113,'extension',0,1,' webp '),(113,'filename',0,1,' infocom slide02 webp '),(113,'kind',0,1,' image '),(113,'slug',0,1,''),(113,'title',0,1,' infocom slide02 '),(136,'alt',0,1,''),(136,'extension',0,1,' webp '),(136,'filename',0,1,' infocom next webp '),(136,'kind',0,1,' image '),(136,'slug',0,1,''),(136,'title',0,1,' infocom next '),(147,'alt',0,1,''),(147,'extension',0,1,' mp4 '),(147,'filename',0,1,' short offline 240822 mp4 '),(147,'kind',0,1,' video '),(147,'slug',0,1,''),(147,'title',0,1,' short offline 240822 '),(150,'field',3,1,' 車体の破損および盗難を補償する「mate bikeオーナー」専用の盗難 車両保険についてのlp制作をお手伝いさせていただきました。ターゲットユーザーに届きやすい軽快なタッチで、難しい保険内容の理解しやすさを重視した設計を目指しています。 '),(150,'field',4,1,' 2023 '),(150,'field',11,1,' web design web design web development web development graphic design graphic design '),(150,'field',23,1,' mate bike 盗難＆車両保険 lp '),(150,'slug',0,1,' mate bike 盗難 車両保険 lp '),(150,'title',0,1,' mate bike 盗難＆車両保険 lp '),(151,'alt',0,1,''),(151,'extension',0,1,' webp '),(151,'filename',0,1,' mate top 1 webp '),(151,'kind',0,1,' image '),(151,'slug',0,1,''),(151,'title',0,1,' mate top 1 '),(152,'field',16,1,' mate01 1 '),(152,'slug',0,1,' temp raefhvvclavldyhmgwkbyoklyndxzqorlbxj '),(152,'title',0,1,''),(153,'alt',0,1,''),(153,'extension',0,1,' webp '),(153,'filename',0,1,' mate01 1 webp '),(153,'kind',0,1,' image '),(153,'slug',0,1,''),(153,'title',0,1,' mate01 1 '),(154,'field',16,1,' mate02 '),(154,'slug',0,1,' temp mhnfreujbcccbxjxrtkjiuehcaomotqqfide '),(154,'title',0,1,''),(155,'alt',0,1,''),(155,'extension',0,1,' webp '),(155,'filename',0,1,' mate02 webp '),(155,'kind',0,1,' image '),(155,'slug',0,1,''),(155,'title',0,1,' mate02 '),(156,'field',17,1,' mate slide01 mate slide02 mate slide03 mate slide04 '),(156,'slug',0,1,' temp ujvfagqbyvtkaaekgpternpklbolgymmfgiw '),(156,'title',0,1,''),(157,'alt',0,1,''),(157,'extension',0,1,' webp '),(157,'filename',0,1,' mate slide01 webp '),(157,'kind',0,1,' image '),(157,'slug',0,1,''),(157,'title',0,1,' mate slide01 '),(158,'alt',0,1,''),(158,'extension',0,1,' webp '),(158,'filename',0,1,' mate slide02 webp '),(158,'kind',0,1,' image '),(158,'slug',0,1,''),(158,'title',0,1,' mate slide02 '),(159,'alt',0,1,''),(159,'extension',0,1,' webp '),(159,'filename',0,1,' mate slide04 webp '),(159,'kind',0,1,' image '),(159,'slug',0,1,''),(159,'title',0,1,' mate slide04 '),(164,'alt',0,1,''),(164,'extension',0,1,' webp '),(164,'filename',0,1,' mate slide03 webp '),(164,'kind',0,1,' image '),(164,'slug',0,1,''),(164,'title',0,1,' mate slide03 '),(171,'alt',0,1,''),(171,'extension',0,1,' mp4 '),(171,'filename',0,1,' short offline 240822 mp4 '),(171,'kind',0,1,' video '),(171,'slug',0,1,''),(171,'title',0,1,' short offline 240822 '),(172,'alt',0,1,''),(172,'extension',0,1,' webp '),(172,'filename',0,1,' infocom slide01 webp '),(172,'kind',0,1,' image '),(172,'slug',0,1,''),(172,'title',0,1,' infocom slide01 '),(173,'alt',0,1,''),(173,'extension',0,1,' webp '),(173,'filename',0,1,' infocom slide03 webp '),(173,'kind',0,1,' image '),(173,'slug',0,1,''),(173,'title',0,1,' infocom slide03 '),(175,'alt',0,1,''),(175,'extension',0,1,' webp '),(175,'filename',0,1,' infocom slide02 webp '),(175,'kind',0,1,' image '),(175,'slug',0,1,''),(175,'title',0,1,' infocom slide02 '),(179,'alt',0,1,''),(179,'extension',0,1,' mp4 '),(179,'filename',0,1,' short offline 240822 mp4 '),(179,'kind',0,1,' video '),(179,'slug',0,1,''),(179,'title',0,1,' short offline 240822 '),(199,'alt',0,1,''),(199,'extension',0,1,' webp '),(199,'filename',0,1,' mate safedrive next webp '),(199,'kind',0,1,' image '),(199,'slug',0,1,''),(199,'title',0,1,' mate safedrive next '),(220,'slug',0,1,' temp kffolqoxpdibtjmfgttailebiaeqfcxvnght '),(220,'title',0,1,''),(237,'alt',0,1,''),(237,'extension',0,1,' webp '),(237,'filename',0,1,' mate safedrive next webp '),(237,'kind',0,1,' image '),(237,'slug',0,1,''),(237,'title',0,1,' mate safedrive next '),(240,'alt',0,1,''),(240,'extension',0,1,' webp '),(240,'filename',0,1,' mate slide01 webp '),(240,'kind',0,1,' image '),(240,'slug',0,1,''),(240,'title',0,1,' mate slide01 '),(241,'alt',0,1,''),(241,'extension',0,1,' webp '),(241,'filename',0,1,' mate slide02 webp '),(241,'kind',0,1,' image '),(241,'slug',0,1,''),(241,'title',0,1,' mate slide02 '),(242,'alt',0,1,''),(242,'extension',0,1,' webp '),(242,'filename',0,1,' mate02 webp '),(242,'kind',0,1,' image '),(242,'slug',0,1,''),(242,'title',0,1,' mate02 '),(243,'alt',0,1,''),(243,'extension',0,1,' webp '),(243,'filename',0,1,' mate01 1 webp '),(243,'kind',0,1,' image '),(243,'slug',0,1,''),(243,'title',0,1,' mate01 1 '),(244,'alt',0,1,''),(244,'extension',0,1,' webp '),(244,'filename',0,1,' mate top 1 webp '),(244,'kind',0,1,' image '),(244,'slug',0,1,''),(244,'title',0,1,' mate top 1 '),(245,'alt',0,1,''),(245,'extension',0,1,' webp '),(245,'filename',0,1,' mate slide04 webp '),(245,'kind',0,1,' image '),(245,'slug',0,1,''),(245,'title',0,1,' mate slide04 '),(246,'alt',0,1,''),(246,'extension',0,1,' webp '),(246,'filename',0,1,' mate slide03 webp '),(246,'kind',0,1,' image '),(246,'slug',0,1,''),(246,'title',0,1,' mate slide03 '),(247,'alt',0,1,''),(247,'extension',0,1,' webp '),(247,'filename',0,1,' mate top 1 webp '),(247,'kind',0,1,' image '),(247,'slug',0,1,''),(247,'title',0,1,' mate top 1 '),(248,'alt',0,1,''),(248,'extension',0,1,' webp '),(248,'filename',0,1,' mate02 webp '),(248,'kind',0,1,' image '),(248,'slug',0,1,''),(248,'title',0,1,' mate02 '),(256,'field',3,1,' 世界遺産である今帰仁城跡近くに位置し、「やんばる」と呼ばれる沖縄独特の大自然を背景に海を一望できる貸切ロッジ３棟を含むグランピング施設の、ティザーサイト制作をお手伝いさせていただきました。 国内外の観光客が忙しなく訪れる沖縄県だからこそ、その空間だけ時間が止まったような、魅力あふれるthe lodgeの空気感を感じていただけるよう配慮しています。 '),(256,'field',4,1,' 2024 '),(256,'field',11,1,' planning planning web design web design web development web development copywriting copywriting '),(256,'field',23,1,' the lodge okinawa teaser site '),(256,'slug',0,1,' the lodge okinawa teaser site '),(256,'title',0,1,' the lodge okinawa teaser site '),(257,'alt',0,1,''),(257,'extension',0,1,' webp '),(257,'filename',0,1,' lodgetop webp '),(257,'kind',0,1,' image '),(257,'slug',0,1,''),(257,'title',0,1,' lodge top '),(258,'alt',0,1,''),(258,'extension',0,1,' webp '),(258,'filename',0,1,' lodgetop 2025 03 21 092749 wnif webp '),(258,'kind',0,1,' image '),(258,'slug',0,1,''),(258,'title',0,1,' lodge top '),(259,'field',17,1,' lodge slide01 lodge slide02 lodge slide03 lodge slide04 '),(259,'slug',0,1,' temp pzoebfgkdvfrvcmvyulwkmlmzlqrtgvjzhaq '),(259,'title',0,1,''),(260,'alt',0,1,''),(260,'extension',0,1,' webp '),(260,'filename',0,1,' lodge slide01 webp '),(260,'kind',0,1,' image '),(260,'slug',0,1,''),(260,'title',0,1,' lodge slide01 '),(261,'alt',0,1,''),(261,'extension',0,1,' webp '),(261,'filename',0,1,' lodge slide04 webp '),(261,'kind',0,1,' image '),(261,'slug',0,1,''),(261,'title',0,1,' lodge slide04 '),(262,'alt',0,1,''),(262,'extension',0,1,' webp '),(262,'filename',0,1,' lodge slide03 webp '),(262,'kind',0,1,' image '),(262,'slug',0,1,''),(262,'title',0,1,' lodge slide03 '),(263,'alt',0,1,''),(263,'extension',0,1,' webp '),(263,'filename',0,1,' lodge slide02 webp '),(263,'kind',0,1,' image '),(263,'slug',0,1,''),(263,'title',0,1,' lodge slide02 '),(264,'alt',0,1,''),(264,'extension',0,1,' webp '),(264,'filename',0,1,' lodgetop webp '),(264,'kind',0,1,' image '),(264,'slug',0,1,''),(264,'title',0,1,' lodge top '),(265,'alt',0,1,''),(265,'extension',0,1,' webp '),(265,'filename',0,1,' mate top 1 2025 03 21 093306 lnsw webp '),(265,'kind',0,1,' image '),(265,'slug',0,1,''),(265,'title',0,1,' mate top 1 '),(267,'alt',0,1,''),(267,'extension',0,1,' webp '),(267,'filename',0,1,' mate02 2025 03 21 093327 wjgt webp '),(267,'kind',0,1,' image '),(267,'slug',0,1,''),(267,'title',0,1,' mate02 '),(277,'field',16,1,' lodge top '),(277,'slug',0,1,' temp cqcowumjcszfusicwrlpaqbmqzuyhkulveds '),(277,'title',0,1,''),(288,'alt',0,1,''),(288,'extension',0,1,' webp '),(288,'filename',0,1,' lodge next webp '),(288,'kind',0,1,' image '),(288,'slug',0,1,''),(288,'title',0,1,' lodge next '),(291,'alt',0,1,''),(291,'extension',0,1,' webp '),(291,'filename',0,1,' lodge next 2025 03 25 024536 jepx webp '),(291,'kind',0,1,' image '),(291,'slug',0,1,''),(291,'title',0,1,' lodge next '),(293,'alt',0,1,''),(293,'extension',0,1,' webp '),(293,'filename',0,1,' lodge next 2025 03 25 024729 dvii webp '),(293,'kind',0,1,' image '),(293,'slug',0,1,''),(293,'title',0,1,' lodge next '),(296,'alt',0,1,''),(296,'extension',0,1,' webp '),(296,'filename',0,1,' lodgetop webp '),(296,'kind',0,1,' image '),(296,'slug',0,1,''),(296,'title',0,1,' lodge top '),(300,'alt',0,1,''),(300,'extension',0,1,' webp '),(300,'filename',0,1,' lodgetop 2025 03 25 025336 jblp webp '),(300,'kind',0,1,' image '),(300,'slug',0,1,''),(300,'title',0,1,' lodge top '),(313,'alt',0,1,''),(313,'extension',0,1,' webp '),(313,'filename',0,1,' mate top 1 2025 03 25 033905 rhde webp '),(313,'kind',0,1,' image '),(313,'slug',0,1,''),(313,'title',0,1,' mate top 1 '),(316,'alt',0,1,''),(316,'extension',0,1,' mp4 '),(316,'filename',0,1,' lodge video mp4 '),(316,'kind',0,1,' video '),(316,'slug',0,1,''),(316,'title',0,1,' lodge video ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,1,'Works -Entry','worksEntry','structure',1,1,'all','beginning','[{\"label\": \"プライマリのエントリページ\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-03-17 04:17:04','2025-03-19 02:43:11',NULL,'3a35e34e-277e-47e5-94e8-8f4ff3887ee0'),(2,NULL,'Works - Index','worksIndex','single',1,1,'all','end','[{\"label\": \"プライマリのエントリページ\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-03-19 02:48:35','2025-03-19 02:48:35',NULL,'cc29658c-c25a-4148-9c08-e722eb9a1c7b');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES (1,3,1,NULL,NULL),(2,8,1,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'works/{slug}','works/_entry',1,'2025-03-17 04:17:04','2025-03-19 03:00:18','2125389c-44ee-4639-854b-499a82cad47f'),(2,2,1,1,'works-index','works-index/_entry.twig',1,'2025-03-19 02:48:35','2025-03-19 02:48:35','fdc200b6-6636-43d9-a1dc-815d6f3a8f73');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'CGtest','2025-03-14 01:39:02','2025-03-14 01:39:02',NULL,'bffa93b7-d62e-412f-be4a-661c30b74b33');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','CGtest','default','JA',1,'$PRIMARY_SITE_URL',1,'2025-03-14 01:39:02','2025-03-14 01:39:02',NULL,'e1547157-8cce-47ee-ad7b-ecafd023889a');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,12,0,'2025-03-17 05:35:19','2025-03-21 09:24:15','785c3adc-aa48-430e-8cab-ab4958ae5f1a'),(5,1,35,1,8,9,1,'2025-03-17 06:05:59','2025-03-21 09:24:15','2973995b-c553-4e8a-909d-4983a3b4b550'),(6,1,93,1,10,11,1,'2025-03-18 07:12:29','2025-03-21 09:24:15','8a1471b3-ea62-4e28-b54a-6174575fd137'),(7,1,106,1,6,7,1,'2025-03-19 03:06:57','2025-03-21 09:24:15','aad064b9-2057-41f8-bb3a-0e5077934fb7'),(8,1,150,1,4,5,1,'2025-03-21 08:02:25','2025-03-21 09:24:15','e48d218e-e11a-4c9e-a5d6-5d052d2eca8b'),(9,1,256,1,2,3,1,'2025-03-21 09:24:15','2025-03-21 09:24:15','6794046e-1740-4968-ae5c-55c9b9dc568e');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2025-03-17 04:17:04','2025-03-17 04:17:04',NULL,'e6fbcb61-8cad-49aa-8fef-8f4b68c82cc3');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tokens` VALUES (1,'m_x1WyLJfPiO6J6wTfZyo36Q81uxmv2w','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":35,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":2}]',NULL,NULL,'2025-03-18 07:12:14','2025-03-17 07:12:14','2025-03-17 07:12:14','71de950b-16d9-45fe-be94-1b6558e9bf08'),(2,'lcJRJs6WF_62F4EYLorWRQWMp1mHqdEs','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":35,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":2}]',NULL,NULL,'2025-03-18 07:13:46','2025-03-17 07:13:46','2025-03-17 07:13:46','75b3f488-f926-45a8-b367-37a2f566e6b0');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (2,'{\"locale\": null, \"language\": \"ja\", \"useShapes\": false, \"weekStartDay\": \"1\", \"underlineLinks\": false, \"disableAutofocus\": \"\", \"profileTemplates\": false, \"showFieldHandles\": true, \"showExceptionView\": false, \"alwaysShowFocusRings\": false, \"notificationDuration\": \"5000\", \"enableDebugToolbarForCp\": false, \"enableDebugToolbarForSite\": false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (2,NULL,NULL,1,0,0,0,1,'kaoara',NULL,NULL,NULL,'kaori@cdgrph.com','$2y$13$YV2Iu4JMlAHpPwnuH/ddL.bHmsUudYRvC6v3nbXxCxMAHLf9WZj92','2025-04-01 06:41:20',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2025-03-17 03:28:23','2025-03-17 03:28:23','2025-04-01 06:41:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Work','','2025-03-17 05:34:44','2025-03-17 05:34:44','729c3589-4389-4159-9bb8-d066d1579a09'),(2,NULL,NULL,'一時アップロード',NULL,'2025-03-17 05:34:59','2025-03-17 05:34:59','4710a1d6-aaad-4718-b497-40e6f24b1c94'),(3,2,NULL,'user_2','user_2/','2025-03-17 05:34:59','2025-03-17 05:34:59','f3c2251a-1563-43e7-9dbc-cd7123d1bc67'),(4,1,1,'MATE.BIKE-NO-違法改造-NO-危険運転-Special-site','MATE.BIKE-NO-違法改造-NO-危険運転-Special-site/','2025-03-17 05:41:07','2025-03-17 05:41:07','7f91a101-73c8-4bd0-b92b-c7dafc1151ab'),(5,1,1,'Codegraph-Namecard-redesign','Codegraph-Namecard-redesign/','2025-03-18 07:13:07','2025-03-18 07:13:07','d4e18977-0053-40fa-bfa9-b63da6e763aa'),(6,1,1,'infocom-MVV-Special-site','infocom-MVV-Special-site/','2025-03-19 03:12:01','2025-03-19 03:12:01','00084aa4-bb77-474c-a4aa-3eb74d68a7fa'),(9,1,1,'MATE.BIKE-盗難＆車両保険-LP','MATE.BIKE-盗難＆車両保険-LP/','2025-03-21 08:03:02','2025-03-21 08:03:02','91b3c631-b969-49bc-af19-8a95b2c2fc81'),(25,1,1,'The-Lodge-Okinawa-Teaser-site','The-Lodge-Okinawa-Teaser-site/','2025-03-21 09:29:19','2025-03-21 09:29:19','4a5a8d73-6f8c-4a9b-8729-2b0d214e468a');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,5,'Work','work','uploads','work','','transform/work','site',NULL,'none',NULL,1,'2025-03-17 05:34:44','2025-03-17 05:34:44',NULL,'0ec3aa91-e4e8-4340-a06a-519f38ee7424');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,2,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2025-03-17 03:29:29','2025-03-17 03:29:29','f4f802da-bd50-4cc0-b389-0cb2caed7606'),(2,2,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2025-03-17 03:29:29','2025-03-17 03:29:29','6344255b-a00d-4002-b81f-ac36ce0b1f22'),(3,2,'craft\\widgets\\Updates',3,NULL,'[]',1,'2025-03-17 03:29:29','2025-03-17 03:29:29','b7ec02fb-4a9d-4d46-8d30-b1f35dff3ce3'),(4,2,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2025-03-17 03:29:29','2025-03-17 03:29:29','da95784b-9e8b-4493-a7ee-29571f9b4559');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-02 13:22:38
